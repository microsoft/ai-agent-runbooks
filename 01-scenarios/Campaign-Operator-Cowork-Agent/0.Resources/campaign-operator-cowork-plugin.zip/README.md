# The Campaign Operator Cowork Plugin

This package targets Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders. Revision **3.1.0** retains `verified: false`: instruction and consistency checks are not proof of Cowork execution or a QA retest.

**Persona:** The Campaign Operator (Campaign / Marketing Ops / Brand Manager) · **Function:** Marketing
**Runbook:** `cowork-campaign-operator-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  campaign-operator-concierge/
    SKILL.md
    reference.md
  content-drift-audit/
    SKILL.md
    reference.md
  campaign-command-center/
    SKILL.md
    reference.md
  asset-production/
    SKILL.md
    reference.md
  event-command-center/
    SKILL.md
    reference.md
  customer-signal-synthesis/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `campaign-operator-concierge` | Routes the user to the right Campaign Operator skill |
| `content-drift-audit` | Audits every asset in a defined asset package against the approved messaging doc, the brand guide, and recent brand guidance from the user's manager in Teams |
| `campaign-command-center` | Runs a campaign from kickoff through execution: builds the kickoff pack and workstream plan, maintains a live tracker of workstreams, owners, blockers, approvals, and milestones, drafts weekly status updates and owner nudges, and optionally runs a weekly performance optimization loop that flags underperforming channels or content and recommends shifts |
| `asset-production` | Converts an approved campaign brief into the full list of required assets, drafts first versions grounded in approved messaging, routes drafts to reviewers, tracks approvals and blockers in an asset tracker, prepares final versions with a publishing checklist, and drafts owner notifications |
| `event-command-center` | Coordinates event marketing in one live execution view: speakers, sessions, customer meetings, content, social, logistics milestones, and post-event follow-ups, with a readiness tracker, customer meeting briefs, a social plan, a daily event digest, and follow-up drafts |
| `customer-signal-synthesis` | Reviews customer signals for a product or business area over a period (surveys, social listening reports, and website feedback in a feedback folder, plus emails and meeting transcripts where customer input was discussed), matches them to campaign performance in a workbook, and groups them into themes with quotes, frequency, affected audience or journey stage, and marketing implications |

Start with `campaign-operator-concierge` if you are not sure which skill to use. Recommended starters: `content-drift-audit` and `campaign-command-center`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All execution skills are review-first and evidence-grounded; the concierge only routes. Supplied-only requests use supplied evidence without M365 access, file saves, or extra artifacts unless requested. Before any permitted write, preview the exact action, content, destination, recipients/access scope and role, and sensitivity impact; wait for explicit confirmation and report success only from tool results. Posting does not grant permission to share a file.

Hard boundaries survive approval: Content Drift Audit never edits source assets; Asset Production never publishes externally; Event Command Center never directly publishes social posts or changes calendars. Owners perform those actions. References can tighten, never weaken, skill guardrails.

Revision 3.1.0 clarifies evidence labels, counting and readiness denominators, deterministic RAG, version-specific approvals, approved-copy fidelity, hypothesis-only analytics, anonymization, routing, scheduling, and action gates. Each reference includes checkable acceptance examples; these are specifications, not asserted model runs. Remaining gaps: live connector behavior, model compliance, billing, and end-to-end Cowork outcomes require runtime validation.
