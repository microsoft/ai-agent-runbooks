# Asset Production reference

Customer-tunable settings for `asset-production`. Settings here may tighten, but never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Campaign brief | [Campaign Brief] | Must be approved before the run |
| Messaging and brand | [Messaging Doc], [Brand Guide] | Drafting and self-check standard |
| Asset folder | [Asset Folder] | Drafts and finals |
| Reviewers by asset type | [Reviewers/Approvers] | e.g., brand, legal, product per asset type |
| Publish date and channels | [Publish Date], [Target Channels] | |
| Naming convention | [Campaign]-[Asset]-[Audience]-v[n] | Customer may replace |
| Version labels | Draft v1..n, Final | |
| Tracker | [Asset Tracker] | Excel workbook in [Asset Folder] |
| Refresh schedule | Twice weekly, [Days/Time] [Time Zone] | Until [Publish Date] |

## Rules and thresholds

| Rule | Default | Notes |
| --- | --- | --- |
| Evidence and scope | Confirmed / Proposed / Inferred / Unknown or Not assessed | Supplied-only: no external access, save, or extras unless requested; cite supplied labels |
| Asset status | Not started, Drafting, In review, Changes requested, Approved, Final, Blocked; Unknown if not evidenced | Unknown is not Not started; silence is not failure |
| Approval evidence | Explicit required-reviewer approval for the exact current version | Ambiguous comments stay In review; revision invalidates prior-version approval |
| Final and readiness | Track final label, approval, build/QA, readiness, publication separately | Unknown final count is not 0; failed QA/broken links/mandatory legal pending = Not launch-ready |
| Blocker | Missing input, missing reviewer, or overdue review | Age requires actual start; otherwise Unknown |
| Review SLA | [Review SLA] | Customer sets; drives overdue flag |
| Claim check | Approved claims verbatim, including supplied approved excerpts | Existing unsupported copy goes in Needs proof with corrected approved copy; never invent draft claims |
| Design-dependent assets | Creative direction notes only | No final design produced |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Asset cycle time | Days from brief to final assets | Tracker, file history | Asset cycle time |
| Approval latency | Median review turnaround | Tracker | Median review turnaround |
| Launch readiness | Ready individual assets / all required individual assets, with denominator and QA/approval gates | Tracker | Assets final by publish date (label count separately) |
| Blockers resolved | Blockers closed per refresh | Tracker | Not in baseline unless tracked |

## Output templates

| Template | Layout |
| --- | --- |
| Asset tracker (Excel) | Asset, type, channel, audience, owner, reviewer, status (version, final label, build/QA, readiness, publication), due date, blocker (actual start/age or Unknown), approval date, version-specific approval evidence, link |
| Draft assets | Word/PowerPoint in [Asset Folder], versioned per naming convention |
| Publishing checklist | By channel: asset, final link, publish date, owner, prerequisites |
| Review request | To: reviewer; asset links; what to check; due date |
| Owner notification | Final link; publish timing; checklist link |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [Campaign Brief], [Messaging Doc], [Brand Guide] | Required for full production | Use supplied approved excerpts for a scoped draft; mark remaining checks unassessed; never invent claims |
| Review comments (files, Teams, mail) | Required for tracking | Leave status unchanged; note the gap |
| Marketing analytics connector | Optional | Choose formats from the brief only |

## Never-automate list

Sends below require per-action confirmation and are never unattended; the remaining prohibitions
are absolute, including after approval.

- Sending review requests or owner notifications
- Marking an asset approved without evidence
- Publishing to any external channel
- Overwriting a final asset

## Sharing gate

Default state: drafts saved to [Asset Folder] only after approval; nothing sent or published.

Before a permitted write, show exact content, action, destination, exact recipients/access scope
and role, asset versions/links, and private/sensitivity impact. Wait for explicit confirmation;
posting/sending does not authorize a file share. No reliance on a secondary platform prompt.
Claim success only after tool confirmation. External publishing is always owner-only.
Scheduling additionally requires confirmed dates, timezone, prompt and cadence; recurring runs
produce draft changes only. Unknown inventory/areas preclude an overall readiness percentage;
partial measured coverage may be reported with its denominator. Separate overlapping counts.

## Billing

| Field | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy |
| License-only starter | None |
| Credit band | Historical sizing guide: Heavy 700+ Copilot Credits, not a quote, minimum, or cap; verify current tenant pricing, tools, asset volume, and refresh count before estimating |

## Example prompt

```
Turn [Campaign Brief] for [Campaign Name] into a complete asset list with owners, reviewers, and due dates for [Publish Date]. Draft the text-based assets using [Messaging Doc] and [Brand Guide], save them to [Asset Folder], and build an Excel asset tracker. Draft review requests to [Reviewers/Approvers], track approvals and blockers, prepare finals with a publishing checklist, and draft owner notifications. Show me every message before sending.
```

## Acceptance examples (specifications, not executed tests)

| Supplied input | Expected behavior |
| --- | --- |
| "Use only this approved claim: 'Works with X.' Draft one email." No full messaging doc. | One email using the exact approved claim; no invented handoff savings or tailored product capability, no M365 access or save |
| v1 approved; v2 changed; owner says ready; link QA fails; final label absent | v2 approval Unknown/pending, final label Unknown, Not launch-ready, publication Unknown; no assumed final count of 0 |
| "Email series of 3 plus 2 posts"; blocker start absent; Friday unanchored | 5 individual assets; age Unknown; Friday unresolved, not a fabricated cutoff |
| User approves publication | Prepare owner checklist only; no external publishing |
