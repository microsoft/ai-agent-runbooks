# Campaign Command Center reference

Customer-tunable settings for `campaign-command-center`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Campaign brief | [Campaign Brief] | Objectives, audiences, channels, budget, KPIs, dates |
| Campaign folder | [Campaign Folder] | Plans, exports, tracker |
| Team channel | [Campaign Team Channel] | Scanned each cycle; destination for draft status post |
| Workstreams and owners | [Workstreams and Owners] | Or derived from the brief |
| Status audience | [Status Audience] | Distribution list or channel |
| Status schedule | Monday 09:00 [Time Zone] | Weekly through [Launch Date] |
| Tracker | [Campaign Tracker] | Excel workbook in [Campaign Folder] |
| Performance sources | [Performance Sources] (optional) | Connector or exported reports |
| KPI targets | [KPI Targets] | From the brief or marketing ops |
| Attribution rules | [Attribution Rules] | Agreed with marketing ops |

## Rules and thresholds

### RAG model

| RAG | Deterministic default (apply in order) | Evidence required |
| --- | --- | --- |
| Red (blocked) | Confirmed critical blocker prevents a required milestone, or confirmed required milestone missed | Actual blocker/milestone evidence; no invented deadline |
| Amber (at risk) | No Red; confirmed unresolved noncritical blocker, pending required approval, or explicit dependency/slip risk | Evidence of the condition, not merely silence |
| Unknown | Neither above; missing/stale evidence prevents assessing all required workstreams | No current source, missing plan/required deadline, or insufficient coverage |
| Green (on track) | None above; all required workstreams have current evidence of progress against confirmed plan, no unresolved risk/blocker or required approval | Positive current evidence for every required workstream |

Apply per workstream, then aggregate Red > Amber > Unknown > Green. Reference overrides may
tighten thresholds or make a result more conservative, never allow Green with unknown/stale evidence.
RAG does not imply approval or launch readiness. Failed QA, broken links, or mandatory pending legal
signoff means Not launch-ready regardless of color; insufficient checks mean readiness Unknown.
Track approval, build/QA, readiness and freshness separately in existing Status/Readiness fields.
An owner "ready" report is evidence of that statement only, not completed build or QA.

### Other rules

| Rule | Default | Notes |
| --- | --- | --- |
| Evidence and scope | Confirmed / Proposed / Inferred / Unknown or Not assessed | Supplied-only: no M365, saves, extras unless requested; no imaginary links |
| Stale workstream | No update since last known cycle; Unknown if no cycle baseline | Freshness only; not failed/completed or automatically Red |
| Blocker age threshold | [Blocker Age Threshold] | Requires actual start and configured threshold; no age from report date |
| Approval latency threshold | [Approval Latency Threshold] | Customer sets |
| Underperformance | Below [KPI Targets] by [Variance Threshold] | Customer sets; no default figure |
| Shift types | Budget, creative, targeting | Hypotheses with proportionate validation, not asserted causes or guaranteed lift |
| Dates and coverage | Confirmed anchor/timezone for relative dates; disclose counting units, overlaps and denominator | Unknown deadlines stay Unknown; unknown areas preclude overall %, allow labeled partial measured coverage |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Status time saved | Hours spent assembling weekly status | Operator self-report | Hours spent on weekly status |
| Blocker resolution | Average blocker age; approval latency | Tracker | Average blocker age and approval latency |
| Workstream completion | Share of workstream milestones met on date | Tracker | Plan milestones |
| Performance lift / campaign ROI | Descriptive KPI change; ROI only with evidenced costs, returns and attribution method | Connector or exports; not proof of causality | KPI targets |

## Output templates

| Template | Layout |
| --- | --- |
| Kickoff deck (PowerPoint) | Objectives; audiences and channels; workstream plan; RACI; milestones; risks; decisions |
| Kickoff invite | Agenda: objectives, plan, RACI, risks, decisions; deck link |
| Tracker (Excel) | Tabs: Workstreams, Milestones, Blockers, Approvals, Optimization Actions; source-backed proposed updates; RAG, approval, QA/readiness and freshness kept distinct |
| Weekly status (Loop/Notebook page or Word) + Teams post | RAG summary, milestones, top blockers, decisions needed |
| Owner nudge | Item, due date, what is needed, link |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [Campaign Brief], [Campaign Folder] | Required for full kickoff | For a scoped supplied scenario use provided evidence; otherwise ask or mark gaps |
| [Campaign Team Channel], mail, transcripts | Required for weekly cycle | Note reduced coverage; freshness stale only against a known cycle, otherwise Unknown |
| Marketing analytics / CRM connector | Optional | Use supplied exports or state "Not assessed - performance data unavailable"; "No related signal found" only after actually reviewing data with no match |

## Never-automate list

Posts, sends and calendar proposals require per-action confirmation and are never unattended;
budget/settings changes and CRM/marketing write-back are prohibited even after approval.

- Posting the weekly status or sending nudges and approval requests
- Scheduling or changing the kickoff or any meeting
- Changing budget, targeting, or creative in marketing systems
- Any CRM or marketing-system write-back

## Sharing gate

Default state: not posted, not sent, not scheduled.

Before each permitted write, preview exact action, content, destination, recipients/access scope and
role, and private/sensitivity impact; wait for explicit confirmation. Posting is not file sharing.
Never depend on a platform secondary prompt; do not claim success before a tool confirms it.
Scheduling needs confirmed dates, timezone, exact prompt and cadence. Tracker changes remain
proposals until an approved write succeeds; scheduled runs draft only. Budget/settings changes and
CRM/marketing write-back remain prohibited even with approval.

## Billing

| Field | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy |
| License-only starter | None |
| Credit band | Historical sizing guide: Heavy 700+ Copilot Credits, not a quote, minimum, or cap; verify current tenant/tool pricing and source volume, then estimate confirmed run count |

## Example prompt

```
Kick off the [Campaign Name] campaign launching [Launch Date]. Read [Campaign Brief], build a workstream plan with owners, milestones, and approval points, and draft a kickoff deck and meeting invite. Then each Monday, scan [Campaign Team Channel], email, and meeting notes to update an Excel tracker of workstreams, blockers, approvals, and milestones; draft owner nudges and a weekly status update for [Status Audience]. If [Performance Sources] are available, flag underperforming channels and recommend shifts with owners. Show me all drafts before sending.
```

## Acceptance examples (specifications, not executed tests)

| Supplied input | Expected behavior |
| --- | --- |
| No launch date or update for a required workstream; no confirmed blocker | RAG Unknown, freshness Unknown/stale as evidenced, no invented lateness rationale |
| Owner says ready; QA links fail; mandatory legal approval pending | RAG from the model, Not launch-ready, QA failed and approval pending shown separately; no completed-build inference |
| Only weekly status requested, no workbook; blocker start absent | Status only, performance Not assessed - performance data unavailable, blocker age Unknown; no kickoff pack or live tracker write |
| "Post this status" but no file-share details | Preview exact channel/content and sensitivity; wait for confirmation; do not infer permission to share the tracker |
