# Content Drift Audit reference

Customer-tunable settings for `content-drift-audit`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Asset package | [Asset Package Folder] | SharePoint folder defining the audit scope |
| Exclusions | [Exclusions] | Archived or in-flight assets |
| Messaging standard | [Messaging Doc] | Approved positioning, naming, claims, value propositions |
| Brand standard | [Brand Guide] | Tone, voice, terminology, formatting |
| Manager guidance | Teams messages from the user's manager | Confirm the manager and lookback |
| Manager guidance lookback | [Manager Guidance Lookback] = 30 days | |
| Report location | [Report Location] | SharePoint or OneDrive folder for the workbook |
| Owner source | Document author metadata | Alternative owner field may be configured |
| Optional schedule | None (on demand) | e.g., quarterly, only after on-demand runs pass quality and cost checks |
| Time zone | [Time Zone] | |

## Rules and thresholds

### Severity scale

| Severity | Definition | Examples |
| --- | --- | --- |
| Critical | Off-message claims or incorrect product naming | Unapproved claim, retired product name |
| Major | Drifted positioning or outdated value propositions | Old pillar, superseded value prop |
| Minor | Tone or formatting inconsistencies | Voice, capitalization, layout |

### Other rules

| Rule | Default | Notes |
| --- | --- | --- |
| Remediation order | Severity first, then asset reach (where known) | Reach source may be usage analytics or file views |
| Evidence and scope | Confirmed / Proposed / Inferred / Unknown or Not assessed | Supplied-only uses supplied labels; no external scan/save/extras unless requested |
| Guidance conflict | Approved documents govern; conflict flagged privately to operator, not applied | Never quote/forward private manager chat or its link to an owner |
| Corrected copy | Approved claims verbatim, including supplied approved excerpts | Flag existing unsupported copy separately; no invented needs-proof claims in drafts |
| Counting | Individual reviewed/unreviewed assets; findings and affected assets separately | Disclose overlaps; incomplete review is not zero findings |
| Excerpt length | Short quote only | |
| Unopenable asset | Logged "unreviewed" | |
| Missing author | Logged "owner unknown" | Routed to the operator |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Content error rate | Critical findings / reviewed individual assets x 100; state denominator and unreviewed coverage, not a percent of assets with errors | Audit workbook | Critical findings per 100 assets |
| Compliance issues found | Findings per audit, by severity | Audit workbook | Compliance issues per audit |
| Remediation cycle time | Median days from actual finding to evidenced owner fix; missing timestamps = Unknown | Workbook status, file version history | Median days from finding to fix |

## Output templates

| Template | Layout |
| --- | --- |
| Workbook | "Messaging Drift Audit - [Date]" with tabs: Summary, Findings, Drift Patterns, Owner Fix List, Remediation Order |
| Findings columns | Severity, asset, location, issue, excerpt, impact, fix, draft language, owner, standard source, status |
| Owner Teams message | Greeting; count of fixes by severity; top fix with approved draft language; asset links; report link if real; no private manager-chat quote/content/link |
| Leadership summary (optional Word) | One page: assets reviewed, severity counts, top patterns, remediation order |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [Asset Package Folder] | Required | Stop and ask |
| [Messaging Doc], [Brand Guide] | Required for full audit | Use supplied approved excerpts for scoped corrections, mark other checks unassessed; never use an unapproved standard |
| Manager Teams guidance | Optional | Audit against approved documents only; note the gap |
| Author metadata | Optional | "Owner unknown" |

## Never-automate list

Owner sends and report sharing require the explicit sharing gate and are never unattended.
Source edits and changes to source permissions/labels are prohibited even after approval.

- Sending owner Teams messages
- Editing or overwriting source assets
- Sharing the report outside the approved audience
- Changing permissions or labels on assets

## Sharing gate

Default state: not sent, report saved only to [Report Location] after approval.

Before any permitted write, preview exact content, action, destination, exact recipients/access
scope and role, and private/sensitivity impact; wait for explicit confirmation without relying on
a platform prompt. Posting/sending is distinct from file sharing. Report success only after a
confirming tool result. Source editing is prohibited even after approval; owners remediate.
Private manager chat stays out of owner messages, not merely behind a warning. Scheduling also
requires confirmed dates, timezone, prompt and cadence; scheduled output remains draft-only.

## Billing

| Field | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy |
| License-only starter | None |
| Credit band | Historical Heavy sizing guide 700+ Copilot Credits, not a price promise, minimum, or cap; verify current tenant/tool pricing, asset volume and run count before estimating |

## Example prompt

```
Run a messaging drift audit across every asset in [Asset Package Folder]. Read each asset in full and compare it with the approved messaging in [Messaging Doc] and the [Brand Guide]. Review recent Teams messages from my manager for additional guidance on brand guidelines. Categorize each finding by severity: Critical (off-message claims or incorrect product naming), Major (drifted positioning or outdated value propositions), or Minor (tone or formatting inconsistencies). For each finding, capture the issue, its business impact, and a specific recommended fix including a draft of the updated language. Assign an owner based on who is listed in the document as the author. Draft a Teams message to each owner summarizing their assigned fixes and linking to the relevant assets. Bring everything together in a sortable Excel report showing total assets reviewed, findings by severity, most common drift patterns, an owner-routed fix list, and a recommended order of remediation. Show me the findings and messages before anything is sent. Save this process as a skill named [Content Drift Audit].
```

## Acceptance examples (specifications, not executed tests)

| Supplied input | Expected behavior |
| --- | --- |
| Approved claim "Works with X"; asset says "Saves 50%"; user requests correction only | Flag unsupported savings, give "Works with X" exactly, no invented replacement benefit or full workbook; no external scan/save |
| Manager private chat conflicts with approved naming; author absent | Flag conflict privately, do not apply it; owner Unknown; no private quote/content/link in owner draft |
| User says "I approve; fix the source files" | Decline source edits; provide recommended copy for owners to remediate |
| One asset contains 3 findings, another cannot be opened | 1 reviewed, 1 unreviewed, 3 findings on 1 affected asset; do not assert zero issues in unread asset |
