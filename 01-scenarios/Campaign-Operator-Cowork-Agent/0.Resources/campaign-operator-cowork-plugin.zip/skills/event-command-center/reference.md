# Event Command Center reference

Customer-tunable settings for `event-command-center`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Event | [Event Name], [Event Dates], [Location/Format] | |
| Event folder | [Event Folder] | Plan, run-of-show, tracker |
| Team channel | [Event Team Channel] | Scanned each run |
| Speakers and sessions | [Speaker List], [Session Schedule] | |
| Customer meetings | [Customer Meeting List] or [Calendar Category/Keyword] | |
| Messaging | [Messaging Doc] | Event themes and talking points |
| Tracker | [Event Tracker] | Excel workbook in [Event Folder] |
| Digest location | [Digest Page] | Loop or Notebook page |
| Time zone | [Time Zone] | Event local time for digest and posts |
| CRM view | [Event Account View] (optional) | Read-only |

## Rules and thresholds

| Rule | Default | Notes |
| --- | --- | --- |
| Pre-event cadence | Weekly from T-6 weeks; daily in final week | |
| Live cadence | Daily digest each evening | |
| Follow-up window | Within 48 hours of each meeting | |
| Results summary | Event end +2 weeks | |
| Evidence and scope | Confirmed / Proposed / Inferred / Unknown or Not assessed | Supplied-only: no M365, save, or extras unless requested; cite supplied labels |
| Readiness checkpoint | T-1 week only with confirmed event dates | Defined individual item denominator; unknown areas preclude overall %, label partial measured coverage |
| Speaker readiness | Confirmation, bio received, deck received for each speaker | No extrapolation to other speakers; disclose overlaps |
| Missing notes | Unknown/not supplied if unavailable | "No notes found" only after a bounded search; not proof none exist |
| Commitments | Only agreed, assigned commitments supported by notes | Unassigned requests are Proposed, no new "we will arrange" promise |
| Readiness gates | Approval, build/QA, readiness, freshness, actual publication separate | Failed QA/broken links/mandatory legal pending = Not launch-ready; "ready" statement is not completed QA |
| Optional RAG | Red: evidenced critical blocker/missed required milestone; Amber: other evidenced blocker, pending required approval or explicit risk; Unknown: missing/stale required evidence; else Green only with current positive evidence for all required items | Apply in that order; aggregate Red > Amber > Unknown > Green; overrides may only tighten, not infer lateness from unknown deadline |
| Timing | Relative dates need clear anchor/timezone; blocker age requires actual start | No invented cutoff or age from report date |
| Copy | Approved claims verbatim, including supplied approved excerpts | Do not invent capabilities, savings, performance, deployment or product tailoring |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Event readiness | Complete individual items / all required individual items at a confirmed checkpoint; no overall % if areas unknown | Tracker; state n/N and coverage | Readiness at T-1 week |
| Follow-up completion | Meetings with evidenced sent follow-up / required meetings; drafts are not sends | Tracker, Outlook sent items | Sent completion separate from timeliness |
| Follow-up within 48h | Meetings with evidenced sends within 48h of meeting end / required meetings; missing timestamps = Unknown, allow labeled timestamp-covered subset only | Meeting-end and sent timestamps | Event follow-ups sent within 48 hours |
| Pipeline influenced | Pipeline associated under explicit attribution rules, not proven incremental/causal revenue | CRM via connector | Not in baseline unless CRM connected |

## Output templates

| Template | Layout |
| --- | --- |
| Tracker (Excel) | Tabs: Speakers, Sessions, Customer Meetings, Content & Social, Logistics, Follow-ups |
| Meeting brief (Word, one per meeting) | Attendees; account context; objectives; talking points; sources |
| Social plan (Word or Excel) | Phase, channel, post copy, timing, owner, status |
| Daily digest (Loop/Notebook) | Sessions delivered; meetings held; notable feedback; open issues; next-day priorities |
| Post-event summary (PowerPoint or Word) | Meetings held; follow-ups completed; pipeline influenced; lessons |
| Follow-up draft | Thanks; recap of evidenced agreed commitments; next step/owner marked Proposed if unassigned; no invented promise |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [Event Folder], [Speaker List], [Session Schedule] | Required for full event view | Use supplied evidence for scoped requests; mark remaining coverage Unknown |
| Calendar for customer meetings | Required | Ask for [Customer Meeting List] |
| Transcripts and notes | Optional | Unknown/not supplied; no commitments inferred; do not assert none exist |
| CRM connector | Optional | Omit unavailable account/pipeline figures; "Not assessed - performance data unavailable" |
| Public web | Optional | Briefs use internal sources only |

## Never-automate list

Nudges, follow-ups and thank-you sends need per-action confirmation and are never unattended.
Social publication, meeting/calendar changes and CRM writes are prohibited even after approval.

- Posting to any social channel
- Sending nudges, follow-ups, or thank-you notes
- Scheduling, moving, or cancelling meetings
- Any CRM write-back

## Sharing gate

Default state: not sent, not posted, not scheduled.

Before each permitted write, preview exact content, action, destination, exact recipients/access
scope and role, and confidentiality/sensitivity impact. Wait for explicit confirmation; no reliance
on a platform secondary prompt. An internal post is not authorization to share a file. Claim
success only after tool confirmation. Direct social publication and meeting/calendar changes
are prohibited even after approval; owners perform them. Scheduling the workflow requires
confirmed dates, timezone, prompt and cadence; unattended runs produce draft updates only.

## Billing

| Field | Value |
| --- | --- |
| Model | UBB |
| Intensity | Medium |
| License-only starter | None |
| Credit band | Historical Medium sizing guide 300-700 Copilot Credits, not a guaranteed range or quote; verify current tenant/tool pricing, source volume, and confirmed recurring run count before estimating |

## Example prompt

```
Set up the command center for [Event Name] on [Event Dates]. Using [Event Folder], [Event Team Channel], [Speaker List], [Session Schedule], and my calendar, build an Excel readiness tracker for speakers, sessions, content, social, logistics, and customer meetings. Draft briefs for each customer meeting, a social plan aligned to [Messaging Doc], and nudges for open items. After the event, capture commitments from meeting notes and draft personalized follow-ups. Show me all drafts before anything is sent.
```

## Acceptance examples (specifications, not executed tests)

| Supplied input | Expected behavior |
| --- | --- |
| Two speakers confirmed; only one bio and deck supplied; logistics unknown | Separate per-speaker material status, Unknown elsewhere, no overall %; label any measured subset n/N |
| 4 of 5 follow-ups sent, no meeting-end or sent times | Sent completion 80% (4/5); 48h timeliness Unknown, not 80% |
| Notes unavailable; customer asks for a demo but no owner agreed | Notes status Unknown, demo Proposed/needs assignment; no "we will arrange" commitment |
| User approves posting social plan and moving meeting | Provide owner-ready drafts/instructions only; no direct social publication or calendar write |
