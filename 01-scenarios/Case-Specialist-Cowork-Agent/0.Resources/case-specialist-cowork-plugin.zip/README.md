# The Case Specialist Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Case Specialist (Support Engineer / Escalation Manager) · **Function:** Customer Service
**Runbook:** `cowork-case-specialist-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  case-specialist-concierge/
    SKILL.md
    reference.md
  case-intake-brief/
    SKILL.md
    reference.md
  knowledge-cited-reply/
    SKILL.md
    reference.md
  root-cause-diagnosis/
    SKILL.md
    reference.md
  stalled-case-outreach/
    SKILL.md
    reference.md
  escalation-handoff/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `case-specialist-concierge` | Routes the user to the right Case Specialist skill |
| `case-intake-brief` | Assembles a complete case-intake brief for a complex or escalated support case before the handler starts work: customer profile, case history, entitlement, SLA clock, related cases, and recent mail, Teams, and meeting conversations in one cited view |
| `knowledge-cited-reply` | Finds the best approved knowledge for a support case, adapts it to the customer's version and environment, and stages a customer reply with inline source citations for the agent's review |
| `root-cause-diagnosis` | Investigates a support issue documented in a case report, supplements it with escalation discussions in Teams, compares symptoms and environment with knowledge-base troubleshooting guidance, and produces a likely root-cause hypothesis with evidence, missing information, confirming checks, and a potential solution, plus a draft Teams message to engineering and a 30-minute engineering review invite |
| `stalled-case-outreach` | Detects stalled or dormant support cases, diagnoses who owns the next move (customer, internal team, engineering, vendor, or the agent), and drafts tailored outreach that gets each case moving again, with a re-engagement tracker and staged case updates |
| `escalation-handoff` | Assembles a clean escalation handoff package for a support case moving to a higher tier, engineering, the account team, or leadership: verified timeline, current diagnosis, applicable policy and entitlement, recommendation and decision needed, communications log, and an owner-assigned action register, plus a draft handoff note and optional customer update |

Start with `case-specialist-concierge` if you are not sure which skill to use. Recommended starters: `case-intake-brief` and `knowledge-cited-reply`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
