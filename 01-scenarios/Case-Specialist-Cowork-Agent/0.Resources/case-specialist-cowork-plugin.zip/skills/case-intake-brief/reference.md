# Case-Intake Brief reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Case folder / workbook | [Case Folder / Case Workbook] | Case report, export, or open-cases workbook row in OneDrive/SharePoint |
| Case management system | [Case Management System] - not connected | Optional connector (e.g., Dynamics 365 Customer Service, ServiceNow) |
| Knowledge base | [Knowledge Base] | Approved, published articles only |
| Queue for trigger | [Queue] | Tier 2/3 or escalation queue whose assignment email fires the run |
| Trigger email | [Assignment Email sender/subject] | Case assignment or escalation notification |
| Lookback period | 90 days | Related activity window |
| Output location | [Output Location] - ask | Folder for the saved brief |
| Output format | Word or Loop page | One to two pages |
| Time zone | [Time Zone] | Used for SLA clock and timeline dates |
| PII masking rules | Mask payment data, credentials, tokens, personal identifiers | Extend with customer privacy rules |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the support manager before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| SLA Green | More than 50% of SLA time remaining, clock running normally | Tune to the customer's SLA policy |
| SLA Amber | 25-50% remaining, or clock paused/on hold | |
| SLA Red | Under 25% remaining or already breached | |
| Repeat-contact pattern | Two or more related cases for the same customer and symptom in the lookback | Flag in Related cases |
| "Start here" list | Two or three actions | Ordered by SLA exposure, then customer commitment dates |
| Conflict handling | Show both sources and their timestamps | Never resolve silently |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Time to first response | Median time from assignment/escalation to first customer-facing response | Case workbook or report (or case system) | Time to first response |
| Case handling time | Specialist time spent per in-scope case, including context rebuild | Specialist time study | Case context rebuild time |
| CSAT | Average CSAT for complex or escalated cases | Survey/CSAT source | CSAT on in-scope cases |
| Customer repeat-ask rate | Cases where the customer was asked again for known information | Case notes/QA sample | Customer repeat-ask rate |

## Output templates

Brief layout (one to two pages):

1. Header: Case ID, customer, product, severity, owner, SLA traffic light, time to breach, source used
2. Customer snapshot: account tier, entitlement, key contacts (business role only), recent CSAT
3. Timeline: dated key events, contacts, status changes
4. Recent conversations with links
5. Commitments in flight: who, what, by when
6. Related cases and known articles
7. Open questions and data gaps
8. Start here: top two or three actions

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Case folder / workbook (M365) | Required (default path) | Ask the user to attach the case file or export; do not guess |
| Outlook, Teams, transcripts | Required | State the gap; brief proceeds on case file only |
| Case management system | Optional | Use the M365 case file; state that case facts come from it and its timestamp |
| Surveys/CSAT, telemetry | Optional | Omit the field and list it as a source gap |

## Never-automate list

- Case record, note, status, priority, or owner updates
- Customer replies or internal messages
- Saving the brief to a shared location

## Sharing gate

Default state: not saved, not sent. Before saving or sharing, show the exact location or
recipients, the exact content, and a private-data warning when the brief uses mail, chat,
transcript, or log content.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Light |
| Indicative band per run | Light 100-300 credits (Medium 300-700, Heavy 700+); actual use varies |
| Volume guardrail | Cap the trigger to in-scope queues; one run per assigned case |

## Example prompt

> I've just been assigned case [Case ID] for [Customer Name]. Build me a complete case-intake brief
> before I start work. Pull the case details, entitlement, and SLA status from [Case Folder / Case
> Workbook] (or [Case Management System], if connected), find related cases for this customer from
> the last [Lookback Period], and cross-reference recent emails, Teams conversations, and meeting
> transcripts that mention the customer or the case. Show me the timeline, commitments in flight,
> open questions, and the two or three things I should address first. Cite your sources, flag any
> gaps or conflicting information, and don't update the case record. Save the brief to [Output
> Location] after I review it.
>
> Save this as a skill named [Case-Intake Brief] and run it whenever a case assignment email for
> [Queue] arrives in my inbox.
