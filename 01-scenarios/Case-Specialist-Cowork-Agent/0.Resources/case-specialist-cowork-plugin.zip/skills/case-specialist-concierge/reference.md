# Case Specialist Concierge reference

Settings here tune routing for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Package directory

Startup order follows the plugin: concierge first, then the scenario skills.

| User goal | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Routing help across the plugin | `case-specialist-concierge` | "help me choose" | On demand |
| Full context on a new, inherited, or escalated case | `case-intake-brief` | "brief me on case [Case ID]" | Event - case assignment or escalation email |
| Accurate, policy-safe customer reply with citations | `knowledge-cited-reply` | "draft a reply for case [Case ID]" | Event - new customer email on an assigned case |
| Likely cause, engineering post, and review meeting | `root-cause-diagnosis` | "investigate the issue in [Case Report]" | On demand (optional reopen / [N]-day trigger) |
| Idle cases, next-move owner, and nudges | `stalled-case-outreach` | "which of my cases are stalled" | Yes - daily on business days |
| Escalation package and handoff to another team | `escalation-handoff` | "escalate case [Case ID]" | Event - case flagged for escalation |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "I just picked up case 123 - what do I need to know?" | `case-intake-brief` |
| "Prep me for this escalated case" | `case-intake-brief` |
| "What should I tell the customer?" | `knowledge-cited-reply` |
| "Find the right article and draft the email" | `knowledge-cited-reply` |
| "Why does this keep failing?" | `root-cause-diagnosis` |
| "Set up an engineering review for this issue" | `root-cause-diagnosis` |
| "Which tickets are stuck?" | `stalled-case-outreach` |
| "Who owes the next move on this case?" | `stalled-case-outreach` |
| "Hand this to engineering" | `escalation-handoff` |
| "Which skill should I use?" | `case-specialist-concierge` |
| "Which cases are about to breach?" | No match here - point to `service-ops-leader-concierge` (`sla-risk-triage`) |

## Ambiguity rules

- "Help with case X" and no further detail: ask whether they need context, a reply, a cause, a
  nudge, or a handoff; default suggestion is `case-intake-brief`.
- "Reply", "answer", "respond", or "what do I tell": `knowledge-cited-reply`.
- "Root cause", "why", "keeps happening", "engineering review": `root-cause-diagnosis`.
- "Stuck", "idle", "no response", "waiting on": `stalled-case-outreach`.
- "Escalate", "hand off", "handover", "package": `escalation-handoff`.
- If two skills fit, pick the narrower artifact first and mention the alternative.

## Starter recommendation

New users start with `case-intake-brief` on one test case, then `knowledge-cited-reply` on the same
case. Add `root-cause-diagnosis`, `stalled-case-outreach`, and `escalation-handoff` once intake and
reply outputs pass grounding and PII checks.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Skills installed | All five scenario skills | Remove rows above for skills not in pilot scope |
| Cross-persona router | `service-ops-leader-concierge` | Remove the pointer if not installed |

## Never-automate list

- Creating, changing, or deleting triggers or schedules
- Invoking a sibling skill's outbound actions

## No-match response

```markdown
I do not have a Case Specialist skill for <goal> yet. This plugin covers case-intake briefs,
knowledge-cited replies, root-cause diagnosis, stalled-case outreach, escalation handoffs, and
routing help.
```

## Schedule guidance

`stalled-case-outreach` is the only default scheduled workflow (daily on business days at [time]).
`case-intake-brief`, `knowledge-cited-reply`, and `escalation-handoff` can run as event triggers on
the named email. Do not create any trigger or schedule unless the user confirms the exact prompt,
queue, and cadence.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB |
| Credit intensity | Light (routing only) |
| Note | The routed skill bills at its own band once invoked |

## Example prompt

> I'm a tier 2 engineer and I've just been handed [Case ID]. Help me choose where to start.
