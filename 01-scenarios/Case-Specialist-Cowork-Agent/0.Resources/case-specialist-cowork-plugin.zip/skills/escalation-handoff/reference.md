# Escalation Handoff reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Case folder | [Case Folder] | Case report, notes, SLA and entitlement, diagnostic files |
| Case management system | [Case Management System] - not connected | Optional connector |
| Escalation template | [Escalation Template] | Organization's form; Word default layout if none |
| Policy / entitlement source | [Policy / Entitlement Source] | Support terms, escalation policy, contracts |
| Escalation targets | [Escalation Target] | Engineering, specialist team, account team, duty/escalation manager |
| Trigger | Escalation email or Teams post for [Queue] | Or case-system flag, if connected |
| Output location | [Output Location] | Package and action register |
| Time zone | [Time Zone] | Timeline and due dates |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the support manager before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Escalation criteria | Severity at [Sev level], SLA threshold crossed, executive complaint, technical depth, policy exception | Confirm with support manager |
| Timeline inclusion | Material events only: contacts, commitments, status changes, troubleshooting, incidents | Each with date and source |
| Exception flag | Any request without a cited approved policy | "No approved policy basis" |
| Customer update | Optional; only when the customer should hear about the escalation | States next contact time, no remedy promises |
| Action register | Every action has an owner (role) and due date | Missing owner shown as "unassigned" |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Escalation handoff time | Time to assemble timeline, diagnosis, policy, and communications | Escalation records/self-report | Escalation handoff time |
| Resolution time | Median time from escalation to resolution | Case workbook/report | Resolution time |
| Customer satisfaction | CSAT on escalated cases | Survey/CSAT source | CSAT on in-scope cases |
| Customer repeat-ask rate | Escalated cases where the customer was re-asked for known facts | QA sample | Customer repeat-ask rate |

## Output templates

Package layout (Word, on [Escalation Template] if provided): executive summary; customer impact;
timeline; diagnosis; policy and entitlement; recommendation and decision needed; communications log.

Action register columns: Action | Owner | Due | Status | Dependency.

Handoff note skeleton: case and customer -> why escalated -> decision needed -> top three facts ->
link to package -> next customer contact time.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Case folder (M365) | Required (default path) | Ask for the case export; do not reconstruct events |
| Policy / knowledge files | Required | Flag policy section as a gap |
| Outlook, Teams, transcripts | Required | Communications log marked incomplete |
| Prior intake/diagnosis outputs | Optional | Build diagnosis section from case evidence |
| Case management system, telemetry | Optional | State source used and timestamp |

## Never-automate list

- Sending the handoff note or customer update
- Reassigning, re-prioritizing, or setting the escalation flag
- Saving the package to a shared location

## Sharing gate

Default state: not sent, not saved. Before any action, show the exact recipients or location, the
exact content, staged record changes, and a private-data warning for customer or log content.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Medium |
| Indicative band per run | Medium 300-700 credits; actual use varies |

## Example prompt

> Case [Case ID] for [Customer Name] needs to be escalated to [Escalation Target] because
> [Escalation Reason]. Build a clean escalation package on [Escalation Template].
>
> Use the case details and SLA from [Case Folder] (or [Case Management System], if connected), our
> escalation and support policy in [Policy / Entitlement Source], and related emails, Teams chats,
> and meeting transcripts. Include a verified timeline, current customer impact, what we know about
> the cause and what's been ruled out, the applicable policy, my recommendation and the decision
> needed, a log of what the customer has been told, and an action register with owners and due
> dates.
>
> Draft the handoff message to [Escalation Target] and a short customer update. Cite sources and
> flag gaps. Show me everything before anything is sent, saved to [Output Location], or written to
> the case.
>
> Save this as a skill named [Escalation Handoff].
