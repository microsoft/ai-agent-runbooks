# Knowledge-Cited Reply reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Knowledge base | [Knowledge Base] | Approved KB, policy library, or product documentation; must expose ID, version, last-reviewed date |
| Policy / entitlement source | [Policy Source] | Basis for refunds, credits, SLA exceptions |
| Case thread / folder | [Case Thread / Case Folder] | Outlook thread and case file in OneDrive/SharePoint |
| Case management system | [Case Management System] - not connected | Optional connector |
| Reply channel | Email | Email, case portal, or chat |
| Tone / brand voice | Professional, empathetic, plain language | [Tone / Brand Voice] |
| Language | Customer's language on the case | [Language] |
| Trigger | New customer email on a case assigned to the user | Optional event trigger |
| SME directory | [SME Teams Channel] | Where gaps are routed for review |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the support manager before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Eligible sources | Approved and published only | Drafts may be listed as "unapproved - not cited" |
| Source ranking | Relevance, then version applicability, then recency | |
| Stale article | Last reviewed more than [N] months ago | Flag as caveat; suggested default 12 months, confirm with knowledge manager |
| Gap marker | "No approved source - SME review required" | Exact wording, kept in the draft |
| Confidence | High: every question cited to a version-matched article; Medium: caveats; Low: any gap | |
| Promises | Refunds, credits, SLA exceptions, roadmap only with a cited policy | Otherwise flag |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Response accuracy | Share of sampled replies with correct, approved, version-applicable guidance | QA review sample | Response accuracy |
| Time to first response | Median time from assignment to first customer-facing response | Case workbook or report | Time to first response |
| CSAT | Average CSAT for in-scope cases | Survey/CSAT source | CSAT on in-scope cases |
| Reply rework | Replies corrected for wrong guidance, missing citation, or unapproved promises | QA review comments | Reply rework |

## Output templates

Email skeleton:

1. Greeting and one-line acknowledgement of the issue
2. Answer per question, with steps and inline [KB-ID]
3. What we need from you (if anything)
4. Next steps and when you will hear from us
5. Sign-off in brand voice

Source panel columns: Article ID | Title | Version | Last reviewed | Link | Answers question.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook thread / case file (M365) | Required (default path) | Ask for the latest message or case export |
| Knowledge base | Required | Do not draft guidance; return gaps only |
| Teams SME discussion | Optional | Note as source gap |
| Case management system | Optional | Use M365 case file; state source and timestamp |
| Telemetry / service health | Optional | Omit incident status; note gap |

## Never-automate list

- Sending or posting any customer reply
- Writing case notes or changing case status
- Promising refunds, credits, SLA exceptions, or roadmap items

## Sharing gate

Default state: draft, not sent. Before sending, show the exact recipients, channel, final text, and
cited sources, and warn if any internal-only content or personal data is present.

## Billing

| Item | Value |
| --- | --- |
| Billing model | USL to UBB |
| Credit intensity | Light |
| License-only starter (USL) | An employee-facing knowledge agent or Copilot Chat over approved knowledge |
| Cowork (UBB) | Full multi-source, multi-step workflow with staged note and approval-gated send |
| Indicative band per run | Light 100-300 credits; actual use varies |

## Example prompt

> Draft a reply for case [Case ID]. Read the customer's latest message and the case history in
> [Case Thread / Case Folder] (or [Case Management System], if connected), then find the
> best-matching approved guidance in [Knowledge Base]. Adapt it to the customer's version and
> environment, answer every question they raised, and set clear next steps and timing expectations
> in our [Tone / Brand Voice].
>
> Cite each approved source inline and list the articles with versions and links. If any question
> has no approved source, flag it clearly rather than filling it in. Show me the draft before
> anything is sent, and stage a case note for my approval.
>
> Save this as a skill named [Knowledge-Cited Reply] so I can run it whenever a customer responds on
> one of my cases.
