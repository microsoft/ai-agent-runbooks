# Root-Cause Diagnosis reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Case report / folder | [Case Report] | Support notes, communications, screenshots, error messages, diagnostic logs |
| Escalations channel | [Escalations Teams Channel] | Where the issue has been discussed |
| Knowledge base | [Knowledge Base] | Troubleshooting guidance, known issues, workarounds |
| Engineering channel | [Engineering Teams Channel] | Receives the draft summary |
| Engineering lead | [Engineering Lead] | Review meeting attendee |
| Meeting window | A 30-minute slot next week | [Meeting Window]; respect the lead's working hours |
| Case management system | [Case Management System] - not connected | Optional; similar resolved cases |
| Output location | Case folder | Word or Loop page |
| Time zone | [Time Zone] | For meeting proposals |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the support manager before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Confidence High | Symptoms, environment, and version match an approved known issue and evidence has no conflicts | |
| Confidence Medium | Partial match or one material gap | |
| Confidence Low | Multiple gaps or conflicting evidence | Lead with checks, not solution |
| Alternative causes | List at least the next two candidates considered | With reason they rank lower |
| Confirming checks | Two or three | Questions or diagnostic steps |
| Optional trigger | Case reopens, or open more than [N] days unresolved | [N] set by support manager; off by default |
| Scheduling conflict | No free slot in window: propose next options | Never double-book |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Time to resolution | Median time from case creation/escalation to resolution | Case workbook or report | Resolution time |
| Repeat case rate | Share of cases recurring for the same customer and issue | Case workbook/report | Repeat case rate |
| Escalation rate | Share of cases escalated to engineering or an escalation manager | Escalation records | Escalation rate |
| Investigation time | Time to a working hypothesis and engineering handoff | Time study | Root-cause investigation time |

## Output templates

Analysis (Word or Loop): problem statement and environment; hypothesis with confidence; evidence
with links; other causes considered; missing information; confirming checks; potential solution
and next action.

Teams message skeleton: **Issue** | **Likely cause (confidence)** | **Key evidence (links)** |
**Potential solution** | **Ask of engineering** | link to analysis.

Invite skeleton: title "Engineering review - <issue>"; 30 minutes; agenda: case folder link,
analysis, open questions, proposed solution.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Case report / folder (M365) | Required (default path) | Ask for the case report; do not diagnose without it |
| Escalations Teams channel | Required | State gap; proceed on case report |
| Knowledge base | Required | State that no approved guidance supports the solution |
| Outlook Calendar | Required for invite | Provide agenda only; user schedules manually |
| Case management system | Optional | State that case facts come from the case report |

## Never-automate list

- Posting to the engineering channel
- Sending or creating the meeting invite
- Updating cause codes, notes, or status in any case system

## Sharing gate

Default state: not posted, not scheduled. Before posting or scheduling, show the exact channel,
attendees, slot, content, and a private-data warning if log or customer content is included.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Medium |
| Indicative band per run | Medium 300-700 credits; actual use varies |

## Example prompt

> Investigate the issue documented in [Case Report]. Review the support notes, customer
> communications, screenshots, error messages, and diagnostic logs in the document. Supplement that
> context with relevant discussions from the [Escalations Teams Channel]. Compare the symptoms and
> environment with the troubleshooting guidance in [Knowledge Base].
>
> Give me the most likely root-cause hypothesis, the evidence supporting it, any missing
> information preventing a stronger conclusion, the two or three questions or diagnostic checks
> needed to confirm the cause, and a potential solution and recommended next action.
>
> Draft a Teams message to the [Engineering Teams Channel] summarizing the issue, likely cause,
> supporting evidence, and potential solution. Then schedule a 30-minute meeting with [Engineering
> Lead] for next week, with the case folder, analysis, open questions, and proposed solution in the
> agenda. Cite every source and flag gaps or conflicting evidence. Show me the analysis, Teams
> message, and meeting invitation before anything is shared or scheduled.
>
> Save this as a skill named [Root-Cause Diagnosis].
