# Stalled-Case Outreach reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Scope | Cases assigned to me | [Queue] or [Case Owner] |
| Open cases workbook | [Open Cases Workbook] | Excel in OneDrive/SharePoint: status, sub-status, last activity, next action date |
| Case management system | [Case Management System] - not connected | Optional connector |
| Work-item tracker | [Engineering Tracker] - not connected | Optional; linked bug status |
| Knowledge base | [Knowledge Base] | Articles to include in customer outreach |
| Tracker location | [Tracker Location] | Excel re-engagement list |
| Schedule | Daily on business days at [time] | Weekly Monday for lower-volume queues |
| Time zone | [Time Zone] | For days-idle calculation |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the support manager before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Stall threshold | No meaningful activity in 5 business days | [Stall Threshold] |
| Meaningful activity | Customer or agent message, status change, or linked-bug update | Automated notifications do not count |
| Next-move owner | Customer / internal team / engineering or vendor / me / unclear | "Unclear" always surfaces first |
| Risk High | SLA exposure inside the risk window, negative sentiment, or high severity | |
| Risk Medium | Two or more unanswered attempts, or idle twice the threshold | |
| Closure | Only per [Closure Policy] (e.g., after N attempts) | Proposal only; never automatic |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Re-engagement rate | Share of stalled cases resuming meaningful activity after outreach | Case activity history/workbook | Re-engagement rate |
| Time to resolution | Median time from creation/escalation to resolution | Case workbook/report | Resolution time |
| Dormant cases reopened | Count of dormant cases restarted in the period | Tracker | Stalled-case dwell time |
| Stalled-case dwell time | Days cases sit idle before someone acts | Case activity history | Stalled-case dwell time |

## Output templates

Tracker columns: Case ID | Customer | Days idle | Last activity | Next-move owner | Risk |
Recommended action | Draft link | Status.

Customer email skeleton: reference to the open item -> what we need (one ask) -> how to send it ->
offer of a call or interim workaround -> when we will follow up.

Internal Teams skeleton: case and customer impact -> precise ask -> due date -> link to case.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Open cases workbook (M365) | Required (default path) | Ask for the queue export |
| Outlook, Teams, transcripts | Required | Classify owner as "unclear"; flag gap |
| Case management system | Optional | Use workbook; state source and timestamp |
| Engineering tracker | Optional | Note linked-bug status unknown |

## Never-automate list

- Sending customer emails or posting internal messages
- Closing cases or changing sub-status, owner, or reminders
- Creating follow-up tasks in a case system

## Sharing gate

Default state: drafts only. Before any send, show the exact recipients, final text, and the case it
relates to; warn if customer data would reach someone without a need to know.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Light |
| Indicative band per run | Light 100-300 credits; actual use varies |
| Volume guardrail | One run per day per queue |

## Example prompt

> Find my open cases in [Queue] that have had no meaningful activity for more than [Stall
> Threshold]. For each one, read the last exchange in [Open Cases Workbook] (or [Case Management
> System], if connected) and related emails, Teams chats, and meeting transcripts, and tell me who
> owns the next move - the customer, an internal team, engineering, a vendor, or me.
>
> Draft a tailored customer email for each case waiting on the customer and a Teams message for each
> case waiting on an internal team, with the specific ask and a due date. Put everything in an Excel
> tracker with days idle, next-move owner, risk, and recommended action. Stage any sub-status
> changes or follow-up tasks, but show me every draft and proposed update before anything is sent or
> written back.
>
> Save this as a skill named [Stalled-Case Outreach] and run it every weekday at [time].
