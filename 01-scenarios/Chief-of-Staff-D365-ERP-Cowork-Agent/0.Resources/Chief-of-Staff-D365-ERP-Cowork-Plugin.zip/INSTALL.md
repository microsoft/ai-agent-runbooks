# Chief of staff_D365 ERP - install and first run

## Prerequisites

- **Access to Dynamics 365 finance and operations instance** - an active, licensed user in the target Dynamics 365 Finance and Operations environment, set
  up as a user in each company / legal entity you will run against.
- **Necessary access to modules within the ERP system** - the Dynamics 365 licence and the security roles, duties and privileges for the module(s) in
  scope (Finance, Supply Chain Management). Every output reflects exactly what your own role-based access grants;
  the plugin never elevates or works around a permission boundary.
- **Ensure the Microsoft published Dynamics 365 ERP plugin enabled** - the Microsoft-published **Dynamics 365 ERP** plugin must be added to Copilot Cowork and
  connected to the approved Dynamics 365 Finance and Operations environment, signed in with your own Microsoft
  Entra ID account (never a shared or service account). All 11 skills in this package read through that
  one connection; none carries its own credential.
- Copilot Cowork itself must be enabled for your account by your administrator.
- Optional, for the email follow-up: Microsoft 365 Outlook access enabled for you in Cowork. Emails go only to your own
  mailbox and only after you approve the send.

## Install

1. Open Copilot Cowork and go to **Customize > Plugins**.
2. Choose **Upload plugin** and select `Chief-of-Staff-D365-ERP-Cowork-Plugin.zip`.
3. Confirm the plugin appears as **Chief of staff_D365 ERP** and switch it on for your conversations.
4. Make sure the **Dynamics 365 ERP** plugin is also on and connected (gear icon next to it > choose your
   environment > sign in if prompted). The first ERP query in a conversation will prompt you to connect if you
   have not done so.
5. If you previously installed this package as loose skills (version 1.x), remove those skills first so the two
   copies do not compete.
6. Optionally install **Insights Analyst_D365 ERP**; the two packages hand off to each other and are designed to be used together.

## First run

Start a **new** conversation (skill descriptions are loaded when a conversation starts) and type the demo prompt:

> "Run the finance morning brief." - the brief asks once for the company / legal entity and the Dynamics 365 URL, then delivers the HTML brief.

What you should see, in this order:

1. The skill asks you once for two inputs: the **company / legal entity** (for example a company code) and your
   **Dynamics 365 Finance and Operations URL** (the address you sign in to). Later prompts in the same conversation
   reuse both without asking; a new conversation asks again.
2. A short summary in the chat, plus a self-contained **HTML** file - the default deliverable - following the
   skill's visual standard (header band with legal entity and query timestamp, colour-coded cards, one section per
   table, callout boxes for the summary and source gaps).
3. Every row shows the record's own business number as plain text - order, invoice, journal, requisition, account
   or item number - so you can find it in Dynamics 365 in seconds. Nothing is a hyperlink, and internal IDs or GUIDs
   are never shown. The header band repeats the legal entity and the environment URL exactly as you entered them.
4. One follow-up question: **"Would you like (1) an editable Word (.docx) version, (2) this emailed to you, and/or
   (3) a scheduled run emailed to you?"** The Word version is written from the same data as the report you just
   received (no second query) as a structured document and is checked to be populated before it is offered. The email goes to your own address only - you see recipient, subject, summary and attachments and approve
   the send first. A scheduled run re-runs the same prompt on its natural cadence and emails it to you; each run asks you to approve its email before it is sent (approving the schedule or an earlier email does not approve the next one), and you can change or stop it in Cowork at any time.

Nothing is written to Dynamics 365 at any point. The only outbound action is the email to your own address, and only
after your approval. If Microsoft 365 Outlook access is not enabled for you in Cowork, the skill says so and skips it.

## Skills in this package

- `erp-concierge`
- `customer-account-brief`
- `finance-approvals-brief`
- `finance-morning-brief`
- `finance-week-ahead-brief`
- `operations-week-ahead-brief`
- `order-trace-brief`
- `procurement-decisions-brief`
- `project-portfolio-brief`
- `scm-morning-brief`
- `supplier-brief`

### Prompt-to-skill quick reference

| Prompt | Skill | What you get in seconds |
| --- | --- | --- |
| "Run the finance morning brief." | `finance-morning-brief` | Top items today across payables, receivables, ledger, bank and fixed assets |
| "Run the finance approvals brief." | `finance-approvals-brief` | Everything waiting in finance workflow, by age and amount |
| "Run the customer account brief." | `customer-account-brief` | Customers needing attention, with account numbers |
| "Run the project portfolio brief." | `project-portfolio-brief` | Projects over budget, behind schedule or with unbilled WIP |
| "Run the finance week-ahead brief." | `finance-week-ahead-brief` | Day by day: payments due, receipts expected, discounts expiring |
| "Run the SCM morning brief." | `scm-morning-brief` | Overdue POs and SOs, stock-out risk, holds, production at risk |
| "Run the procurement decisions brief." | `procurement-decisions-brief` | Requisitions, PO changes, RFQs and quality orders awaiting a decision |
| "Run the operations week-ahead brief." | `operations-week-ahead-brief` | Deliveries, shipments, production and transfers due this week |
| "Run the order trace brief." | `order-trace-brief` | Stuck purchase, sales, production and transfer orders, with order numbers |
| "Run the supplier brief." | `supplier-brief` | Vendors needing attention, with account numbers |

Fastest for a first run or a demo: finance approvals, procurement decisions, customer account and supplier briefs (single-module reads with many visible rows). The two morning briefs and the project portfolio brief sweep several modules and take longer - run them after the quick ones. One conversation, one question: the first prompt asks for the legal entity and environment URL; the rest reuse them.

Each skill's `SKILL.md` lists its demo prompt, other ways to ask, required inputs, workflow, output format, record
identifier rule, visual standard and guardrails; its `reference.md` holds the definitions, the data the skill reads
(never asked of the user), the record identifiers shown, scope resolution and hand-off table. The package `README.md` describes
the package standards.

## Troubleshooting

| Symptom | What to do |
| --- | --- |
| The plugin shows "Disabled by your organization's administrator" | Ask your administrator to enable Copilot Cowork plugins and the Dynamics 365 ERP plugin for your tenant. |
| The skill reports a source gap or "not available from the connected source" | Check that you are a user in that legal entity and hold the module's security roles; the skill never substitutes another company or sample data. |
| You want to switch company or environment mid-conversation | Say so in your next prompt (for example "switch to company <code>"); the skill confirms the new value and uses it from then on. |
| You expected clickable links to Dynamics 365 records | By design the outputs carry no hyperlinks; every row shows the record's business number, which you can paste into Dynamics 365 search or a list page filter. |
| The Word version is empty or missing sections | Re-run with the current package: the skill writes the document from the report data as structured content and verifies it is populated before offering it; if it still cannot, it says so and the HTML remains the deliverable. |
| The email follow-up is declined or fails | Microsoft 365 Outlook access must be enabled for you in Cowork; the email is only ever addressed to your own mailbox and is sent only after you approve it. |
| A scheduled run did not arrive | Open Cowork's scheduled runs, check the schedule is still active and that its prompt text states the legal entity, the environment URL and "email the result to me". |
| The wrong package answered (a report instead of a brief, or the reverse) | Use the demo prompt wording; briefs are "Run the ... brief", reports use the official report name. Both routers hand off to each other. |
| Nothing happens after changing skills | Start a new conversation; descriptions are read at conversation start. |
