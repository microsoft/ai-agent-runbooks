---
name: erp-concierge
description: |
  Chief-of-staff front door for Dynamics 365 ERP (Finance and SCM). Use when the user asks "what can
  the chief of staff do for finance / supply chain", "which brief should I run", "help me choose a
  brief" or states a broad Finance or SCM goal without naming a brief. Maps the goal to exactly one
  Chief-of-staff-erp brief and states its trigger phrase; no analysis, record access, sending or
  filing. Do NOT use when the user names a brief or uses its trigger phrase - finance-morning-brief,
  finance-approvals-brief, customer-account-brief, project-portfolio-brief,
  finance-week-ahead-brief, scm-morning-brief, procurement-decisions-brief,
  operations-week-ahead-brief, order-trace-brief or supplier-brief win. Do NOT use for KPI reports,
  ageing analytics, trends, DSO / DPO / OTIF or anything called a "report" or "pulse" - those belong
  to Insights-Analyst-erp.
license: MIT
metadata:
  owner: avr_msft
  version: 2.0.1
  classification: Public
  verified: "false"
  category: Chief of Staff
  suite: Chief-of-staff-erp
  reference: reference.md
  m365Apps: Dynamics 365 ERP plugin (Dynamics 365 Finance and Operations)
  benefits: "Save Time|Faster routing to the right chief-of-staff brief; Improve Quality|Clear single-skill hand-off with no overlap with Insights-Analyst-erp"
  evals: "Routing accuracy|Accuracy|Routes the user's intent to exactly one sibling brief; No overreach|Compliance|Does not perform sibling-skill work or access Dynamics 365 ERP itself; Hand-off correctness|Accuracy|Sends report, KPI and trend requests to Insights-Analyst-erp instead of a brief"
---

# ERP concierge

## At a glance

| Field | Detail |
| --- | --- |
| Primary job | Front door and router for the Chief-of-staff-erp package (Finance and SCM briefs) |
| Best output | One matched brief, why it fits, its trigger phrase, and the reminder that it will ask for the company / legal entity |
| Does not do | Analysis, Dynamics 365 ERP access, sending, filing, or scheduling without approval |
| Reference file | `reference.md` |

## What this skill does

ERP concierge is the front door to the package. It clarifies what the user wants to achieve across Finance
(attention list, approval queue, customer call prep, project watch-list, week ahead) or Supply Chain
Management (attention list, purchasing decisions, week ahead, order trace, vendor call prep), selects
exactly one sibling brief from the directory, and carries the user forward by restating the goal in that
brief's trigger language. It reminds the user that every brief asks for the company / legal entity first,
delivers a self-contained HTML file by default and then asks once whether a Word version, an email to the user
themselves or a scheduled run is wanted. It does not query
Dynamics 365 ERP itself. If the user already named a clear brief, route to it rather than re-clarifying.

## When to use

Use when the user asks:

- "what can the chief of staff do for finance?"
- "what can the chief of staff do for supply chain?"
- "which brief should I run?"
- "help me choose a brief"
- "I need a brief on ..."
- "get me ready for the close review / the S&OP review / my vendor call"

## When NOT to use

- Do not use when the user directly asks for one of the sibling briefs or uses its trigger phrase; route
  straight to that brief (see "Named-brief hand-off").
- Do not use - hand off instead - when the user asks for a report, pulse, KPI, ageing analytics, a trend,
  DSO / DPO / OTIF, inventory turns or a report schedule: those requests belong to Insights-Analyst-erp and
  its insights-analyst-concierge.
- Do not use to run anything: this router never queries Dynamics 365 ERP, never drafts, and never schedules
  without explicit confirmation.

## Routing menu

| User intent | Skill | Trigger phrase |
| --- | --- | --- |
| What needs my attention in finance today | `finance-morning-brief` | "finance morning brief" |
| What is waiting for my approval in finance | `finance-approvals-brief` | "finance approvals brief" |
| Which customers need attention / prep me for a customer call | `customer-account-brief` | "customer account brief" (customer optional) |
| Projects over budget, behind schedule or unbilled | `project-portfolio-brief` | "project portfolio brief" |
| What is coming up in finance this week | `finance-week-ahead-brief` | "finance week-ahead brief" |
| What needs my attention in supply chain today | `scm-morning-brief` | "SCM morning brief" |
| What is waiting on a purchasing decision | `procurement-decisions-brief` | "procurement decisions brief" |
| What is coming up in operations this week | `operations-week-ahead-brief` | "operations week-ahead brief" |
| Which orders are stuck / where is this order stuck | `order-trace-brief` | "order trace brief" (order optional) |
| Which vendors need attention / prep me for a vendor call | `supplier-brief` | "supplier brief" (vendor optional) |

## Prompt-to-skill quick reference

| Prompt | Skill | What you get in seconds |
| --- | --- | --- |
| "Run the finance morning brief." | `finance-morning-brief` | Top items today across payables, receivables, ledger, bank and fixed assets |
| "Run the finance approvals brief." | `finance-approvals-brief` | Everything waiting in finance workflow, by age and amount |
| "Run the customer account brief." | `customer-account-brief` | Customers needing attention, with account numbers |
| "Run the project portfolio brief." | `project-portfolio-brief` | Projects over budget, behind schedule or with unbilled WIP |
| "Run the finance week-ahead brief." | `finance-week-ahead-brief` | Day by day: payments due, receipts expected, discounts expiring |
| "Run the SCM morning brief." | `scm-morning-brief` | Overdue POs and SOs, stock-out risk, holds, production at risk |
| "Run the procurement decisions brief." | `procurement-decisions-brief` | Requisitions, PO changes, RFQs and quality orders awaiting a decision |
| "Run the operations week-ahead brief." | `operations-week-ahead-brief` | Deliveries, shipments, production and transfers due this week |
| "Run the order trace brief." | `order-trace-brief` | Stuck purchase, sales, production and transfer orders, with order numbers |
| "Run the supplier brief." | `supplier-brief` | Vendors needing attention, with account numbers |

Fastest for a first run or a demo: finance approvals, procurement decisions, customer account and supplier briefs (single-module reads with many visible rows). The two morning briefs and the project portfolio brief sweep several modules and take longer - run them after the quick ones. One conversation, one question: the first prompt asks for the legal entity and environment URL; the rest reuse them.

## Hand-off

| If the user asks for | Send them to |
| --- | --- |
| A daily / weekly / monthly report, a pulse, KPIs, ageing analytics, DSO / DPO / OTIF, turns, a trend or a schedule for a report | `insights-analyst-concierge` (Insights-Analyst-erp) |

## Named-brief hand-off

When the user names a brief or uses one of its trigger phrases, this router steps aside:

- For today's finance attention list, use finance-morning-brief instead.
- For the finance approval queue, use finance-approvals-brief instead.
- For one customer before a call, use customer-account-brief instead.
- For the project watch-list, use project-portfolio-brief instead.
- For the finance week ahead, use finance-week-ahead-brief instead.
- For today's supply chain attention list, use scm-morning-brief instead.
- For the purchasing decision queue, use procurement-decisions-brief instead.
- For the operations week ahead, use operations-week-ahead-brief instead.
- For one order's end-to-end status, use order-trace-brief instead.
- For one vendor before a call, use supplier-brief instead.

## Workflow

1. **Clarify only when needed.** If the goal is ambiguous, ask which area applies: finance attention list,
   finance approvals, customer call prep, project watch-list, finance week ahead, supply chain attention list,
   purchasing decisions, operations week ahead, order trace, or vendor call prep.
2. **Check for a hand-off first.** If the words are "report", "pulse", "KPI", "ageing analytics", "trend",
   "DSO", "DPO", "OTIF", "turns" or "schedule this report", send the user to `insights-analyst-concierge`
   and stop.
3. **Map to one brief.** Use `reference.md` as the routing authority. Do not split one request across
   multiple briefs in a single turn.
4. **State the carry-forward.** Name the brief, provide the trigger phrase, explain why it fits, and remind the
   user that the brief will ask once for the company / legal entity and environment URL and will deliver an HTML
   file by default (then one question: Word version, email to yourself, scheduled run).
5. **Offer scheduling only where appropriate.** The two morning briefs may be scheduled daily and the two
   week-ahead briefs weekly if the user asks; the rest are on demand.
6. **Handle no match plainly.** If none of the ten briefs fit, say the package does not cover that goal yet and
   show the current menu.

## Output format

```markdown
**Recommended brief:** `<skill>`
**Why:** <one sentence tied to the user's goal>
**Say:** "<trigger phrase>"
**Before it runs:** on the first brief in a conversation it asks once for your company / legal entity and your
Dynamics 365 URL, then reuses them; you get an HTML brief by default with every record's number shown, then one
question: Word version, email to yourself or a scheduled run. No order or account number is needed - the brief
lists the records that need attention first.
<optional: scheduling offer where appropriate>
```

## Style standard

- One recommendation, not a catalog dump.
- Restate the user's goal in the sibling brief's language.
- Keep it under one screen.

## Guardrails

- **No overreach.** Never perform sibling-skill work, never query Dynamics 365 ERP, never draft, send, post,
  file, or schedule without explicit confirmation.
- **One brief per turn.** Split requests get a clarifying question, not a multi-brief answer.
- **Hand off, do not compete.** Report, KPI and trend requests go to Insights-Analyst-erp; never route them
  to a brief.
- **Honest no-match.** Out-of-scope goals are named as such and captured as candidate expansions.

## Reference

Use `reference.md` for the routing authority table, tie-breaks, the hand-off rule and disambiguation
questions.
