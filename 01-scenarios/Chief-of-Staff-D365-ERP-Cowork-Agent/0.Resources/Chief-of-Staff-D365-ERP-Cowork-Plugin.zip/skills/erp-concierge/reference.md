# ERP concierge reference

## Routing authority

| Intent keywords | Skill |
| --- | --- |
| attention, on fire, needs a look, today, this morning + finance / ledger / AP / AR / bank / assets | `finance-morning-brief` |
| approval, approve, waiting on me, queue, workflow + journal / invoice / expense / timesheet / budget entry | `finance-approvals-brief` |
| customer + call, meeting, prep, position, brief, everything open | `customer-account-brief` |
| project, WIP, unbilled, over budget, behind schedule, timesheet compliance | `project-portfolio-brief` |
| this week, coming up, plan my week + finance / payments / receipts / discounts / close dates | `finance-week-ahead-brief` |
| attention, overdue, on hold, stock-out, behind schedule + supply chain / operations / today | `scm-morning-brief` |
| requisition, PO change, RFQ, award, quality order, purchasing decision, procurement queue | `procurement-decisions-brief` |
| this week, coming up + deliveries, shipments, production, transfers, operations | `operations-week-ahead-brief` |
| where is, stuck, trace, status of + purchase order / sales order / production order / transfer order number | `order-trace-brief` |
| vendor, supplier + call, meeting, prep, position, brief, everything open | `supplier-brief` |

## Hand-off to Insights-Analyst-erp

Route to `insights-analyst-concierge` - never to a brief - when the request contains any of: report,
pulse, KPI, ageing analytics, trend, month-over-month, year-over-year, DSO, DPO, OTIF, inventory turns,
days of supply, purchase price variance, budget variance, "schedule this report", or names a
Insights-Analyst-erp skill. Say plainly: "That is a report, not a brief - say '<IA trigger phrase>'."

## Tie-breaks

1. A named record (customer, vendor, order number) beats a list intent: route to the single-record brief
   (`customer-account-brief`, `supplier-brief`, `order-trace-brief`).
2. "This week" or "coming up" beats "today": route to a week-ahead brief.
3. "Approval", "waiting on me" or "queue" beats "attention": route to an approvals or decisions brief.
4. Finance words (journal, invoice, customer, vendor payment, project) beat SCM words only when no order,
   item or production term is present; otherwise ask the disambiguation question.

## Disambiguation question

"Is this about finance (ledger, payables, receivables, projects) or about supply chain (purchasing,
sales orders, inventory, production) - and do you want today's attention list, what's waiting on a
decision, the week ahead, one specific record, or preparation for a call?"

## Legal-entity reminder

Every brief in this package asks the user to enter the company / legal entity name before it runs, even
when only one is available. The concierge tells the user to expect that question; it does not collect the
legal entity itself.

## Output delivery reminder

Every brief delivers a self-contained HTML file by default and, once the results are generated, asks once
whether the user wants a Word version, the brief emailed to themselves or a scheduled run. The concierge states
this in its carry-forward.

## Scheduling guidance

- `finance-morning-brief` and `scm-morning-brief`: may be scheduled daily before the stand-up on request.
- `finance-week-ahead-brief` and `operations-week-ahead-brief`: may be scheduled weekly (Monday) on request.
- All other briefs: on demand.

## No-match handling

If none of the ten briefs fit, say the package does not cover that goal yet, show the routing menu, and
capture the goal as a candidate expansion. Do not improvise a brief.
