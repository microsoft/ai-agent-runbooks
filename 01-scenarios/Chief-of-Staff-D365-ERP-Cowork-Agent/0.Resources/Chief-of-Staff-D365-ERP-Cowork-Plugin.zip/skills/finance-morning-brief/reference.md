# Finance morning brief reference

## Definitions

| Term | Definition |
| --- | --- |
| Invoice due soon | Open vendor invoice whose due date falls within the next 3 calendar days (default; configurable per deployment) |
| Cash discount expiring | Open vendor invoice whose cash discount date falls within the next 3 days |
| Newly on hold | Vendor or customer whose hold state is other than No and changed within the last 7 days; existing holds are listed separately |
| Over credit limit | Customer balance plus open sales order value greater than the credit limit |
| Journal pending | Journal batch not yet posted: in approval workflow, awaiting posting, or out of balance (debits do not equal credits) |
| Unreconciled bank line | Bank statement line not yet matched to a ledger transaction |
| Unposted depreciation proposal | Fixed asset journal created from a depreciation proposal and not yet posted |

Excluded: cancelled and closed records, and records below any configured priority floor (the floor is
summarized, not itemized).

## Urgency ordering

(1) already breached - overdue, out of balance, over limit; (2) breaches within 3 days; (3) newly on
hold; (4) everything else by amount. Within a tier, larger amount first. Area order for the page:
payables, receivables, ledger, bank, fixed assets.

## Data the skill reads (never asked of the user)

The user supplies only the company / legal entity (and, optionally, a record to drill into). The skill itself
reads the following through the Dynamics 365 ERP plugin:

| Data the skill reads | Illustrative F&O OData entity or record type | Window |
| --- | --- | --- |
| Vendor invoices due, discounts expiring, invoices on hold | Open vendor transactions (due date, cash discount date); pending vendor invoices; `VendorsV2` (hold state) | Due within 3 days; current |
| Customers over credit limit or on hold | `CustomersV3` (credit limit, hold state); open customer transactions; open sales order value | Current |
| Journals pending approval or out of balance | `LedgerJournalHeaders` (posted = No), journal workflow status, journal totals | Current period |
| Unreconciled bank statement lines | Bank statement and reconciliation lines | Current |
| Unposted depreciation proposals | Fixed asset journals (depreciation proposal lines not posted) | Current period |
| Ledger period status | Ledger period settings (open / on hold / closed by module) | Current period |

Entity names are illustrative examples of standard F&O OData collections and record types; confirm exact
names against the connected environment's metadata, as custom or ISV entities may differ. A missing entity
is reported as a source gap, never substituted.

## Session inputs and record identifiers

**Deployment parameter (optional):** Environment URL: `<not set>` - if a deployment sets this to the Dynamics 365
Finance and Operations URL (for example `https://<name>.operations.dynamics.com`), the skill uses it and asks the
user only for the legal entity; otherwise the skill asks for the URL once per conversation together with the legal
entity. The URL is recorded and shown in the header band as entered; it does not redirect the Dynamics 365 ERP
plugin, which reads the environment it is connected to. A mismatch that becomes visible in the plugin's response
is reported under Source gaps.

Record identifiers shown in this brief (plain text, never a hyperlink, never a RecId, GUID or internal ID):

| Record type | Identifier shown (plain text) |
| --- | --- |
| Vendor | Vendor account number |
| Customer | Customer account number |
| Pending vendor invoice | Invoice number |
| Posted vendor invoice / open vendor transaction | Invoice number and voucher |
| Posted customer invoice / open customer transaction | Invoice number and voucher |
| General journal (unposted or pending) | Journal batch number |
| Bank account | Bank account ID (as shown in Cash and bank management) |
| Fixed asset journal | Journal batch number |

Identifiers are business numbers the reader can type into Dynamics 365 search or a list page filter; the legal
entity is stated once in the header band, not repeated in every row.

## Scope resolution

1. Company / legal entity: On the first brief in a conversation, ask the user once - in a single question - for two inputs: the company / legal entity code, and the Dynamics 365 Finance and Operations environment URL (the address they sign in to, for example https://<name>.operations.dynamics.com). Remember both for the rest of the conversation and reuse them silently on every later prompt, stating them in each brief's header band; if a later prompt names a different legal entity or URL, use that instead and confirm it back. Never guess or substitute either value. The URL is recorded and shown in the header band; it does not redirect the plugin, which reads the environment it is connected to. If a deployment default environment URL is set in reference.md, use it and ask only for the legal entity. A new conversation asks again; a scheduled prompt should state both values in its text.
2. Run only for the confirmed legal entity. A legal entity outside the user's membership is reported as a
   scope limitation, never silently included or dropped.
3. As-of date: Defaults to today; ask only if the user names another day.
4. Area filter: Ledger, payables, receivables, bank or fixed assets - only if the user narrows the brief; default is all five.
5. Never proceed on a guessed record, counterparty or location scope for an ask that names one; ask
   instead.

## Output delivery rule

When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
no external dependencies) together with a short chat summary. Once the results are generated, ask
exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this
brief emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only
on the options chosen and ask nothing further. Word: produce the .docx from the data already in this
conversation - the same summary, header details, sections, tables and figures used for the HTML,
with no second query to Dynamics 365 - written as structured document content through Cowork's Word
/ document creation capability: title, header line (legal entity, environment, as-of date, query
timestamp), one heading per section, each table as a real table, summary and Source gaps as bold
call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML
file as the document content. Before offering it, check the document contains every section and the
same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the
HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and
nobody else; subject "<brief title> - <legal entity> - <as-of date>"; body = the summary and the top
items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft 365
Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled run of
this brief's demo prompt on its natural cadence, with the legal entity, the environment URL and
"email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.

## Read-only rule

This brief has no write path. It never creates, updates, approves, rejects, posts, releases, adjusts or
deletes a Dynamics 365 ERP record, and never sends a message on the user's behalf. When the user wants to
act, the brief names the record by its number so the action is taken in the application.

## Hand-off rule

Chief-of-staff briefs answer "what needs my attention, what is waiting on a decision, what is coming this
week, where is this record, prep me for this call". KPI reports, ageing analytics, trends and scheduled
report packs belong to Insights-Analyst-erp:

| If the user asks for | Hand off to (Insights-Analyst-erp) |
| --- | --- |
| Daily cash position and liquidity KPIs | `cash-liquidity-pulse` |
| Weekly AR ageing, DSO and top overdue customers | `ar-aging-collections-pulse` |
| Weekly AP ageing, DPO and payment-run readiness | `ap-payment-readiness-pulse` |
| Monthly close-readiness trend | `close-readiness-analytics` |

## People-safety rule

Output reports records, conditions and record facts. It never ranks, rates, scores or compares employees,
approvers, buyers, planners or warehouse staff, never analyzes individual throughput or working patterns,
and never frames a condition as personal performance.

## Email and sharing gate

Default state: not shared. The only distribution this brief performs is an email to the signed-in user's own
address (To and From are the user), sent through Cowork's Microsoft 365 Outlook capability after the user approves
the send - recipient, subject, summary body and attachments are shown first. No other recipient, no Teams post, no
file share. A scheduled run emails the same way and requests approval for each send: if approval is declined or not given, the output stays in the session Output folder and nothing is sent. Approval of the schedule or of an earlier send does not authorize the next send.
