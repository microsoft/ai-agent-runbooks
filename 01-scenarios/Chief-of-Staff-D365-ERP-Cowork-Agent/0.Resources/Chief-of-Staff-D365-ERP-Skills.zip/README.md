# Chief-of-staff-erp

A Finance and Supply Chain Management (SCM) **chief-of-staff brief** package grounded in the
Microsoft-published Dynamics 365 ERP plugin (Dynamics 365 Finance and Operations): daily attention lists,
approval and decision queues, week-ahead calendars, one-record order traces, and call preparation for a
customer or a vendor - plus skill routing. Every skill is read-only and delivers a self-contained HTML brief
by default. Independent of the Insights-Analyst-erp package; install either or both.

**Version 2.0.2.** Before generating, emailing, or saving a brief, the skill confirms the plugin's
connected environment and legal entity against what was entered and pauses with a source gap if
either cannot be confirmed; a sandbox and a production environment sharing the same company code
are treated as different environments and never compared. Clarifies that the 20,000-character
`SKILL.md` figure is a recommended authoring target, not Cowork's platform limit (1 MB per `.md`
skill file). Skill names, logic and definitions are otherwise unchanged.

**Version 2.0.1.** Every scheduled run now requests approval before its email is sent; approval of a schedule or of an earlier send no longer covers the next send, and a declined or unanswered send leaves the brief in the session Output folder. Every skill declares `license: MIT` and the package includes the MIT licence notice as `LICENSE`. Hand-offs now name the companion package by its published name, Insights-Analyst-erp (`insights-analyst-concierge`). Skill names, logic and definitions are unchanged.

**Version 2.0.0.** This version replaces the module briefs of 1.0.0 (`ledger-close-pulse`,
`fixed-asset-tracker`, `vendor-invoice-brief`, `customer-billing-brief`, `project-cost-tracker`,
`procurement-sourcing-pulse`, `inventory-warehouse-brief`, `sales-order-pulse`, `manufacturing-ops-brief`,
`scm-exceptions-pulse`) with ten chief-of-staff briefs that no longer overlap with the Insights-Analyst-erp
reports, and removes the only write path the package had. Remove the 1.0.0 skills before installing 2.0.0.

## Briefs, not reports

This package produces chief-of-staff briefs: attention lists, decision queues, week-ahead views,
order traces and call preparation. It never produces KPI reports, ageing analytics, trends or
scheduled report packs - those belong to the Insights-Analyst-erp package. Every brief skill says
so in its description so the two packages never compete for the same prompt.

| A chief-of-staff **brief** (this package) answers | An Insights Analyst **report** (Insights-Analyst-erp) answers |
| --- | --- |
| What needs my attention today? | How are we doing on this KPI? |
| What is waiting on my approval or decision? | What is the ageing profile, DSO, DPO, OTIF? |
| What is coming up this week? | What is the trend versus last period? |
| Which orders are stuck, and where? | What is the weekly / monthly picture across the entity? |
| Prep me for my call with this customer or vendor | Which report should I schedule? |

Rule of thumb for users: if the answer belongs in a report, say "report" or "pulse"; if it belongs in your
inbox or your to-do list, say "brief".

## Skills

| Skill | Purpose |
| --- | --- |
| `erp-concierge` | Front door that routes the user's goal to the right Chief-of-staff-erp brief; hands report, KPI and trend requests to Insights-Analyst-erp |
| **Finance** |  |
| `finance-morning-brief` | Daily attention list across ledger, payables, receivables, bank and fixed assets for one legal entity |
| `finance-approvals-brief` | Read-only view of every finance item waiting in workflow - journals, vendor invoices, expense reports, timesheets, budget register entries - for one legal entity |
| `customer-account-brief` | Customers needing attention, and a one-page call brief for any one of them: position, exposure, disputes, open orders, talking points |
| `project-portfolio-brief` | Weekly watch-list across the project portfolio: budget overruns, schedule slips, unbilled WIP, unapproved expenses and timesheets |
| `finance-week-ahead-brief` | Dated view of the finance week: vendor payments due, customer receipts expected, cash discounts expiring, journals still to post, depreciation runs and period-end dates |
| **Supply Chain Management** |  |
| `scm-morning-brief` | Daily cross-module attention list across procurement, sales, inventory and production for one legal entity - read-only |
| `procurement-decisions-brief` | What is waiting on a purchasing decision in one legal entity: requisitions in review, purchase order change requests, RFQs awaiting an award, quality orders awaiting disposition |
| `operations-week-ahead-brief` | Dated view of the operations week for one legal entity: deliveries expected, shipments promised, production starting or finishing, transfers arriving, plus carry-over late items |
| `order-trace-brief` | Stuck purchase, sales, production and transfer orders in one legal entity - where each is stuck and why - with an end-to-end trace of any one order on request |
| `supplier-brief` | Vendors needing attention, and a one-page call brief for any one of them: open purchase orders, late lines, quality, invoice mismatches, holds, payments, talking points |

## Folder standard

Each skill folder contains:

- `SKILL.md` - the executable skill definition: prompt examples (demo prompt first), required inputs, workflow,
  output format, output delivery, record identifiers, visual standard and guardrails
- `reference.md` - definitions, urgency ordering, the data the skill reads (never asked of the user), record
  identifiers, scope resolution, output delivery rule, hand-off table and email gate

## Prerequisites

- **Access to Dynamics 365 finance and operations instance**
- **Necessary access to modules within the ERP system**
- **Ensure the Microsoft published Dynamics 365 ERP plugin enabled**

In detail:

- **Access to the Dynamics 365 Finance and Operations instance.** The user must have an active, licensed
  account in the target Dynamics 365 Finance and Operations environment, and must be set up as a user in the
  company / legal entity that the brief is scoped to. A user who is not added to a company inside the
  instance cannot retrieve data for that company, regardless of what the request asks for.
- **Necessary access to modules within the ERP system.** The user must hold the Dynamics 365 ERP license for
  the module(s) in scope - Finance or Supply Chain Management - and must be assigned the security roles,
  duties and privileges needed to view the relevant records. Every output reflects exactly what the user's
  role-based access control (RBAC) already grants; the package never elevates, bypasses, impersonates or works
  around a permission boundary. A user who lacks access to a module gets a plainly reported source gap for
  that module, never a substitute or a guess.
- **The Microsoft-published Dynamics 365 ERP plugin enabled.** The Dynamics 365 ERP plugin must be enabled in
  Copilot Cowork and connected to the approved Dynamics 365 Finance and Operations environment. The connection
  authenticates with the same Microsoft Entra ID account the user signs in with - never a shared, delegated or
  service account - so every read is scoped to that individual user's own access. Every skill in this package
  calls this same plugin connection; none maintains a separate credential or API path.
- **Legal entity and environment URL are asked once per conversation.** On the first brief in a conversation, ask the user once - in a single question - for two inputs: the company / legal entity code, and the Dynamics 365 Finance and Operations environment URL (the address they sign in to, for example https://<name>.operations.dynamics.com). Remember both for the rest of the conversation and reuse them silently on every later prompt, stating them in each brief's header band; if a later prompt names a different legal entity or URL, use that instead and confirm it back. Never guess or substitute either value. The URL is recorded and shown in the header band; it does not redirect the plugin, which reads the environment it is connected to. If a deployment default environment URL is set in reference.md, use it and ask only for the legal entity. A new conversation asks again; a scheduled prompt should state both values in its text.
- **Entity names may vary by environment.** Every skill's `reference.md` lists the standard F&O OData
  collections and record types it expects (for example `CustomersV3`, `VendorsV2`, `InventSum`,
  `PurchaseOrderHeadersV2`, `LedgerJournalHeaders`). These are illustrative; custom fields, ISV solutions or
  renamed entities in your tenant may differ. A skill reports a source gap rather than guessing or substituting
  a similarly named entity.
- **No record numbers required.** Users are never asked for an order, invoice or account number. The three
  briefs that can focus on one record (`customer-account-brief`, `supplier-brief`, `order-trace-brief`) run
  without one and return the list of customers, vendors or orders that need attention - each row carrying its
  own account or order number and a link that opens it in Dynamics 365 - so nobody has to know a number in
  advance. Naming one (or picking one from the list) drills into the full brief for that record; an ambiguous
  name gets the matches listed and a question, never a guess. Each skill's `SKILL.md` lists what it may ask for
  under "Required inputs"; the data it reads is documented in `reference.md` and is never requested from the user.

## Package standards

- **All eleven skills are read-only.** This package has no write path anywhere; it never creates, updates,
  approves, rejects, posts, releases a hold, adjusts inventory, reschedules or deletes any Dynamics 365 ERP
  record. When the user wants to act, the brief names the record by its number so the action is taken in the
  application. The only outbound action is the optional email of a brief to the user's own address, after approval.
- **Ask once per conversation for the legal entity and environment URL.** On the first brief in a conversation, ask the user once - in a single question - for two inputs: the company / legal entity code, and the Dynamics 365 Finance and Operations environment URL (the address they sign in to, for example https://<name>.operations.dynamics.com). Remember both for the rest of the conversation and reuse them silently on every later prompt, stating them in each brief's header band; if a later prompt names a different legal entity or URL, use that instead and confirm it back. Never guess or substitute either value. The URL is recorded and shown in the header band; it does not redirect the plugin, which reads the environment it is connected to. If a deployment default environment URL is set in reference.md, use it and ask only for the legal entity. A new conversation asks again; a scheduled prompt should state both values in its text.
- **Microsoft 365 Outlook access in Cowork (optional, for the email follow-up).** "Email this brief to me" sends
  through Cowork's Microsoft 365 Outlook capability to the signed-in user's own mailbox only, after the user approves
  the send; if Outlook access is not enabled for the user in Cowork, the brief says so and skips the email.
- **HTML by default, one follow-up question.** When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS, no external dependencies) together with a short chat summary. Once the results are generated, ask exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this brief emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only on the options chosen and ask nothing further. Word: produce the .docx from the data already in this conversation - the same summary, header details, sections, tables and figures used for the HTML, with no second query to Dynamics 365 - written as structured document content through Cowork's Word / document creation capability: title, header line (legal entity, environment, as-of date, query timestamp), one heading per section, each table as a real table, summary and Source gaps as bold call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML file as the document content. Before offering it, check the document contains every section and the same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and nobody else; subject "<brief title> - <legal entity> - <as-of date>"; body = the summary and the top items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft 365 Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled run of this brief's demo prompt on its natural cadence, with the legal entity, the environment URL and "email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.
- **Grounding and failure handling.** Every item, value and reason traces to the connected Dynamics 365 ERP
  plugin and the confirmed legal entity, with the legal entity, as-of date and query timestamp stated. If plugin
  access fails, the legal entity cannot be resolved, or a query returns blank or errors, the skill stops,
  retries a blank/invalid query once, and then reports the failure plainly - it never substitutes another legal
  entity, environment, tenant or sample data, and never guesses at an unclear request instead of asking.
- **Hand-off, not overlap.** Every brief's description names the Insights-Analyst-erp skills that own the
  KPI, ageing and trend versions of its subject, and declines those requests. Keep both packages installed;
  they are designed to be used together (a report flags a customer, a brief preps the call).
- **Records, not people.** Report records, conditions and legal entities, not people: no ranking, rating,
  comparison, sentiment inference, wellbeing inference or surveillance of employees, approvers, buyers,
  planners or warehouse staff. Names appear only as record facts.
- **Review before distribution.** Outputs are review-ready drafts; never send, post, publish, share, create
  tasks or update systems without explicit user confirmation.

## Demo prompts

Every brief has one demo prompt - the short form "Run the <brief name>." On the first brief in a conversation
it asks once for the company / legal entity and the Dynamics 365 URL, then delivers the HTML brief (visual
standard in each skill) with every record's number shown as plain text, then asks once whether a Word version, an
email to yourself or a scheduled run is wanted;
later briefs in the same conversation reuse both inputs without asking. Each `SKILL.md` keeps further trigger phrases for reference.

| Module | Skill | Cadence | Demo prompt |
| --- | --- | --- | --- |
| Finance | `finance-morning-brief` | Daily | "Run the finance morning brief." |
| Finance | `finance-approvals-brief` | Daily | "Run the finance approvals brief." |
| Finance | `customer-account-brief` | On demand | "Run the customer account brief." |
| Finance | `project-portfolio-brief` | Weekly | "Run the project portfolio brief." |
| Finance | `finance-week-ahead-brief` | Weekly | "Run the finance week-ahead brief." |
| SCM | `scm-morning-brief` | Daily | "Run the SCM morning brief." |
| SCM | `procurement-decisions-brief` | Daily | "Run the procurement decisions brief." |
| SCM | `operations-week-ahead-brief` | Weekly | "Run the operations week-ahead brief." |
| SCM | `order-trace-brief` | On demand | "Run the order trace brief." |
| SCM | `supplier-brief` | On demand | "Run the supplier brief." |

### Prompt-to-skill quick reference

| Prompt | Skill | What you get in seconds |
| --- | --- | --- |
| "Run the finance morning brief." | `finance-morning-brief` | Top items today across payables, receivables, ledger, bank and fixed assets |
| "Run the finance approvals brief." | `finance-approvals-brief` | Everything waiting in finance workflow, by age and amount |
| "Run the customer account brief." | `customer-account-brief` | Customers needing attention, with account numbers |
| "Run the project portfolio brief." | `project-portfolio-brief` | Projects over budget, behind schedule or with unbilled WIP |
| "Run the finance week-ahead brief." | `finance-week-ahead-brief` | Day by day: payments due, receipts expected, discounts expiring |
| "Run the SCM morning brief." | `scm-morning-brief` | Overdue POs and SOs, stock-out risk, holds, production at risk |
| "Run the procurement decisions brief." | `procurement-decisions-brief` | Requisitions, PO changes, RFQs and quality orders awaiting a decision |
| "Run the operations week-ahead brief." | `operations-week-ahead-brief` | Deliveries, shipments, production and transfers due this week |
| "Run the order trace brief." | `order-trace-brief` | Stuck purchase, sales, production and transfer orders, with order numbers |
| "Run the supplier brief." | `supplier-brief` | Vendors needing attention, with account numbers |

Fastest for a first run or a demo: finance approvals, procurement decisions, customer account and supplier briefs (single-module reads with many visible rows). The two morning briefs and the project portfolio brief sweep several modules and take longer - run them after the quick ones. One conversation, one question: the first prompt asks for the legal entity and environment URL; the rest reuse them.

## Record identifiers - no hyperlinks

Every row in every brief shows the record's own business number as plain text - order, invoice, journal,
requisition, account or item number (each `reference.md` lists them under "Record identifiers"). Nothing in a
brief is a hyperlink, and RecIds, GUIDs and other internal identifiers are never shown. The header band names the
legal entity and the environment URL exactly as the user entered them.

## Follow-ups: Word, email, scheduled run

When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
no external dependencies) together with a short chat summary. Once the results are generated, ask
exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this
brief emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only
on the options chosen and ask nothing further. Word: produce the .docx from the data already in this
conversation - the same summary, header details, sections, tables and figures used for the HTML,
with no second query to Dynamics 365 - written as structured document content through Cowork's Word
/ document creation capability: title, header line (legal entity, environment, as-of date, query
timestamp), one heading per section, each table as a real table, summary and Source gaps as bold
call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML
file as the document content. Before offering it, check the document contains every section and the
same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the
HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and
nobody else; subject "<brief title> - <legal entity> - <as-of date>"; body = the summary and the top
items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft 365
Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled run of
this brief's demo prompt on its natural cadence, with the legal entity, the environment URL and
"email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.

## Recommended cadence

| Cadence | Skills |
| --- | --- |
| Daily (on request, before the stand-up) | `finance-morning-brief`, `scm-morning-brief`, `finance-approvals-brief`, `procurement-decisions-brief` |
| Weekly (Monday) | `finance-week-ahead-brief`, `operations-week-ahead-brief`, `project-portfolio-brief` |
| On demand | `customer-account-brief`, `supplier-brief`, `order-trace-brief` |

All skills are on demand by default; scheduling is offered only when the user asks for it.

## Avoiding collisions with Insights-Analyst-erp

Copilot Cowork selects a skill by matching the request against each skill's description. To keep the two
packages apart:

1. Use the vocabulary split: **brief** (this package) versus **report / pulse / KPI / trend**
   (Insights-Analyst-erp). Every description in both packages now carries an explicit hand-off sentence.
2. Teach the lead trigger phrase - "Run the finance morning brief." - rather than a description of the data.
3. After installing or changing either package, test in a **new** conversation; descriptions are loaded when
   a session starts.
4. If a prompt lands on either concierge, the phrase you typed is missing from the functional skill's
   description - add it there.
5. For demonstrations, the Insights-Analyst-erp plugin can be switched off in the conversation's sources
   picker so only briefs can fire.
