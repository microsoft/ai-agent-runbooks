# Chief of Staff Sales Cowork Plugin (v1.1.0)

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest
plus expanded agent skill folders. It is independent of the Chief of Staff Service plugin package;
deploy either or both.

## What changed in 1.1.0

- Every skill now carries an explicit **handoff** to the built-in Dynamics 365 Sales plugin skills
  (meeting preparation, activity synthesis, pipeline prioritizer) so Cowork's conflict scan sees a
  deliberate division of labour rather than competing triggers.
- Trigger phrases were narrowed so the package does not capture prompts Microsoft documents for
  the built-in skills (for example "Help me prepare for my meeting with Contoso").
- Environment handling follows the documented Cowork behaviour: the first sales prompt asks the
  user to pick the Dynamics 365 environment, Cowork remembers it, and the user changes it with
  `list environments` or `Set environment to [environment name]`. Skills report the environment
  and never change it themselves.
- Write and send gates now reference Cowork's native approval dialog and instruct users not to
  suppress it for record updates or sends.
- Companion files moved to `references/` (documented layout); non-standard frontmatter moved here.
- Parameters are passed in the prompt (scheduled-prompt text for Monday runs); org-wide defaults
  sit in each skill's `references/reference.md`. No dependency on a Preferences tab.
- `manifest.json`: `packageName`, `validDomains`, and `defaultInstallScope` removed (the v1.28
  schema rejects undefined fields), skill paths use `./skills/<name>`, version bumped.
- Three new skills: `lead-reengagement`, `segment-pattern`, `pipeline-review-deck`.

## Contents

```text
manifest.json
color.png                 192x192
outline.png               32x32
skills/
  sales-concierge/        SKILL.md, references/reference.md
  sales-leader-360/       SKILL.md, references/reference.md
  deal-brief/             SKILL.md, references/reference.md
  pipeline-pulse/         SKILL.md, references/reference.md
  lead-reengagement/      SKILL.md, references/reference.md
  segment-pattern/        SKILL.md, references/reference.md
  pipeline-review-deck/   SKILL.md, references/reference.md
```

## Skills included

| Skill | Purpose | D365 posture |
| --- | --- | --- |
| `sales-concierge` | Meta-router: "what can you do", "which skill" | No access |
| `sales-leader-360` | Monday-ready weekly sales operating brief | Read-only |
| `deal-brief` | Executive one-page brief for one account, opportunity, or meeting | Read-only |
| `pipeline-pulse` | Pipeline hygiene sweep with approval-gated field fixes | Read; writes only via approval |
| `lead-reengagement` | Quiet-lead ledger and re-engagement drafts held for approval | Read-only |
| `segment-pattern` | Segment and territory performance patterns (deals, never sellers) | Read-only |
| `pipeline-review-deck` | Turns Leader 360 or deal briefs into a PowerPoint via the built-in PowerPoint skill | Read-only |

Only `pipeline-pulse` proposes Dynamics 365 record updates. Candidate expansions not yet in the
package because they add automation or a second write path: `deal-signal-watch` (event-driven
email/Teams trigger) and `meeting-to-crm` (meeting recap to D365 activity log).

## Plugin prerequisites

- Copilot Cowork enabled for target users with Microsoft 365 Copilot licenses.
- Dataverse MCP server enabled on the approved Sales environment; tenant Dataverse-in-Copilot
  setting scoped to the pilot group; users hold Dynamics 365 Sales licenses and security roles.
- Sales plugin turned on by each user (**Customize > Plugins > Installed > Sales**) and the approved
  environment selected on the first sales prompt.
- Desktop or web Cowork: custom skills and plugins are not available on Cowork mobile.

## Benefit and evaluation notes (moved out of frontmatter)

| Skill | Benefit hypothesis | What the pilot measures |
| --- | --- | --- |
| `sales-leader-360` | 3 hrs/week saved; 100% material movement surfaced | Record-link coverage; on-time scheduled runs |
| `deal-brief` | 45 min/meeting saved | Brief structure completeness; confirmation gate stated |
| `pipeline-pulse` | 2 hrs/week saved; hygiene fixed before review | Definition fidelity; 0 unapproved commits |
| `lead-reengagement` | Quiet leads re-engaged within the week | Draft quality; 0 unapproved sends |
| `segment-pattern` | Pattern surfaced before the monthly review | Deals-only output; no seller comparison |
| `pipeline-review-deck` | Review deck in minutes, not hours | Deck matches source brief; nothing shared without approval |

Cowork evaluates every custom skill automatically (Skill Report: trigger clarity, instruction
specificity, scope boundaries, robustness; safety/RAI, trust-and-safety, and conflict gates).
Target band: Good or Excellent, with all gates passed, before sharing.

## Packaging rule

Upload the ZIP built from the contents of this folder. The ZIP must open directly to
`manifest.json`, `color.png`, `outline.png`, and `skills/`. Do not zip each skill separately.

Manifest version: this package keeps `devPreview` (what `atk import` emits and what the Cowork
admin documentation shows). If your upload channel requires `1.28` or `1.29`, change
`manifestVersion` and `$schema` only; no other fields need to change. Validate before upload with
`wiqd plugin validate --mode deep` if the wiqd CLI is available.

## Distribution options

| Option | When |
| --- | --- |
| Customize > Skills > Upload skill, then Share > Specific users | Small pilots; fastest; per-skill Re-share on updates |
| Customize > Plugins > Upload plugin, Share: Only you | Author end-to-end test |
| Admin center > Manage apps > Upload custom app > ... > Add agent, targeted to a security group | Tenant pilot |

## Safety posture

All skills are review-first. They may draft briefs, worklists, dashboards, decks, and
recommendations, but they must not send, post, publish, share, create tasks, update Dynamics 365
records, or change calendars without explicit user confirmation through Cowork's approval dialog.
Output reports business records, never rankings or ratings of people. Skills report the selected
Dynamics 365 environment and never change it; the user changes it with
`Set environment to [environment name]`.
