# Deal brief reference

## Brief layout

| Section | Purpose |
| --- | --- |
| Status line | Stage, value, close date, owner, record link, environment |
| One-line read | The honest single-sentence position of the deal |
| Stakeholders | Who matters, their role, last touch, who is missing |
| Momentum | What changed in the last 30 days, with sources |
| Signals, risks, gaps | Competitive, pricing, and risk evidence and what it implies |
| Open items | Commitments in both directions with owners and dates |
| Talking points and ask | What to say and the one thing to request |

## Disambiguation flow

1. Exact record match: proceed.
2. Multiple matches: list name, stage, value, close date, record link; ask the user to choose.
3. No match: say so, show closest names, ask for the account number or record link.

Never proceed on a guessed record.

## Evidence rules

| Claim type | Required backing |
| --- | --- |
| Deal facts (stage, value, dates, owner) | Dynamics 365 record link |
| Interaction claims | Named email, meeting, or Teams source with date |
| Competitive or pricing signals | Quoted or referenced evidence; marked inferred if indirect |
| Missing stakeholder | Role expected for this stage with no contact or touch recorded |
| Anything without backing | Omit, or state as an open question |

## Confirmation gate

Applies to: logging notes or activities, updating any record field, sending any follow-up.

Before commit, show the exact record and field changes or the exact message and recipients, plus
a private-data warning when content derives from mail, chat, calendar, or files. Cowork's own
approval dialog then appears. Default state: nothing committed, nothing sent.
