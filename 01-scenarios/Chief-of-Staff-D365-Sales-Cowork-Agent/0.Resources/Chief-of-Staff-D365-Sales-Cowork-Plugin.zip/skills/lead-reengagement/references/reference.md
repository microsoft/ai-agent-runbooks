# Lead re-engagement reference

## Definitions

| Term | Definition |
| --- | --- |
| Quiet lead | Open lead with at least one outbound touch and no inbound reply for 14 or more days (configurable) |
| Last touch | Most recent email, call, meeting, or note on the lead record or in Outlook/Teams |
| Context | Stated interest, objection, or next step recorded on the lead or in the last thread |

Excluded: disqualified leads, leads converted to opportunities, leads outside the user's scope.

## Angle rules

| Context found | Angle pattern |
| --- | --- |
| Stated interest in a capability | Share a specific proof point for that capability |
| Objection recorded | Address the objection with new evidence or an alternative |
| No reply to a proposal | Offer a lighter next step (short call, trial, reference) |
| No context at all | Mark inferred; propose a value-first check-in, not a chase |

One angle per lead. Never more than one draft per lead per pass.

## Send gate

1. Show recipient, subject, and full body.
2. Wait for approve, edit, or dismiss per message.
3. Cowork's approval dialog follows; the user approves per send during the pilot.
4. Default state: nothing sent.
