# Pipeline pulse reference

## Hygiene definitions

| Ledger | Definition |
| --- | --- |
| Slipped | Open opportunity whose estimated close date moved later during the reporting week (Monday through Sunday); carries a "why" column with evidence or "no evidence found" |
| Stalled | Open opportunity with no activity (email, meeting, task, note) for 14 or more days |
| Missing or aging next step | Next-step field empty, or unchanged for 21 or more days |
| Closing soon, untouched | Estimated close date within 14 days and no activity for 7 or more days |

Excluded: leads (see `lead-reengagement`), on-hold opportunities, and deals below the configured
value threshold (summarized, not itemized).

## Parameters

Take values stated in the prompt first. Otherwise ask once in an interactive run, or use the
defaults below in a scheduled run, and state the values used.

| Parameter | Default |
| --- | --- |
| Horizon | Current and next quarter |
| Value threshold | Ask / state "not configured" |
| Batch cap | 10 proposed record updates per pass |
| Permitted fields | Next step, estimated close date |
| Aging thresholds | 14 / 21 / 14+7 days as above |

## Prioritization

Order by: (1) estimated value, (2) close-date proximity, (3) number of overlapping ledgers.

## Write approval gate

1. Show the exact record, field, old value, and new value, or the exact message and recipient.
2. Wait for approve, edit, or dismiss per item; batch approval only after the full batch is
   displayed. Cowork's own approval dialog follows for each Dataverse write.
3. Commit only approved items; report the committed list with record links.
4. Default state: nothing committed, nothing sent.

## People-safety rule

Output reports deals and deal facts. It never ranks, rates, scores, or compares sellers, never
analyzes individual working patterns, and never frames hygiene gaps as personal performance.
