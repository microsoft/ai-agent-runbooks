# Pipeline review deck reference

## Deck map

| Source brief | Slides |
| --- | --- |
| `sales-leader-360` | Title (window, environment, RAG) · Executive summary · Pipeline KPIs · Movement · Slipped and stalled · Deal risks · Asks · First moves · Source gaps |
| `deal-brief` | Title (deal, environment) · Status and one-line read · Stakeholders and gaps · Momentum · Signals and risks · Open items · Talking points and ask · Source gaps |
| `pipeline-pulse` | Title · Sweep summary · Priority worklist · Slipped (with why) · Stalled · Next steps · Closing soon · Definitions and gaps |
| `segment-pattern` | Title · Segment table · Pattern · Actions · Source gaps |

## Notes rules

- Every slide that states a deal fact carries the Dynamics 365 record link in speaker notes.
- Source gaps and confidence notes go on their own slide, never dropped.
- No per-seller content, even if the user asks to "add the team view".

## Sharing gate

Show recipients or destination and the deck filename; Cowork's approval dialog follows. Default
state: not shared.
