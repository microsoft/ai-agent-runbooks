# Sales concierge reference

## Routing authority

| Signal in the user's ask | Route to |
| --- | --- |
| "week", "Monday", "leadership", pipeline-wide view, "since <date>" | `sales-leader-360` |
| A named account, opportunity, customer, or meeting with an executive/one-page framing | `deal-brief` |
| "hygiene", "slipped", "stalled", "clean up", "next steps missing", fix-oriented asks | `pipeline-pulse` |
| "leads", "quiet", "stopped responding", "re-engage" | `lead-reengagement` |
| "segment", "territory", "region", "vertical", "underperforming", "pattern" | `segment-pattern` |
| "deck", "slides", "PowerPoint", "QBR", "pipeline review meeting" | `pipeline-review-deck` |
| Plain meeting prep, activity catch-up, prioritization with no executive format | Built-in Dynamics 365 Sales skills |
| Rep-level activity, performance, ranking | Not in package; state the people-safety rule |

Tie-break: a named account inside a weekly ask routes to `sales-leader-360` first; offer
`deal-brief` as the follow-on.

## Disambiguation question

"Do you want (a) the weekly leadership view, (b) an executive brief on one account or deal,
(c) a pipeline hygiene sweep, (d) quiet-lead re-engagement, (e) a segment pattern, or (f) a deck
from an existing brief?"

Ask only when the routing authority produces no single match.

## Scheduling guidance

| Skill | Stance |
| --- | --- |
| `sales-leader-360` | Offer Monday 08:00 local time; remind the user to confirm the remembered environment first |
| `pipeline-pulse` | Offer only if the user mentions a recurring pipeline review |
| `segment-pattern` | Offer monthly only if the user asks |
| Others | On demand |

## No-match handling

Say: "The Chief-of-staff-sales package does not cover that yet. Current menu: weekly brief,
one-deal brief, pipeline hygiene, lead re-engagement, segment pattern, review deck." Capture the
goal as a candidate expansion; do not improvise.
