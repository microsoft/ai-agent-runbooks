# Sales Leader 360 reference

## Operating model

| View | Purpose |
| --- | --- |
| Executive snapshot | What matters in the pipeline this week |
| Pipeline dashboard | Open value, movement, wins and losses, slipped and stalled ledgers |
| Sales leadership update | Outcome-first summary for CRO or skip-level consumption |
| Deal-risk lens | Watchlist, active saves, escalation candidates |
| Monday first moves | The first three to five actions that create commercial momentum |

## Pipeline metric definitions

| Metric | Definition |
| --- | --- |
| Open pipeline | Sum of estimated value of open opportunities with estimated close date in the horizon; excludes leads and on-hold opportunities |
| Pipeline movement | Opportunities whose stage, estimated value, or estimated close date changed in the reporting window |
| Slipped deal | Open opportunity whose estimated close date moved later in the reporting window |
| Stalled deal | Open opportunity with no activity (email, meeting, task, note) for 14 or more days |
| Bookings | Opportunities set to Won in the window, at final amount |
| Deal-value threshold | Report movement at or above the configured threshold; summarize the rest |

## Parameters

Take values stated in the prompt first (for scheduled runs, the prompt text is the carrier).
Otherwise ask once in an interactive run, or use the defaults below in a scheduled run, and
state the values used in the output.

| Parameter | Default |
| --- | --- |
| Reporting window | Previous Monday 00:00 through Sunday 23:59 |
| Deal-value threshold | Ask / state "not configured" |
| Currency | Environment default |
| Key-account list | None (state "not configured") |

## RAG model

| RAG | Meaning | Typical signals |
| --- | --- | --- |
| Green | Under control | Movement explained, coverage adequate, no material unmitigated risk |
| Amber | Needs active management | Multiple slips, growing stalled ledger, coverage gap forming |
| Red | Needs intervention | Must-win slipping, quarter coverage broken, decision stalled above threshold |

## Deal-risk thresholds

| Level | Description | Handling |
| --- | --- | --- |
| Watchlist | Could slip; owner and next step plausible | Keep in dashboard |
| Active save | At-risk deal with a save plan underway | Leadership update risks |
| Escalation candidate | Needs sponsor, pricing decision, resource, or cross-team unblock | Formal callout |

## Dashboard layout

1. Hero bar: window, environment, overall RAG, one-line summary
2. KPI cards: open value by quarter, movement, wins, losses, slipped count, stalled count
3. Movement ledger with record links
4. Slipped and stalled ledgers
5. Week-ahead key-account moments
6. Deal-risk lens
7. Monday first moves
8. Source gaps and confidence notes

## Leadership update style

| Weak | Better |
| --- | --- |
| "Worked the Contoso deal." | "Contoso close risk reduced after pricing approval unblocked the proposal." |
| "Pipeline changed a bit." | "Q3 open value fell 6% as two deals above threshold slipped to Q4; save plans are owned." |
| "Waiting on legal." | "Fabrikam signature blocked until legal confirms clause 7 by Thursday." |

## Sharing gate

Default state: not sent. Before any sharing or action, show exact recipients, exact content, and
a private-data warning if the message uses calendar, mail, chat, or file content. Cowork's own
approval dialog then appears; the user should approve per action during the pilot.
