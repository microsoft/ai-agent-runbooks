# Segment pattern reference

## Metrics

| Metric | Definition |
| --- | --- |
| Open value | Sum of estimated value of open opportunities in the period horizon |
| Won / Lost | Count and value of opportunities closed Won / Lost in the period |
| Win rate | Won / (Won + Lost) by count |
| Slip rate | Share of open opportunities whose close date moved later in the period |
| Average deal | Mean estimated value of won opportunities |
| Average cycle | Mean days from creation to Won |
| Engagement gap | Share of open opportunities with no activity for 14 or more days |

## Comparison rules

- Compare each segment to its own prior period and to the median of the other segments.
- Call a segment underperforming only when at least two metrics are below both comparators.
- Name the top three deals driving the segment's numbers, with record links.

## Small-sample rule

Flag any segment with fewer than five closed opportunities in the period; do not state a pattern
for it, only the observation.

## Excluded dimensions

Owner, seller, team member, or any person attribute. If the requested dimension is a person,
decline and state the people-safety rule.
