# Chief of Staff Sales - Cowork custom skills (v1.1.1)

Seven skills that extend the Dynamics 365 Sales plugin's built-in skills (meeting preparation,
activity synthesis, pipeline prioritizer) with executive-ready, record-linked, review-first
outputs. See the plugin package README for the full change log, benefit notes, and safety posture.

## Install options

| Option | Steps |
| --- | --- |
| Upload and share (recommended for pilots) | Cowork > Customize > Skills > Add (arrow) > Upload skill. Upload each skill folder as a .zip with SKILL.md at its root plus references/. Then Share > Specific users; Re-share on updates. Delete the old copy before re-uploading a changed skill. |
| OneDrive | Copy each skill folder to /Documents/Cowork/skills/<skill-name>/. Cowork discovers skills at the start of the next session. |

Custom skills run on Cowork desktop and web only.

## Before first use

1. Turn on the Sales plugin: Customize > Plugins > Installed > Sales toggle.
2. Enter a sales prompt; on first use Cowork asks which Dynamics 365 environment to use and
   remembers it. Confirm with `list environments`; change with `Set environment to [name]`.
3. Pass pilot parameters (environment name, deal-value threshold, currency, key-account list)
   in the prompt, including scheduled-prompt text. Org-wide defaults live in each skill's
   references/reference.md Parameters table.

## Skills

| Skill | Purpose | D365 posture |
| --- | --- | --- |
| sales-concierge | Package meta-router | No access |
| sales-leader-360 | Weekly operating brief | Read-only |
| deal-brief | Executive one-page deal brief | Read-only |
| pipeline-pulse | Hygiene sweep with approval-gated fixes | Read; writes via approval only |
| lead-reengagement | Quiet leads and outreach drafts | Read-only; sends via approval only |
| segment-pattern | Segment/territory patterns, deals only | Read-only |
| pipeline-review-deck | PowerPoint from a package brief | Read-only |
