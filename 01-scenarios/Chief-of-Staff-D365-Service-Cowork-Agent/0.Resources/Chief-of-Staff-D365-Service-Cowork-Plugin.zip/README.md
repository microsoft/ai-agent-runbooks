# Chief of Staff Service Cowork Plugin (v1.0.0)

Seven Cowork custom skills that extend the **Service** plugin (Dynamics 365 Customer Service) and
its built-in skills (case enrichment, customer-ready response drafting, incident resolution) with
leader-level, record-linked, review-first outputs. The built-in skills work one case at a time for
the representative; this package works at queue, account, and leadership level for the service
leader and their chief of staff. It is independent of the Chief of Staff Sales package.

## Contents

```text
manifest.json
color.png                   192x192
outline.png                 32x32
skills/
  service-concierge/        SKILL.md, references/reference.md
  service-leader-360/       SKILL.md, references/reference.md
  escalation-brief/         SKILL.md, references/reference.md
  queue-pulse/              SKILL.md, references/reference.md
  queue-pattern/            SKILL.md, references/reference.md
  knowledge-gap-pattern/    SKILL.md, references/reference.md
  service-review-deck/      SKILL.md, references/reference.md
```

## Skills

| Skill | Purpose | D365 posture |
| --- | --- | --- |
| `service-concierge` | Meta-router: "what can you do", "which skill" | No access |
| `service-leader-360` | Monday-ready weekly service operating brief | Read-only |
| `escalation-brief` | Leadership brief on one escalated case or one account's service situation | Read-only |
| `queue-pulse` | Queue hygiene sweep with approval-gated field fixes | Read; writes only via approval |
| `queue-pattern` | Performance pattern by queue, product, channel, or region (never agents) | Read-only |
| `knowledge-gap-pattern` | Recurring case themes with no knowledge coverage; KB outlines held for review | Read-only |
| `service-review-deck` | PowerPoint from any package brief via the built-in PowerPoint skill | Read-only |

Only `queue-pulse` proposes Dynamics 365 record updates. Candidate expansions not in 1.0.0:
`case-signal-watch` (event-driven email/Teams trigger on named accounts) and `incident-comms`
(customer-facing updates during major incidents); each adds automation or outbound risk.

## Design rules shared by every skill

- **Handoff to built-in skills.** Each skill names the built-in Customer Service skill it consumes
  and states which prompts belong to the built-in skill (one-case brief, one-case escalation
  summary, one-case reply drafting, one-case re-engagement). This satisfies Cowork's conflict scan.
- **Environment.** Cowork asks for the Dynamics 365 environment on the user's first service prompt
  and remembers it; the user changes it with `list environments` or
  `Set environment to [environment name]`; an administrator can configure a default. Skills name
  the environment in the output header, stop on a mismatch, and never change it.
- **Parameters** come from the prompt first (scheduled-prompt text for Monday runs), then a
  one-time ask, then the defaults in `references/reference.md`.
- **People safety.** Output reports cases, queues, and accounts; it never ranks, rates, or
  compares agents, even when asked.
- **Approval.** Record updates and sends are previewed, then approved in Cowork's own dialog;
  pilot users do not select "Always allow" for Dataverse updates or sends.
- **Mobile.** Custom skills and plugins run on Cowork desktop and web only.

## Prerequisites

- Cowork enabled and licensed for target users.
- Tenant setting Copilot > Settings > Dataverse data available in Microsoft 365 Copilot scoped to
  the pilot group; Dataverse MCP server enabled on the approved Customer Service environment.
- Users hold Dynamics 365 Customer Service licences and service security roles.
- Service plugin switched on by each user (Customize > Plugins > Installed > Service).

## Packaging and distribution

Upload the ZIP built from this folder (opens at `manifest.json`). Manifest version stays
`devPreview`; switch `manifestVersion` and `$schema` to 1.28 or 1.29 only if your upload channel
requires it. Validate with `wiqd plugin validate --mode deep` when the CLI is available.

| Option | When |
| --- | --- |
| Customize > Skills > Add > Upload skill, then Share > Specific users | Small pilots; Re-share on updates |
| Customize > Plugins > Add plugin, Share: Only you | Author end-to-end test |
| Admin center > Manage apps > Upload custom app > ... > Add agent, targeted to a security group | Tenant pilot |

## Benefit hypotheses

| Skill | Hypothesis | Pilot measure |
| --- | --- | --- |
| `service-leader-360` | 3 hrs/week saved; all material backlog movement surfaced | Record-link coverage; on-time Monday runs |
| `escalation-brief` | 45 min per escalation saved | Structure completeness; one decision asked |
| `queue-pulse` | SLA breaches caught before review | 0 unapproved commits; definitions fidelity |
| `queue-pattern` | Pattern surfaced before monthly review | Queues-only output |
| `knowledge-gap-pattern` | Top recurring theme has a KB draft within the week | Outlines grounded in cited cases |
| `service-review-deck` | Review deck in minutes | Deck matches source brief |
