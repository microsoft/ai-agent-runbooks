# Escalation brief reference

## Brief layout

| Section | Purpose |
| --- | --- |
| Status line | Status, priority, SLA, owner, queue, record link, environment |
| One-line read | Honest single-sentence position |
| Exposure | Why this matters beyond the one case |
| Timeline and tried | What happened, what was attempted, with sources |
| Stakeholders | Who matters on both sides, who is missing |
| Risks and commitments | What could go wrong; what has been promised |
| Decision requested | The one decision, with options and consequences |

## Disambiguation flow

1. Exact case, incident, or account match: proceed.
2. Multiple matches: list number, title, status, priority, account, record link; ask.
3. No match: say so, show closest names, ask for the case number or record link.

Never proceed on a guessed record.

## Exposure checklist

| Check | Evidence source |
| --- | --- |
| Entitlement and SLA tier | Case and account records |
| Linked and prior cases (12 months) | Service plugin |
| Repeat issue or known defect | Incident record, knowledge base |
| Commercial context (renewal, open opportunity) if visible | Account record |
| Regulatory, safety, or data-protection flag | Case category, notes |
| Executive or press attention | Mail and Teams signals |

## Evidence rules

| Claim type | Required backing |
| --- | --- |
| Case facts | Dynamics 365 record link |
| Interaction claims | Named email, meeting, or Teams source with date |
| Exposure claims | Record evidence; marked inferred if indirect |
| Missing stakeholder | Role expected for this stage with no contact or touch recorded |
| Anything without backing | Omit, or state as an open question |

## Confirmation gate

Applies to: notes, field updates, customer messages, internal posts. Show the exact change or
message and recipients, with a private-data warning when content derives from mail, chat,
calendar, or files. Cowork's approval dialog follows. Default state: nothing committed, nothing
sent.
