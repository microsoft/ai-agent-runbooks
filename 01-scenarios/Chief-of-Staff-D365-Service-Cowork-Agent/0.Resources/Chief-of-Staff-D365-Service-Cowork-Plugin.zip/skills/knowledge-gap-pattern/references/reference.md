# Knowledge gap pattern reference

## Parameters

| Parameter | Default |
| --- | --- |
| Period | Last 30 days |
| Scope | All queues and products the user can see |
| Minimum theme size | 5 cases |
| Stale article | Not modified in 180 days or in draft/expired state |

## Coverage states

| State | Definition |
| --- | --- |
| None | No published article matches the theme |
| Stale | A matching article exists but is stale per the parameter above |
| Unlinked | A current article exists but was linked to fewer than 25% of the theme's cases |
| Covered | Current article linked to 25% or more of cases (not reported as a gap) |

## Ranking

Order by: (1) case volume, (2) median resolution effort, (3) reopen rate. Incident-driven themes
are listed separately and not ranked as knowledge gaps.

## Outline template

```markdown
# <Article title> (DRAFT - not published)
Symptoms: <from case titles and descriptions>
Applies to: <product / version / channel>
Cause: <from resolutions; "unconfirmed" if cases disagree>
Resolution steps: <numbered, from recorded resolutions>
Open questions: <steps not evidenced in any case>
Cited cases: <record links, no customer identifiers>
```
