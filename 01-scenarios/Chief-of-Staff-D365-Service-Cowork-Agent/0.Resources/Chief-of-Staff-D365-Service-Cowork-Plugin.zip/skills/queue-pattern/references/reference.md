# Queue pattern reference

## Metrics

| Metric | Definition |
| --- | --- |
| Inflow | Cases created in the period |
| Backlog | Active cases at period end |
| Median resolution | Median hours from creation to resolution for cases resolved in the period |
| SLA attainment | Share of SLA KPI instances met among those due in the period |
| Reopen rate | Reactivated / resolved in the period |
| Waiting-on-customer share | Share of active cases in "waiting on customer" at period end |
| Escalation rate | Escalated / created in the period |

## Comparison rules

- Compare each value to its own prior period and to the median of the other values.
- Call a value underperforming only when at least two metrics are worse than both comparators.
- Name the top three cases or incidents driving the value's numbers, with record links.
- If an open incident explains a spike, say so before stating any pattern.

## Small-sample rule

Flag any value with fewer than 20 cases in the period; state the observation, not a pattern.

## Excluded dimensions

Owner, agent, team member, or any person attribute. If the requested dimension is a person,
decline and state the people-safety rule.
