# Queue pulse reference

## Hygiene definitions

| Ledger | Definition |
| --- | --- |
| SLA breached | Active case with any SLA KPI instance past its target |
| SLA at risk | Active case within 20% of an SLA KPI target with no resolution |
| Aging | Active case older than 10 days |
| Waiting on customer | Status reason "waiting on customer" for 48 or more hours |
| Unowned / no next action | No owner, or follow-up-by date empty or in the past by more than 2 days |
| Reopened | Case reactivated in the last 7 days |

Excluded: cases linked to an open incident (reported, not nudged), cases outside the user's
queues, resolved or cancelled cases.

## Parameters

Take values stated in the prompt first. Otherwise ask once in an interactive run, or use the
defaults below in a scheduled run, and state the values used.

| Parameter | Default |
| --- | --- |
| Queues in scope | All queues the user can see |
| Priorities in scope | All |
| Batch cap | 10 proposed record updates per pass |
| Permitted fields | Priority, follow-up by, queue |
| Aging / waiting / at-risk thresholds | 10 days / 48 hours / 20% of target |

## Prioritization

Order by: (1) SLA state (breached, then at risk), (2) case priority, (3) customer tier if
visible, (4) number of overlapping ledgers.

## Write approval gate

1. Show the exact record, field, old value, and new value, or the exact nudge and recipient.
2. Wait for approve, edit, or dismiss per item; batch approval only after the full batch is
   displayed. Cowork's approval dialog follows for each Dataverse write.
3. Commit only approved items; report the committed list with record links.
4. Default state: nothing committed, nothing sent.

## People-safety rule

Output reports cases and queues. It never ranks, rates, scores, or compares agents, never
analyzes individual workload or handling patterns, and never frames hygiene gaps as personal
performance.
