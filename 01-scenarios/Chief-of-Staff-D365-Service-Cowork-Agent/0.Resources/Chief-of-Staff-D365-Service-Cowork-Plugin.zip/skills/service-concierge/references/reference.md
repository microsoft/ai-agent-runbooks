# Service concierge reference

## Routing authority

| Signal in the user's ask | Route to |
| --- | --- |
| "week", "Monday", "leadership", backlog-wide view, "since <date>" | `service-leader-360` |
| A named account or escalated case with executive, exposure, or decision framing | `escalation-brief` |
| "hygiene", "aging", "SLA at risk", "waiting on customer", "clean up the queue" | `queue-pulse` |
| "queue", "product", "channel", "region", "underperforming", "pattern" | `queue-pattern` |
| "knowledge gap", "recurring", "no article", "what keeps coming back" | `knowledge-gap-pattern` |
| "deck", "slides", "PowerPoint", "service review meeting", "QBR" | `service-review-deck` |
| One-case brief, escalation summary for the next owner, reply from article, one-case re-engagement | Built-in Customer Service skills |
| Agent-level activity or performance | Not in package; state the people-safety rule |

Tie-break: a named account inside a weekly ask routes to `service-leader-360` first; offer
`escalation-brief` as the follow-on.

## Disambiguation question

"Do you want (a) the weekly leadership view, (b) a leadership brief on one escalation or account,
(c) a queue hygiene sweep, (d) a queue or channel pattern, (e) knowledge gaps, or (f) a deck from
an existing brief?"

## Scheduling guidance

| Skill | Stance |
| --- | --- |
| `service-leader-360` | Offer Monday 08:00; remind the user to confirm the remembered environment first |
| `queue-pulse` | Offer only if a recurring backlog review is mentioned |
| Others | On demand |

## No-match handling

Say: "The Chief-of-staff-service package does not cover that yet. Current menu: weekly brief,
escalation brief, queue hygiene, queue pattern, knowledge gaps, review deck." Capture the goal as
a candidate expansion; do not improvise.
