# Service Leader 360 reference

## Operating model

| View | Purpose |
| --- | --- |
| Executive snapshot | What matters in the backlog this week |
| Backlog dashboard | Open, inflow, resolved, reopened, aging, SLA at risk and breached |
| Service leadership update | Outcome-first summary for the service VP or skip level |
| Risk lens | Watchlist, active saves, escalation candidates |
| Monday first moves | The first three to five actions that reduce customer exposure |

## Metric definitions

| Metric | Definition |
| --- | --- |
| Open backlog | Count of active cases in queues in scope, by priority |
| Inflow / resolved / reopened | Cases created, resolved, and reactivated in the window |
| Aging case | Active case older than 10 days (configurable) |
| Waiting on customer | Active case with status "waiting on customer" for 48 or more hours |
| SLA at risk | Active case within 20% of its SLA KPI target with no resolution |
| SLA breached | Active case past its SLA KPI target |
| Escalation | Case flagged escalated, or routed to an escalation queue, in the window |
| Incident | Parent case or incident record with linked child cases |

## Parameters

Take values stated in the prompt first (for scheduled runs, the prompt text is the carrier).
Otherwise ask once in an interactive run, or use the defaults below in a scheduled run, and
state the values used in the output.

| Parameter | Default |
| --- | --- |
| Reporting window | Previous Monday 00:00 through Sunday 23:59 |
| Queues in scope | All queues the user can see (state "all") |
| Key-account list | None (state "not configured") |
| Aging threshold | 10 days |
| Waiting-on-customer threshold | 48 hours |
| SLA at-risk margin | 20% of target |

## RAG model

| RAG | Meaning | Typical signals |
| --- | --- | --- |
| Green | Under control | Backlog flat or falling, SLA breaches isolated, no open incident |
| Amber | Needs active management | Backlog rising, breaches clustering in a queue, escalation count up |
| Red | Needs intervention | Open incident with key-account exposure, SLA failing in a queue, unresolved escalation above threshold |

## Risk thresholds

| Level | Description | Handling |
| --- | --- | --- |
| Watchlist | Could breach or escalate; owner and next action plausible | Dashboard |
| Active save | Escalated case with a recovery plan underway | Leadership update |
| Escalation candidate | Needs sponsor, credit or policy decision, engineering fix, or cross-team unblock | Formal callout |

## Dashboard layout

1. Hero bar: window, environment, overall RAG, one-line summary
2. KPI cards: open backlog, inflow, resolved, reopened, SLA at risk, SLA breached, open escalations
3. Backlog movement by queue
4. Aging and waiting-on-customer ledgers
5. Escalations and incidents
6. Key-account exposure
7. Monday first moves
8. Source gaps and confidence notes

## Leadership update style

| Weak | Better |
| --- | --- |
| "Worked the Contoso cases." | "Contoso exposure reduced after the firmware fix closed 14 linked cases." |
| "Backlog changed a bit." | "Billing queue backlog rose 18% as inflow doubled after the invoice run; two SLA breaches." |
| "Waiting on engineering." | "Fabrikam escalation blocked until engineering confirms the patch date by Thursday." |

## Sharing gate

Default state: not sent. Before any sharing or action, show exact recipients, exact content, and
a private-data warning if content uses mail, chat, calendar, or file detail. Cowork's approval
dialog follows; approve per action during the pilot.
