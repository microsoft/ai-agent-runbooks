# Service review deck reference

## Deck map

| Source brief | Slides |
| --- | --- |
| `service-leader-360` | Title (window, environment, RAG) · Executive summary · Backlog and SLA KPIs · Movement by queue · Escalations and incidents · Key-account exposure · Asks · First moves · Source gaps |
| `escalation-brief` | Title (case/account, environment) · Status and one-line read · Exposure · Timeline and tried · Stakeholders and gaps · Risks and commitments · Decision requested · Source gaps |
| `queue-pulse` | Title · Sweep summary · Priority worklist · SLA ledger · Aging and waiting · Unowned and reopened · Definitions and gaps |
| `queue-pattern` | Title · Dimension table · Pattern · Actions · Source gaps |
| `knowledge-gap-pattern` | Title · Gap ledger · Top outlines · Source gaps |

## Notes rules

- Every slide stating a case fact carries the record link in speaker notes.
- Source gaps and confidence notes get their own slide, never dropped.
- No per-agent content.

## Sharing gate

Show recipients or destination and the filename; Cowork's approval dialog follows. Default
state: not shared.
