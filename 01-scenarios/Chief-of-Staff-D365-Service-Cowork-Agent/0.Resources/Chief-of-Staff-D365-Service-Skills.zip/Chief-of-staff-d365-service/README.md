# Chief of Staff Service - Cowork custom skills (v1.0.1)

Seven skills that extend the Service plugin (Dynamics 365 Customer Service) and its built-in
skills (case enrichment, customer-ready response drafting, incident resolution) with leader-level,
record-linked, review-first outputs. See the plugin package README for the full design rules,
benefit notes, and safety posture.

## Install options

| Option | Steps |
| --- | --- |
| Upload and share (recommended for pilots) | Cowork > Customize > Skills > Add (arrow) > Upload skill. Upload each skill folder as a .zip with SKILL.md at its root plus references/. Then Share > Specific users; Re-share on updates. Delete the old copy before re-uploading a changed skill. |
| OneDrive | Copy each skill folder to /Documents/Cowork/skills/<skill-name>/. Discovered at the next session. |

Custom skills run on Cowork desktop and web only.

## Before first use

1. Turn on the Service plugin: Customize > Plugins > Installed > Service toggle.
2. Enter a service prompt; on first use Cowork asks which Dynamics 365 environment to use and
   remembers it. Confirm with `list environments`; change with `Set environment to [name]`.
3. Pass pilot parameters (environment name, queues, key accounts, thresholds) in the prompt,
   including scheduled-prompt text. Org-wide defaults live in each skill's
   references/reference.md Parameters table.

## Skills

| Skill | Purpose | D365 posture |
| --- | --- | --- |
| service-concierge | Package meta-router | No access |
| service-leader-360 | Weekly operating brief | Read-only |
| escalation-brief | Leadership brief on one escalation, incident, or account | Read-only |
| queue-pulse | Hygiene sweep with approval-gated fixes | Read; writes via approval only |
| queue-pattern | Queue/product/channel/region patterns, cases only | Read-only |
| knowledge-gap-pattern | Recurring themes without articles; outlines held for review | Read-only |
| service-review-deck | PowerPoint from a package brief | Read-only |
