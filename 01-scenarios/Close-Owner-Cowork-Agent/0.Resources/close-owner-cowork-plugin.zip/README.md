# The Close Owner Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Close Owner (Controller / FP&A Lead / Finance Partner) · **Function:** Finance & Operations
**Runbook:** `cowork-close-owner-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  close-owner-concierge/
    SKILL.md
    reference.md
  weekly-business-review/
    SKILL.md
    reference.md
  close-and-variance-package/
    SKILL.md
    reference.md
  budget-consolidation/
    SKILL.md
    reference.md
  reconciliation-review/
    SKILL.md
    reference.md
  audit-evidence-package/
    SKILL.md
    reference.md
  market-intelligence/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `close-owner-concierge` | Routes the user to the right Close Owner skill |
| `weekly-business-review` | Prepares a leadership-ready weekly business review for a business area by combining a governed Power BI dashboard (Fabric IQ) with recent email, Teams, and review-meeting updates; compares week over week and to plan; and flags the most important changes, ahead- and behind-plan areas, risks, decisions needed, and stalled actions |
| `close-and-variance-package` | Builds a month-end or quarter-end close package and board-ready variance narrative by tying out ledger and trial-balance data across entities, reading close-calendar status and team commentary, and explaining every material swing versus prior period, budget, and forecast |
| `budget-consolidation` | Drives the annual or quarterly budget cycle: tracks which submissions are received, late, or missing against the budget calendar, drafts chase reminders, validates and consolidates inputs across cost centers and entities with formulas, compares them to targets, prior year, and forecast, flags variance issues before review, and prepares a decision packet |
| `reconciliation-review` | Performs a reconciliation and exception review across two or more sources (GL vs |
| `audit-evidence-package` | Assembles an audit evidence and workpaper package by mapping each item on an auditor's request list (PBC list) to supporting evidence in files, mail, Teams, and finance systems, summarizing workpapers, and making missing or weak support visible before the auditor review |
| `market-intelligence` | Runs a scheduled weekly market intelligence monitoring and action workflow (saved in the deck as "Market Competition Analyzer") across market data, news, competitor sites, analyst research, filings, internal research, and email and Teams; identifies material changes since the last review, their impact, and the plan or assumption they affect |

Start with `close-owner-concierge` if you are not sure which skill to use. Recommended starters: `weekly-business-review` and `close-and-variance-package`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
