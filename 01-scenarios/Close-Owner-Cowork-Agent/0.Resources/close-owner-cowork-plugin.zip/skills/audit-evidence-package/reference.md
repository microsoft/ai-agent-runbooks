# Audit Evidence Package reference

Customer-tunable settings for `audit-evidence-package`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Request list | [Audit Request List] | PBC list or auditor request workbook |
| Audit type | [Audit Type] | External financial, SOX/ICFR, internal audit, or tax |
| Period and entity | [Period], [Entity] | Scope of the audit |
| Evidence locations | [Evidence Locations] | SharePoint libraries and folders |
| Prior-year pack | [Prior-Year Pack] | For comparison and repeat findings |
| Control matrix | [Control Matrix] | RCM or control list, if controls-based |
| Request owners | [Request Owners] | Internal owner per area |
| Due dates and auditor contacts | [Due Dates], [Auditor Contacts] | Auditor contacts are never messaged without approval |
| Redaction rules | [Redaction Rules] | Payroll, legal, personal data handling |
| Time zone | [Time Zone] | For due-date math and schedule |
| Schedule | On receipt; weekly during fieldwork; quarterly for SOX | Per fieldwork plan |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Complete | Final, approved, correct period and entity; population ties to source | All checks pass |
| Partial | Evidence exists but outdated, wrong period, unsigned, or population does not tie | State the reason |
| Missing | No candidate evidence found | Name owner and exact item needed |
| Version preference | Final and approved over drafts | Flag if only drafts exist |
| Due-soon alert | [Due-Soon Days] before due date | Highlight in tracker |
| Population tie tolerance | Zero | Any difference is flagged |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Audit prep time | Hours from request list receipt to review-ready tracker | Time study | Audit readiness (prep time; add to baseline) |
| Evidence completeness | Requests Complete at first submission ÷ total requests | Tracker | Audit readiness |
| Review cycle time | Days from submission to auditor acceptance; follow-up requests count | Auditor correspondence | Audit readiness (follow-ups; add to baseline) |
| Late or missing PBC items | Requests past due or Missing at due date | Tracker | Audit readiness |

## Output templates

| Artifact | Layout |
| --- | --- |
| Request-to-evidence tracker (Excel) | Request ID, Description, Area, Owner, Due Date, Status, Evidence Links, Gap Description, Days to Due (formula), Prior-Year Finding; Summary tab with completion % by area (formulas) |
| Evidence index | Proposed folder structure and file naming by request ID (created only after approval) |
| Workpaper summary (Word) | One section per control/area: objective, procedure, evidence, results, exceptions, sign-off |
| Owner request | Request ID, item needed, period, due date, where to save |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Evidence locations, mail, Teams | Required | Mark affected requests Missing with a source-gap note |
| ERP reports and logs | Optional | List as a request to the system owner; never substitute other data |
| Fabric IQ / Power BI populations | Optional | Use provided population extracts; state date |

## Never-automate list

- Sending evidence, workpapers, or messages to auditors
- Uploading to auditor portals
- Sending owner requests
- Creating, editing, back-dating, or completing evidence
- Creating the evidence folder structure

## Sharing gate

Default state: not sent. Before any send, show exact recipients, files, content, redactions
applied, and a warning for payroll, legal, or personal data.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Heavy |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Build the audit pack for [Audit Type] for [Entity], [Period]. Take [Audit Request List], map
> each request to evidence in [Evidence Locations], email, and Teams, and mark each as Complete,
> Partial, or Missing with links. Summarize the workpapers by control area, compare to last year's
> pack, and flag missing or weak support with the owner and exact item needed. Give me an Excel
> tracker with formulas and draft requests to owners - don't send anything until I approve.
