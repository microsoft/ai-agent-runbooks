# Close and Variance Package reference

Customer-tunable settings for `close-and-variance-package`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Period | [Period] | e.g., FY26 P09 or Q3 close |
| Entity scope | [Entity] | Legal entities or consolidation group in scope |
| Trial balance source | [Trial Balance Source] | ERP extract, Power BI close model, or close workbook |
| Close model | [Close Model] | Fabric / Power BI semantic model for actuals and comparatives |
| Comparatives | Prior period, prior year, budget, latest forecast | Remove any the close policy does not use |
| Close checklist | [Close Calendar / Checklist] | Workbook with tasks, owners, due dates |
| Package folder | [Close Package Folder] | OneDrive / SharePoint location for prior narrative and flux template |
| Audience | [Audience] | CFO, audit committee, or board; sets depth and tone |
| Distribution list | [Close Distribution List] | Named recipients of pre-release results |
| Approver | [Controller] | Approves distribution and any recommended adjustment |
| Time zone | [Time Zone] | Used for close calendar and schedule |
| Schedule | Status pass BD 2-3; full package BD 4-5; quarterly board | Or per the close calendar |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Materiality threshold | [Materiality Threshold] (example: >$500K and >10%) | Default from the close policy if documented |
| Threshold logic | Absolute AND percentage | Switch to OR only if the close policy says so |
| Tie-out tolerance | Zero | Any difference is reported, never plugged |
| Driver categories | Volume, price, mix, FX, one-time, timing | Add customer categories as needed |
| Explanation status | Explained (cited) / Explanation required (owner) / Conflicting | Conflicting shows both sources |
| Reporting blockers | Accruals, intercompany, FX revaluation | Close tasks that block the package if open |
| Late task rule | Past due date on the close calendar | Report by task and owner of record |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Days to close | Business days from period end to close sign-off | Close calendar / sign-off record | Days to close |
| Report generation time | Hours from final TB to review-ready package | Time study / file version history | Close package report generation time |
| Variance explanation cycle time | Median time from variance flagged to cited explanation | Variance workbook, mail, Teams | Variance explanation cycle time |
| First-review explanation rate | Material variances explained with cited source ÷ material variances | Package review comments | Material variances explained at first review |

## Output templates

| Artifact | Layout |
| --- | --- |
| Close narrative (Word) | Executive summary; results vs. comparatives; material variances with sources; balance sheet highlights; close status; open items |
| Board summary (PowerPoint, 5-7 slides) | Headline results; variance bridge (waterfall); top drivers; risks and outlook; open items |
| Variance workbook (Excel) | TB Tie-out tab; Variance tab (Δ and Δ% formulas, materiality flag, explanation, driver, source, owner) |
| Open-items tracker | Item, Type (unexplained variance / late task), Owner, Due Date, Status |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Fabric IQ / Power BI close model | Required for model grounding | Work only from provided extracts; do not claim report-grounded analytics |
| ERP (Dynamics 365 Finance, SAP, Oracle) | Optional | Use the provided extract; state extract date and scope |
| Close checklist workbook | Required for status | Report close status as a source gap |
| Mail, Teams, meeting notes | Required for explanations | Mark variances "Explanation required" |

## Never-automate list

- Posting, reversing, or post-on-behalf journal entries
- Sending owner questions or the package to the CFO, audit committee, or board
- Posting close results to Teams channels
- Changing ledger, model, or checklist data

## Sharing gate

Default state: not sent. Before any share, show exact recipients, exact content, attachments, the
sensitivity label, and a warning that pre-release results may be material non-public information.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Heavy |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Draft the close package for [Period] for [Entity]. Use [Trial Balance Source] and compare to
> prior month, prior year, and budget. Tie out the TB, flag every variance above [Materiality
> Threshold], and explain each using commentary from recent emails, Teams threads, and close
> meetings - cite sources and mark anything unexplained with an owner. Give me a Word narrative, a
> 6-slide board summary with a variance bridge, and an Excel variance workbook with formulas. Show
> me drafts before anything goes out.
