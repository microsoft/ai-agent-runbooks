# Market Intelligence reference

Customer-tunable settings for `market-intelligence` (alias: Market Competition Analyzer). Settings
here may tighten, but never loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Business area | [Business Area] (default: sales) | Plan whose assumptions signals may affect |
| Competitors and topics | [Competitors] | Competitors, segments, topics to monitor |
| Internal research | [Research] | SharePoint site or folder with research notes and prior briefs |
| Prior brief | [Prior Brief] | Last week's HTML brief; none on first run |
| Plan assumptions | [Plan Assumptions] | Fabric / Power BI model or workbook (optional) |
| Teams channel | [Teams Channel] | Destination for the draft update |
| Decision owners | [Decision Owners] | Invitees for the decision review |
| Excluded sources | [Excluded Sources] | Sites or feeds not to use |
| Time zone | Pacific Time | Change for the customer region |
| Schedule | Every Monday 8:00 AM PT | Covers the prior week |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Materiality criteria | [Materiality Criteria] | Default categories: competitor price move, product move, guidance change, new entrant, regulatory change, supply disruption, analyst outlook shift |
| Impact threshold | [Impact Threshold] | Optional minimum sized impact to include |
| Confidence scale | Confirmed / Reported / Rumored | Confirmed = primary source (filing, company site) |
| Week-over-week status | New / Escalating / Resolved / Unchanged | Against [Prior Brief] |
| Decision-invite trigger | Signal requires leadership direction | 30-minute invite draft |
| Top actions | 3 | Number of planning actions recommended |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Research time saved | Hours per brief vs. baseline | Time study | Market research time |
| Decision speed | Days from signal raised to decision or planning action | Signal log | Leadership decision speed |
| Signals acted on | Material signals with a closed action ÷ material signals raised | Signal log | Signals acted on |
| Brief cadence met | Monday briefs delivered on schedule ÷ scheduled Mondays | Automations history | Signals acted on (cadence; add to baseline) |

## Output templates

| Artifact | Layout |
| --- | --- |
| HTML brief | Hero line; Market shifts; Competitor moves; Business implications; Recommended actions; week-over-week table; sources with URLs and timestamps |
| Top-3 planning actions | Signal, Action, Affected assumption, Suggested owner, Timing |
| Teams update | 3-5 lines: headline signals, recommended actions, link to brief |
| Decision-review invite | 30 minutes; decision question; evidence links; agenda |
| Signal log (Excel, optional) | Date, Signal, Category, Source/URL, Confidence, Impact (formula), Affected Assumption, Action, Owner, Status |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Public web search | Required | Run from internal research only and say so |
| Premium or paywalled sources | Optional | State unavailable; do not infer values |
| Fabric IQ / Power BI plan assumptions | Optional | Mark "Impact not quantified" |
| Internal research, mail, Teams | Required | List as source gap |

## Never-automate list

- Posting the Teams update
- Sending the decision-review invite
- Distributing the brief
- Changing forecasts or plans; executing trades or hedges
- Contacting competitors, suppliers, or other external parties

## Sharing gate

Default state: not posted, not sent. Before any post or send, show the exact channel or
recipients, content, and a warning when internal non-public data is included.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium |
| License-only starter (USL) | Researcher one-off brief (single, unscheduled brief to validate sources and format) |
| Cowork (UBB) | Scheduled Monday run, multi-source monitoring, week-over-week brief, top-3 actions, approval-gated update and invite |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Monitor market and competitor developments affecting [Business Area] sales during the last week.
> Use public market data, current news and web sources, competitor websites for [Competitors],
> analyst research, SEC or company filings, internal research in [Research], and relevant recent
> emails and Teams discussions. Identify what changed since the previous review, focusing on
> material signals. For each, capture what changed and the evidence, the potential financial or
> operational impact, the assumption or plan it may affect, and the recommended response and
> timing. Create a concise HTML brief organized into Market shifts, Competitor moves, Business
> implications, and Recommended actions, with a week-over-week comparison. Recommend a planning
> action for the top three signals. Draft a short Teams update for [Teams Channel] and, if needed,
> a 30-minute decision-review invite for [Decision Owners] - hold everything for my review. Save
> this as a skill named [Market Intelligence] (alias: Market Competition Analyzer) and schedule it
> every Monday at 8:00am PT.
