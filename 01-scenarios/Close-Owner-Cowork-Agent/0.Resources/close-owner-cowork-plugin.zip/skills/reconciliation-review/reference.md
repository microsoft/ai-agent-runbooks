# Reconciliation Review reference

Customer-tunable settings for `reconciliation-review`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Reconciliation scope | [Account / Reconciliation Scope] | Cash, AR control, intercompany, accruals, clearing |
| Entity | [Entity] | Legal entity or entities |
| Period | [Period] | As-of date |
| Source A | [Source A] | e.g., GL extract |
| Source B | [Source B] | e.g., bank statement, subledger, counterparty statement |
| Prior reconciliation | [Prior Reconciliation] | Last period's workbook |
| Recon folder | [Recon Folder] | OneDrive / SharePoint location for workbooks |
| Reviewer / approver | [Reviewer] | Approves routing and proposed corrections |
| Time zone | [Time Zone] | For schedule |
| Schedule | Monthly BD 1-3; weekly or daily for cash and intercompany | Per close calendar |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Match keys | Reference, amount, date, counterparty | Order of precedence |
| Date tolerance | [Date Tolerance] (example: ±3 days) | Tolerance-match pass only |
| Amount tolerance | [Amount Tolerance] (example: ±$1) | Tolerance-match pass only |
| Many-to-one matching | Exact sum only | Never within tolerance |
| Materiality | [Materiality Threshold] (example: items >$10K) | Driver search above this |
| Aging buckets | >30, >60, >90 days | Carried forward from prior recon |
| Priority order | Amount, then age, then control risk | Tunable weights |
| Break categories | Timing, missing in A, missing in B, amount difference, duplicate, mis-posting, FX | Add customer categories |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Reconciliation cycle time | Hours from data load to review-ready exception list | Recon workbook history | Reconciliation cycle time |
| Exception resolution rate | Exceptions cleared within period ÷ exceptions raised | Owner tracker | Exception resolution rate (add to baseline) |
| Aged reconciling items | Open items >30/60/90 days at period end | Recon workbooks | Aged reconciling items |
| Control accuracy | Review notes and post-close adjustments per cycle | Review comments, post-close adjustments | Control accuracy (add to baseline) |

## Output templates

| Artifact | Layout |
| --- | --- |
| Exception workbook (Excel) | Summary (balance per A, per B, difference, explained vs. unexplained - formulas); Matched (with rule); Exceptions (Category, Amount, Age formula, Driver, Evidence, Status, Owner, Proposed Resolution); Aging pivot |
| Review summary (Word, 1-2 pages) | Reconciled position; top exceptions; control observations; recommended actions |
| Owner tracker | Exception, Owner, Due Date, Status |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| ERP (Dynamics 365 Finance, SAP) | Optional | Use provided extracts; state extract date |
| Fabric IQ / Power BI transactional model | Optional | Use provided extracts |
| Statements and workbooks in files | Required (at least two sources) | Stop and request the missing source |
| Mail and Teams context | Optional for drivers | Label explanations Hypothesis |

## Never-automate list

- Posting correcting journal entries
- Clearing or matching open items in any system
- Altering source data or statements
- Routing exceptions to owners

## Sharing gate

Default state: not routed. Before routing, show exact owners, items, content, and a warning when
bank or counterparty data is included.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium |
| License-only starter (USL) | Copilot in Excel or Analyst on two exports |
| Cowork (UBB) | Full multi-source, multi-step workflow with saved artifacts and approval-gated routing |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Reconcile [Account / Reconciliation Scope] for [Entity] as of [Period], comparing [Source A] to
> [Source B]. Match on reference and amount with [Date Tolerance] date tolerance, then flag every
> break over [Materiality Threshold]. Classify each break, find the likely driver from transaction
> detail, emails, and Teams (mark what's supported vs. hypothesis), and carry forward aged items
> from [Prior Reconciliation]. Give me an Excel exception workbook with formulas, a one-page
> summary, and a proposed owner for each item - don't route anything until I approve.
