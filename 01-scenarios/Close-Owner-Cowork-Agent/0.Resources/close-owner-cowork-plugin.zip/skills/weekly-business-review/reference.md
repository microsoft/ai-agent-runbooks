# Weekly Business Review reference

Customer-tunable settings for `weekly-business-review`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Business area | [Business Area] | Business unit, region, or product line |
| Dashboard / model | [Power BI Dashboard] | Governed dashboard or semantic model; same as any Insights Analyst Finance review |
| KPI list | KPIs used in the prior review | Keep order and labels stable week to week |
| Plan version | [Plan / Forecast Version] | Budget or latest forecast |
| Review week | Most recent completed week | Week-ending date |
| Prior review folder | [Review Folder] | Prior review document and action tracker |
| Stakeholders | [Stakeholders] | Review attendees and sharing audience |
| Meeting slot | End of next week | Draft only; booked after approval |
| Time zone | [Time Zone] | For schedule and meeting draft |
| Schedule | Weekly, 1-2 business days before review (e.g., Wednesday 7:00 AM for a Friday review) | After the model's scheduled refresh |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Materiality to plan | [Materiality Threshold] (default ±5%; example ±$250K) | Flag KPIs beyond threshold |
| Status label | Ahead / On plan / Behind | Based on plan Δ vs. threshold |
| Stalled action | Open action with no update since [Prior Review] | Report owner, age, blocker |
| Stale data | Model not refreshed since the review week ended | Show last refresh time; do not substitute |
| Conflict rule | Dashboard vs. team update disagree | Show both; mark "Needs confirmation" |
| Risk fields | Impact, likelihood, owner | Leadership-attention risks only |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Report generation time | Hours to assemble KPI tables, narrative, document, and tracker | Time study | Weekly business review report generation time |
| Leadership decision speed | Median days from decision raised to decision recorded | Review documents, action tracker | Leadership decision speed |
| Forecast accuracy | Forecast vs. actual variance (%) for review KPIs, model-defined measure | Power BI / Fabric semantic model | Forecast accuracy |

## Output templates

| Artifact | Layout |
| --- | --- |
| Business review document (Word, or PowerPoint on request) | Executive summary; KPI scorecard; highlights; ahead/behind-plan drivers; risks; decisions needed; open-action review; appendix of sources and refresh times |
| Action tracker (Excel) | Action, Owner, Due Date, Status, Days Open (formula), Source, Last Update, Blocker; carried forward from prior tracker |
| KPI tab (Excel) | Current, Prior, Plan, WoW Δ, Plan Δ, Δ% (live formulas) |
| Meeting draft | End of next week; agenda: performance, risks, decisions needed, action review; both files attached |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Fabric IQ / Power BI dashboard | Required | State the gap and last refresh; do not claim report-grounded figures |
| ERP drill-down | Optional | Ask for an extract; never infer values |
| Mail, Teams, meeting recaps | Required for updates | List as a source gap |
| Prior review and tracker | Required for WoW and stalled actions | First run: no WoW comparison; say so |

## Never-automate list

- Booking the review meeting or sending invites
- Sharing the review document or posting to Teams
- Messaging stakeholders or action owners
- Changing plan or forecast values

## Sharing gate

Default state: not sent, not booked. Before any share or booking, show exact recipients, content,
attachments, meeting time, and a private-data warning where mail, chat, or meeting content is used.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> I'm preparing for the weekly business review for [Business Area]. Use [Power BI Dashboard] and
> relevant updates from recent emails, Teams discussions, and review meetings with my team.
> Identify the most important changes since last week's review, areas ahead of plan and behind
> plan, risks that require leadership attention, decisions that need to be made, and open actions
> that have not progressed. Create a business review document with key metrics, highlights,
> risks, and decisions, and an updated action tracker. Then draft a business review meeting for the
> end of next week with [Stakeholders], attaching the review document and action tracker, with an
> agenda covering performance, risks, decisions needed, and action review - show me the drafts
> before anything is shared or booked. Save this process as a skill named [Weekly Business Review]
> so I can run it before each leadership review.
