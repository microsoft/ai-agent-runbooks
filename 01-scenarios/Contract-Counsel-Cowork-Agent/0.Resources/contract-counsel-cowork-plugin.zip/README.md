# The Contract Counsel Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Contract Counsel (In-house Counsel / Transactional Lawyer / Contract Manager) · **Function:** Legal
**Runbook:** `cowork-contract-counsel-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  contract-counsel-concierge/
    SKILL.md
    reference.md
  playbook-contract-review/
    SKILL.md
    reference.md
  draft-from-precedent/
    SKILL.md
    reference.md
  tracked-change-editing/
    SKILL.md
    reference.md
  final-draft-check/
    SKILL.md
    reference.md
  playbook-from-precedents/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `contract-counsel-concierge` | Routes the user to the right Contract Counsel skill |
| `playbook-contract-review` | Reviews counterparty paper against the organization's standard contract playbook (deck alias "Legal Review"): compares every clause to the playbook's standard, fallback, and walk-away positions, drafts tracked-change redlines in Word, and prepares an approver issues list and a draft reply |
| `draft-from-precedent` | Builds a new agreement in Word from an agreed precedent and the terms settled by email: pulls the client precedent from the document management system and the emails and Teams messages where terms were agreed, maps each agreed term to a precedent clause, drafts the new agreement, and lists every term it could not place or found in conflict |
| `tracked-change-editing` | Applies a lawyer's instructed amendments to a Word draft as tracked changes so reviewers see exactly what moved: numbers each instruction, makes each edit in tracked changes with a comment linking it to the instruction, applies consequential updates to defined terms, cross-references, and numbering, and lists any instruction it could not apply or found ambiguous |
| `final-draft-check` | Confirms the execution version of an agreement actually contains what the parties agreed (deck title "Final draft verification"): compares the execution version against the last agreed draft, the negotiation history, and terms agreed in email and Teams; lists every difference with clause/section references; and checks parties, dates, defined terms, cross-references, schedules, and signature blocks |
| `playbook-from-precedents` | Turns previously negotiated deals into a reusable contract playbook of standard, fallback, and walk-away positions: collects executed agreements and negotiation history for a contract type, extracts the position taken on each clause topic and how often it was conceded, and drafts a cited playbook in Word with an evidence table in Excel for the playbook owner to approve |

Start with `contract-counsel-concierge` if you are not sure which skill to use. Recommended starters: `playbook-contract-review` and `draft-from-precedent`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
