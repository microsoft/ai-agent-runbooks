# Contract Counsel Concierge reference

Routing authority for `contract-counsel-concierge`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Package directory

Skills in startup order (The Contract Counsel plugin).

| User goal | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Routing help across the plugin | `contract-counsel-concierge` | "help me choose" | On demand |
| First turn on counterparty paper; flag deviations; approver issues list | `playbook-contract-review` | "review this contract using our playbook" | Optional event trigger from [Contracts Inbox] |
| New agreement from a precedent plus terms agreed by email | `draft-from-precedent` | "draft a new agreement from the [Client] precedent" | On demand |
| Apply instructed edits as tracked changes | `tracked-change-editing` | "make these changes in tracked changes" | On demand |
| Execution version vs. agreed draft before signing | `final-draft-check` | "check the execution version before signing" | On demand |
| Build or refresh a playbook from executed deals | `playbook-from-precedents` | "build a playbook from our past [Contract Type] deals" | Optional quarterly or semi-annual |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "Run the Legal Review on this NDA" | `playbook-contract-review` |
| "Flag every deviation from our standard terms" | `playbook-contract-review` |
| "Turn the agreed terms into a first draft" | `draft-from-precedent` |
| "Use our last deal as the starting point" | `draft-from-precedent` |
| "Mark up the draft per [Partner]'s email" | `tracked-change-editing` |
| "Does the final draft match what we agreed?" | `final-draft-check` |
| "What are our usual fallback positions on liability?" | `playbook-from-precedents` |
| "Which skill should I use?" | `contract-counsel-concierge` |
| "Extract key terms across the data room" | Out of scope - suggest `portfolio-counsel-concierge` |

## Ambiguity rules

- Counterparty paper just arrived, or "first turn", "deviation", "our standard terms" -> playbook review.
- "Precedent", "first draft", "agreed terms" -> draft from precedent.
- Specific instructions or "tracked changes" on an existing draft -> tracked-change editing.
- "Execution version", "signing copy", "before signing" -> final draft check.
- "Playbook", "fallback positions", "past deals" without a single agreement -> playbook from precedents.
- If two fit, pick the narrower artifact first and mention the alternative.
- Requests to send, sign, file, or accept changes: explain these stay with the lawyer, then route to
  the skill that prepares the draft.

## Starter recommendation

For a first-time user, recommend `playbook-contract-review` on one contract type with an approved
playbook, run on a recently closed agreement so findings can be checked against the negotiation.
Then add `draft-from-precedent`, `tracked-change-editing`, `final-draft-check`, and
`playbook-from-precedents` in that order.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Skills installed | All five scenario skills | Remove rows for skills not deployed |
| Sibling concierge | `portfolio-counsel-concierge` | Remove mention if not deployed |
| Contracts inbox | [Contracts Inbox] | Named only when offering the trigger |

## Schedule guidance

Do not create a trigger or schedule unless the user explicitly confirms the exact prompt and cadence.
Event trigger for `playbook-contract-review` and refresh schedule for `playbook-from-precedents` are
optional; all runs produce drafts only.

## Never-automate list

- Running sibling-skill work from the concierge
- Creating or changing triggers or schedules without confirmation of exact prompt and cadence
- Sending, signing, filing, issuing notices, or accepting/rejecting tracked changes

## Sharing gate

Default state: nothing shared. The concierge produces a routing recommendation only; any sharing
happens in the routed skill under that skill's sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Light (routing only) |
| Note | Routed skill billing applies when the user runs the routed skill |

## No-match response

```markdown
I do not have a Contract Counsel skill for <goal> yet. This plugin covers playbook contract review,
draft from precedent, tracked-change editing, final draft check, playbook from precedents, and
routing help.
```

## Example prompt

> Help me choose: [describe the contract situation, e.g., "the counterparty just sent their MSA"].
