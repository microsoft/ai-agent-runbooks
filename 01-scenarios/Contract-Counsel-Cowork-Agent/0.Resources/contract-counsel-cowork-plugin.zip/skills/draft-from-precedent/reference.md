# Draft from Precedent reference

Customer-tunable settings for `draft-from-precedent`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Document management system | [Document Management System] (e.g., HighQ, iManage, NetDocuments) | Read-only connector, if approved |
| Approved precedent set | [Library or workspace of precedents cleared for reuse] | Owned by knowledge / legal ops lead |
| Reuse restrictions | [List of clients or matters whose precedents may not be reused] | Excluded and logged every run |
| Fallback library | [SharePoint library with copied precedents] | Only if no connector; record copy date |
| Draft save location | [Matter workspace or OneDrive folder] | Save after lawyer approval |
| Reviewer default | [Reviewing Lawyer] | Overridable per run |
| Banner text | DRAFT - FOR LAWYER REVIEW | Per firm practice |
| Placeholder style | [TBC - not agreed] | Used for unagreed values |
| Time zone | [Customer time zone] | For term-log dates |

## Rules and thresholds

| Term status | Meaning | Handling |
| --- | --- | --- |
| Reflected | Agreed term placed in a clause of the new draft | Cite email and clause |
| Not confirmed | Proposed but not clearly accepted, or later contradicted | List both sources; placeholder in draft |
| Unplaced | Agreed but no matching precedent clause | Open point for the lawyer |

| Rule | Default | Tunable |
| --- | --- | --- |
| "Agreed" evidence | Explicit acceptance by both sides in email or Teams | Can be tightened (e.g., require term sheet) |
| Latest-wins | Never applied automatically; contradictions are flagged | Not loosenable |
| Prior-client scrub | Names, figures, dates, and bespoke terms from the precedent client | Can add items |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Time to first draft | Median hours from terms agreed to first draft shared internally | Version history | Time to first draft from precedent |
| Rework from missed terms | Agreed terms missing from a draft and found at review | Review comments sample | Rework from missed terms |
| Drafting time saved | Lawyer drafting hours vs. baseline | Time study | Time to first draft from precedent |

## Output templates

**Agreed-terms map columns:** Term | Agreed Position | Source (email/date) | Precedent
Clause/Section | New Clause/Section | Status (Reflected / Not confirmed / Unplaced).

**Open points list:** Term or clause | Issue | Sources | Decision needed | Owner.

**Draft document:** banner, tracked changes vs. precedent, placeholders for unagreed values.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook, Word | Required | Ask user to supply threads and precedent |
| Document management connector | Optional | Use precedent the user supplies in M365; say so in output |
| Teams | Optional | Note as source gap |

## Never-automate list

- Sharing the draft with a client or counterparty
- Signing, e-signature routing, or filing
- Accepting or rejecting tracked changes
- Saving a new version to the document management system without confirmation

## Sharing gate

Default state: not shared. Before any share, show exact recipients, exact content, sensitivity
label, and a privilege and prior-client warning; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium (indicative 300-700 Copilot Credits per run) |
| License-only starter | Copilot in Word drafts from one precedent |
| Cowork | Full workflow: precedent from document management plus terms across mail and Teams, term map, draft, review gate |

## Example prompt

> Use the [Client] precedent in [Document Management System] to draft a new agreement that reflects
> the terms we agreed to over email on [Matter / Deal] between [Dates]. Map each agreed term to the
> matching precedent clause, cite the email and clause number, show changes against the precedent in
> tracked changes, and list any term that is unconfirmed, conflicting, or has no matching clause.
> Hold the draft for [Reviewing Lawyer] - don't share it. Save this as a skill named [Draft from
> Precedent].
