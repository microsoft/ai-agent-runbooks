# Final Draft Check reference

Customer-tunable settings for `final-draft-check`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Document management system | [Document Management System] | Version history via read-only connector, if approved |
| Entity register | [Location of approved legal entity names and authorized signatories] | Used to check parties and signature blocks |
| Report save location | [Matter workspace or OneDrive folder] | Save after review |
| Banner text | DRAFT - PRIVILEGED & CONFIDENTIAL - FOR LAWYER REVIEW | Per firm practice |
| Comparison format | Word compare document | Tunable |
| Time zone | [Customer time zone] | For dates in report |

## Rules and thresholds

| Status | Meaning |
| --- | --- |
| Reflected | Agreed point appears in the execution version as agreed |
| Missing | Agreed point absent from the execution version |
| Different | Point present but wording or value differs from what was agreed |
| Unexplained difference | Difference vs. last agreed draft with no agreeing source |
| Not checkable | Page or document without readable text |

## Mechanical checks

| Check | Default |
| --- | --- |
| Parties and entity names | Match [Signatory Details] / entity register exactly |
| Dates | Effective date, term dates, and dates in schedules are consistent |
| Defined terms | Every capitalized term is defined and used consistently |
| Cross-references | Every reference points to an existing clause |
| Numbering | No gaps or duplicates |
| Schedules/exhibits | All referenced schedules attached |
| Blanks and placeholders | None remaining (e.g., [ ], TBC, XX) |
| Signature blocks | Names, titles, and entities match [Signatory Details] |

Customers may add checks; none may be removed.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Pre-signature check time | Minutes per execution-version check | Time study | Pre-signature check time |
| Post-signing errors avoided | Corrections or amendments needed after signature for drafting errors | Matter records | Post-signing errors |
| Differences caught pre-signature | Differences found by the check before signature | Check reports | Pre-signature check time |

## Output templates

**Differences table:** Clause/Section | Agreed Draft | Execution Version | Source of Agreement |
Status.

**Report sections:** result line (never a certification), differences, agreed points, mechanical
checks, open questions, source gaps, signature decision note.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Word/PDF documents | Required | Ask the user to supply both versions |
| Outlook, Teams | Optional | Check versions only; note agreed-terms gap |
| Document management connector | Optional | User supplies last agreed draft; say so |

## Never-automate list

- Signing or routing for e-signature
- Certifying a document as ready to sign
- Sending to a counterparty or filing
- Accepting or rejecting tracked changes

## Sharing gate

Default state: not shared. Before any share, show exact recipients, content, and sensitivity label;
wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium (indicative 300-700 Copilot Credits per run) |
| License-only starter | Copilot in Word compares two versions |
| Cowork | Full workflow: execution version vs. agreed draft plus terms from mail, Teams, and negotiation history, with mechanical checks |

## Example prompt

> Compare [Execution Version] against [Last Agreed Draft] and the terms agreed in [Negotiation
> Sources] for [Matter / Deal]. List every difference with clause numbers, confirm each agreed point
> is reflected, and check parties, dates, defined terms, cross-references, schedules, blanks, and
> signature blocks against [Signatory Details]. Flag anything unexplained - don't certify it as ready
> to sign. Save this as a skill named [Final Draft Check].
