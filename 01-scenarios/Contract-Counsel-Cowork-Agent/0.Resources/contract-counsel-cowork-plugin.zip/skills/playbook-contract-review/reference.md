# Playbook Contract Review reference

Customer-tunable settings for `playbook-contract-review`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Document management system | [Document Management System] (e.g., iManage, NetDocuments, HighQ) | Read-only connector, if approved |
| Playbook map | [Contract Type] -> [Playbook location and version] | One row per in-scope type (e.g., NDA, MSA, SaaS, DPA) |
| Fallback library | [SharePoint library with copied playbooks] | Used only if no connector; record copy date |
| Approver map | [Contract Type / deviation category] -> [GC or deal lead] | Named approvers for off-playbook points |
| Contracts inbox | [Contracts Inbox] mail folder | Event trigger source (optional) |
| Issues list location | [Matter workspace or SharePoint folder] | Drafts saved only after approval |
| Our side defaults | [Entity name], [Expected governing law] | Confirmed per run |
| Clause topics | Liability, indemnities, IP, confidentiality, data protection, termination, payment, governing law, assignment | Align to playbook headings |
| Banner text | DRAFT - PRIVILEGED & CONFIDENTIAL - FOR LAWYER REVIEW | Per firm practice |
| Time zone | [Customer time zone] | For trigger timestamps |

## Rules and thresholds

| Classification | Meaning | Handling |
| --- | --- | --- |
| Standard | Clause matches the playbook standard position | No redline; listed for completeness |
| Acceptable fallback | Matches a pre-approved fallback | Optional redline; note fallback used |
| Off-playbook (approval required) | Outside standard and fallback | Redline to playbook; issues list row; approver named |
| Walk-away | Matches a playbook walk-away trigger | Top of issues list; approver named |
| Not covered by playbook | No playbook topic applies | No invented position; lawyer decides |

| Rule | Default | Tunable |
| --- | --- | --- |
| Issues list order | Walk-away, off-playbook, fallback, not covered | Yes |
| Ambiguity flag | Any ambiguous drafting, inconsistency, or broken cross-reference | Can add, not remove |
| Event trigger scope | Email with agreement attachment in [Contracts Inbox] | Yes |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| First-turn review time | Median hours from paper received to first turn returned | Email timestamps, matter records | First-turn review time |
| Deviations caught | Deviations found at first turn ÷ all deviations found in negotiation | Issues lists, redline history | Deviations caught at first turn |
| Approval cycle time | Median days from off-playbook point raised to approver decision | Approval emails, Teams | Approval cycle time |

## Output templates

**Issues list columns:** Clause/Section | Topic | Counterparty Text | Playbook Position |
Classification | Proposed Redline | Ambiguity Flag | Decision Needed | Approver.

**Redline comment:** "Playbook [topic] rule [ref]: [position]. Counterparty text deviates: [reason]."

**Approver message skeleton:** Subject: [Matter / Deal] - off-playbook points for decision.
Body: summary counts, walk-away items, off-playbook items with proposed redline, decision by
[date], link to issues list.

**Counterparty reply skeleton:** thanks, key changes summarized by topic, attached redline, open
points. Held as a draft; the user sends.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook, Word | Required | Ask user to supply agreement |
| Document management connector | Optional | Use playbook the user supplies or Fallback library; say so in output |
| Teams | Optional | Note as source gap |

## Never-automate list

- Sending anything to a counterparty, client, or opposing counsel
- Signing, e-signature routing, or filing
- Accepting or rejecting tracked changes; removing existing changes or comments
- Routing to approvers or saving back to the document management system without confirmation

## Sharing gate

Default state: not sent. Before any send, show exact recipients, exact content, sensitivity label,
and a privilege warning; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium (indicative 300-700 Copilot Credits per run) |
| License-only starter | Copilot in Word reviews one agreement against the playbook |
| Cowork | Full workflow: email + playbook + agreement, redline, issues list, approval-gated routing |

## Example prompt

> Review [Agreement] using our standard playbook stored in [Document Management System]. We act for
> [Our Side] on [Matter / Deal]. Compare every clause to the playbook, cite the clause number for
> each deviation, and classify it as standard, fallback, off-playbook, walk-away, or not covered.
> Draft tracked-change redlines in Word for my review, build an issues list for [Approvers], and
> draft a reply to [Counterparty Contact] summarizing key changes. Flag ambiguous drafting instead of
> interpreting it. Don't send anything or accept any changes. Save this as a skill named [Playbook
> Contract Review].
