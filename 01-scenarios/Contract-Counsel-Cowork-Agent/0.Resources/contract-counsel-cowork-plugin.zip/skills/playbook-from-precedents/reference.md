# Playbook from Precedents reference

Customer-tunable settings for `playbook-from-precedents`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Document management system | [Document Management System] (e.g., iManage, NetDocuments, HighQ) | Read-only connector, if approved |
| Precedent set | [Workspace/library of executed agreements for [Contract Type]] | With date range and deal count |
| Fallback library | [SharePoint library with copied executed agreements] | Only if no connector; record copy date |
| Existing playbook | [Location and version] | Optional |
| Playbook owner | [GC or legal ops lead] | Approves before publishing |
| Reuse restrictions | [Clients/matters excluded from precedent analysis] | Logged every run |
| Anonymization | Anonymize counterparties in evidence table | Tunable per owner direction |
| Output location | [Legal team SharePoint folder] | Draft only until approved |
| Refresh schedule | Quarterly or semi-annual, [Day/time, time zone] | Optional; confirm before creating |

## Clause topics

Default: limitation of liability; indemnities; IP; confidentiality; data protection; termination;
payment; governing law and disputes; assignment and change of control. Add or remove per contract
type.

## Rules and thresholds

| Rule | Default | Tunable |
| --- | --- | --- |
| Minimum deals | 3 supporting precedents before a position is established | Can raise; lowering requires owner approval |
| Standard candidate | Most common executed position | Yes |
| Fallback candidate | Position accepted with an approval email | Yes |
| Walk-away candidate | Position rejected or escalated and not accepted | Yes |
| Thin evidence | Fewer than [Minimum Deals] supporting precedents | Flag always shown |
| Conflict | Precedents disagree with no approval trail explaining why | Flag always shown |
| External context | Legal AI assistant output labeled "Market context - not internal precedent" | Not loosenable |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Playbook build time | Hours to a reviewed playbook for one contract type | Legal ops records | Playbook build time |
| Negotiation consistency | Share of new deals closed within standard/fallback positions | Issues lists | Deviations caught at first turn |
| Escalations avoided | Escalations per deal after adoption | Approval emails | Approval cycle time |

## Output templates

**Playbook entry per topic:** Standard | Fallback(s) | Walk-away | Approver | Rationale |
Supporting precedents (agreement + clause/section).

**Evidence table columns:** Agreement | Date | Counterparty (or anonymized ID) | Topic | Executed
Position | Clause/Section | Category | Approval Source.

**Change log:** Topic | Existing position | Proposed position | Evidence count | Reason.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Executed agreements | Required | Cannot run; ask for the precedent set |
| Document management connector | Optional | Fallback library; say so in output |
| Outlook, Teams approval threads | Optional | Fallback/walk-away candidates marked lower confidence |
| Legal AI assistant | Optional | Omit market context; say so |

## Never-automate list

- Publishing to the clause library or document management system
- Sharing the playbook outside legal
- Sending to counterparties, signing, or filing
- Creating a refresh schedule without confirmation of prompt and cadence

## Sharing gate

Default state: not published. Before publishing or sharing, show exact destination, audience,
content, and sensitivity label; wait for the playbook owner's explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (indicative 700+ Copilot Credits per run) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Bound the precedent set for first runs; check `/cost` per run |

## Example prompt

> Build a negotiation playbook for [Contract Type] from our executed deals in [Precedent Set] since
> [Date]. For each of [Clause Topics], identify the standard, fallback, and walk-away positions from
> what we actually agreed, cite the agreement and clause number for each, show how often each
> position was used, and flag conflicts or thin evidence. Compare to [Existing Playbook] and list
> proposed changes. Hold the draft for [Playbook Owner] - don't publish it. Save this as a skill
> named [Playbook from Precedents].
