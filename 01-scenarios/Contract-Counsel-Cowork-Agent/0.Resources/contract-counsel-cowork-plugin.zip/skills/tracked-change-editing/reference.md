# Tracked-Change Editing reference

Customer-tunable settings for `tracked-change-editing`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Author label | [Author Label] (e.g., user name or "Copilot for [User]") | Per firm tracked-change attribution practice |
| Version naming | [Document name]_v[n+1]_[initials]_[date] | Never overwrite the source version |
| Save location | Same folder as [Draft], or document management via connector | Save-back requires confirmation |
| Comment prefix | "Instruction #[n] - source: [email/comment/user]" | Tunable wording |
| Internal-comment handling | Keep all comments | Strip only when instructed, in a separate version |
| Banner text | DRAFT - FOR LAWYER REVIEW | Per firm practice |
| Time zone | [Customer time zone] | For version dates |

## Rules and thresholds

| Change status | Meaning | Handling |
| --- | --- | --- |
| Applied | Edit made as a tracked change | Comment links to instruction |
| Ambiguous | Instruction has more than one reasonable reading or conflicts with another | Not applied; listed for the lawyer |
| Not applied | Target clause cannot be located or instruction is out of scope | Listed with reason |

| Consequential edit scope | Default | Tunable |
| --- | --- | --- |
| Defined terms | Update uses of a renamed or new defined term | Yes |
| Cross-references | Update references to renumbered clauses | Yes |
| Numbering | Renumber after insertions or deletions | Yes |
| Schedules/exhibits | List affected schedules; edit only if instructed | Can tighten |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Markup turnaround time | Median minutes from instruction to marked-up draft | Version history, time study | Markup turnaround time |
| Revision cycles | Review rounds per draft caused by missed or wrong edits | Version history | Revision cycles |
| Drafting accuracy | Errors in applied edits found at review | Review comments | Revision cycles |

## Output templates

**Change summary columns:** Instruction # | Clause/Section | Change Made | Consequential Edits |
Status (Applied / Ambiguous / Not applied).

**Margin comment:** "Instruction #[n] - [short quote of instruction] - source: [email date/sender
or comment]".

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Word | Required | Cannot run |
| Outlook, Teams | Optional | User pastes instructions |
| Document management connector | Optional | Save new version to OneDrive/SharePoint; user files it |

## Never-automate list

- Accepting or rejecting any tracked change
- Removing existing tracked changes or comments
- Sending to a counterparty, signing, or filing
- Saving back to the document management system without confirmation

## Sharing gate

Default state: not shared. Before any share or save-back, show the exact file, recipients, and
sensitivity label; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | USL |
| Intensity | Included (Copilot in Word) |
| License-only starter | The core value is available with the Microsoft 365 Copilot license in Word |
| Cowork | Use Copilot Credits only when the user wants the full multi-step version with saved outputs or actions |

## Example prompt

> Apply the changes in [Instructions] to [Draft] as tracked changes. Add a comment on each change
> linking it to the instruction number, update any defined terms, cross-references, and numbering
> affected, and list any instruction that is ambiguous or can't be applied. Don't accept or reject
> anything. Save this as a skill named [Tracked-Change Editing].
