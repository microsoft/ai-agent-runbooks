# The Decision-Maker Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Decision-Maker (CEO / President / BU Head) · **Function:** Executives
**Runbook:** `cowork-decision-maker-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  decision-maker-concierge/
    SKILL.md
    reference.md
  daily-command-center/
    SKILL.md
    reference.md
  board-pre-reads/
    SKILL.md
    reference.md
  cited-decision-briefs/
    SKILL.md
    reference.md
  exception-analytics/
    SKILL.md
    reference.md
  relationship-briefings/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `decision-maker-concierge` | Routes a senior leader to the right Decision-Maker skill |
| `daily-command-center` | Builds a daily interactive HTML Executive Command Center and a printable one-page Word summary from the executive's calendar, recent mail, Teams chats, meeting transcripts, and priority documents |
| `board-pre-reads` | Runs the board prep workflow (saved-skill alias "Board and Leadership Pre-Read") |
| `cited-decision-briefs` | Writes a cited decision brief for one pending leadership decision |
| `exception-analytics` | Runs the business-review exception radar |
| `relationship-briefings` | Prepares a focused briefing pack on a person, organization, topic, or relationship ahead of a high-stakes meeting |

Start with `decision-maker-concierge` if you are not sure which skill to use. Recommended starters: `daily-command-center` and `board-pre-reads`.

Some skills mention Force Multiplier skills (`force-multiplier-concierge`, `weekly-synthesis`, `cross-org-leadership-brief`, `inbox-triage-at-scale`, `delegated-memo-and-deck`). They are not in this package; the Decision-Maker skills route to them only when The Force Multiplier plugin is installed.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

Fill these before first use, because they ship blank: the criteria weights in `cited-decision-briefs` (until filled, briefs are unweighted) and `[Materiality Threshold]` in `exception-analytics`. External web research stays off for `cited-decision-briefs` and `relationship-briefings` until the security owner approves it and the approval (who and when) is recorded in each skill's `reference.md`.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.

- Each confirmation covers one previewed item, showing its exact recipients or attendees, content, attachments, and time. Confirming one item does not confirm another.
- Teams messages and calendar events have no draft state, so the preview shown in chat is the draft; nothing is created until it is confirmed.
- Drafted messages and invites go only to the approved audience (for example, the meeting invite's attendees exactly as listed); no one is added without asking.
- Saving to a shared location or into another person's OneDrive also needs confirmation.
- Scheduled and event-triggered runs build drafts only and never send, post, share, schedule, or write back.
