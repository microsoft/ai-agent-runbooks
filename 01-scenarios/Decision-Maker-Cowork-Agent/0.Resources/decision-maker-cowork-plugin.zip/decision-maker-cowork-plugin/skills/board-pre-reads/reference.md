# Board Pre-Reads reference

Customer-tunable settings for `board-pre-reads`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

Resolve each value in the order shown. "Confirm" means show the found value and its source in the
draft summary; the run continues. "Ask" means ask once in an interactive run; in a scheduled run,
write `[TBD: ...]` and list it as a gap instead.

| Setting | Placeholder | 1. Look up | 2. If none or several found | Required? |
| --- | --- | --- | --- | --- |
| Meeting and date | [Board / Leadership Meeting], [Date] | Calendar: next occurrence whose subject matches the name in the prompt | Ask; list the 3 nearest candidate meetings | Yes - stop if unresolved |
| Main topic | [Project / Initiative] | Prompt; invite body or agenda | Ask | Yes |
| Materials folder | [Meeting Materials Folder] | Files linked from the invite, meeting chat, and mail since the previous meeting; the folder holding the prior deck | Ask; continue with found files and list the folder as a gap | Yes for saving; no for building |
| Performance workbook | [Performance Workbook] | Latest .xlsx in the materials folder or linked in recent leadership mail | Build narrative only; mark the performance slide as a gap | No |
| Board template | [Board Template] (.pptx/.potx) | Org template library; else the prior deck's master and layouts | Use the org default and note it | No |
| Leadership team | [LT] | Configured list; else the meeting attendees (expand distribution lists only if the user confirms) | Ask | Yes for the drafts |
| Review window | [Date or Timeframe] | Default: 2-3 business days before the meeting, inside attendees' shared working hours | Propose one slot and state that availability was not checked | No |
| Time zone | [Time Zone] | Mailbox time zone setting; apply daylight-saving changes for the review date | Ask | Yes for the drafts |
| Run timing | 10 business days before; refresh 2 business days before | For meetings that recur weekly or every other week, use half the recurrence interval (minimum 2 business days) | - | - |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Priority status | On track = evidence of progress to plan; At risk = slip or open blocker; Off track = missed milestone or no plan to recover; Not assessable = no evidence found (list as a gap) |
| "Most important change" | Largest variance vs. plan or prior period that affects a decision or priority; if no plan exists, largest change vs. prior period |
| Conflict | Two sources, or two places in the same source (for example two slides), give different values for the same figure, date, or status: show every value with its location |
| Stale workbook | Last refresh older than the reporting period: flag on the gaps slide |
| Placeholder text in a source | Values such as "X", "TBD", or "COMING SOON" in a source are gaps, not data |
| Slide count | 8-12 slides |
| Review meeting | 30 minutes; agenda: gaps, unresolved decisions, final changes |
| File name | `<Meeting>-PreRead-<YYYY-MM-DD>.pptx`; meeting name without spaces or special characters |

**Running on a schedule or trigger in Cowork**

Cowork scheduled prompts run on fixed recurrences or once at a set time; Cowork event triggers fire
on mail, Teams messages, webhooks, or Power Platform connector events. Neither natively computes
"N business days before a calendar meeting". Use one of these, only after the user confirms the
prompt, time zone, and drafts-only behavior:

1. **Weekly scan (recommended).** A weekly scheduled prompt (for example Mondays 8:00 a.m.) that
   looks for meetings matching [Board / Leadership Meeting] whose lead time falls in the coming
   week, then builds or refreshes drafts.
2. **One-time runs per meeting.** Two one-time scheduled prompts per meeting: one at the lead time
   and one 2 business days before.
3. **Connector trigger (advanced).** A Power Platform Outlook "event added" connector trigger on an
   existing connection, filtered to the meeting subject, that schedules the two one-time runs. This
   needs a connection the user creates and approves.

Every scheduled or triggered run is drafts-only and sends nothing.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Board prep time saved | Hours from kickoff to approved pre-read | Version history | Pre-read prep time |
| Gaps flagged | Gaps surfaced before (not during) the meeting | Gaps slide vs. minutes | Gaps found during the meeting |
| Decision readiness | Decisions taken at the meeting vs. deferred | Minutes / decision log | Decisions taken vs. deferred |
| Review cycles reduced | Review rounds before final | Version history | Pre-read review rounds |

## Output templates

### Deck outline (`[Meeting]-PreRead-[Date].pptx`)

The six content areas checked by the evals are slides 2-7. Slides 1 and 8 frame them. Add slides
(up to 12) by splitting a content area, never by adding a new topic.

| Slide | Content | Content area |
| --- | --- | --- |
| 1 | Executive summary (what changed, why it matters, asks) | Framing |
| 2 | Business performance and most important changes since last review | 1. Performance |
| 3 | Progress against priorities agreed last time | 2. Prior priorities |
| 4 | [Project / Initiative] status: milestones, risks, dependencies, open questions | 3. Initiative status |
| 5 | Decisions needed, with recommended direction | 4. Decisions |
| 6 | Open actions (owner, due date) | 5. Open actions |
| 7 | Gaps, conflicts, and open questions | 6. Gaps and conflicts |
| 8 | Sources appendix (files with slide/sheet/cell, emails, chats, meetings) | Framing |

A title slide may precede slide 1 and does not count toward the 8-12 limit.

### Feedback request skeleton

Subject: Pre-read for [Board / Leadership Meeting] - feedback by [date]. Body: purpose, link to the
pre-read (once saved), three asks (gaps, decisions, changes), review meeting time. No private mail,
chat, or calendar detail.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Meeting materials (any found) | Required | Stop and ask for the folder or files |
| [Performance Workbook] | Optional | Build narrative only; mark the performance slide as a gap |
| [Board Template] | Optional | Use the org default or prior deck master and note it |
| Prior minutes | Optional | Use the previous meeting's transcript; if none, note "No baseline" on the progress slide |
| Protected or unreadable file | Optional | List it by name on the gaps slide; never guess its content |
| Mail, Teams, transcripts | Required | Note gaps on the gaps slide |

## Never-automate list

- Saving the pre-read to a shared location or another person's OneDrive
- Sharing the pre-read or sending the feedback request
- Creating the review meeting
- Writing to finance, BI, or business systems

## Sharing gate

Default state: not saved to shared locations, not shared, not scheduled. Before any action, show
exact recipients (with distribution lists named), content, attachment, sensitivity label, and
confirm the audience matches the label.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Heavy |
| Credit band | Indicative 700+ Copilot Credits per run; actual use varies. Check with `/cost` |
| License-only starter | None; multi-source assembly, drafting, and scheduling need Cowork |

## Example prompt

> I'm preparing for [Board / Leadership Meeting] on [Date]. The main topic of discussion will be
> [Project / Initiative]. Use the materials in [Meeting Materials Folder], the latest business
> results in [Performance Workbook], and relevant decisions and updates from recent executive
> emails and leadership meetings related to [Project / Initiative]. Create a concise presentation
> based on our existing board presentation template to share as a pre-read that includes business
> performance and the most important changes since the last review, progress against the
> priorities agreed in the previous meeting, status of [Project / Initiative] including major
> milestones, risks, dependencies, and open questions, decisions the group needs to make with a
> recommended direction for each, and open actions with owners and due dates. Keep the narrative
> on what has changed, why it matters, and where leadership input is required. Cite supporting
> files, emails, and meetings, and flag any gaps or conflicting information rather than filling
> them in. Then draft the save to [Meeting Materials Folder], a message to [LT] asking for their
> feedback and inputs, and a 30-minute review meeting with [LT] for [Date or Timeframe] with the
> presentation and a short agenda covering gaps, unresolved decisions, and final changes. Show me
> the drafts before anything is saved, shared, or scheduled.
