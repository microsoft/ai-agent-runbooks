# Cited Decision Briefs reference

Customer-tunable settings for `cited-decision-briefs`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them. Any value still shown as `[Placeholder]` is treated as unset and
handled by the Inputs rules in `SKILL.md` (use the user's value, look it up, ask once,
or show `[TBD: ...]`).

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Evidence folder | [Evidence Folder] | Optional SharePoint/OneDrive location of analyses. Unset: search the user's OneDrive and related sites and note that no folder was configured |
| Evidence window | Last 6 months | Internal mail, Teams, transcripts. Widen per decision only on request |
| External research | [External Research Allowed?] - unset means **no** | Set to yes only after the security owner and executive agree (runbook Step 1). Public sources only; generic query terms only |
| Decision log | [Decision Log] | Optional list for a standing decision pipeline; read only |
| Scheduled run | Off. Optional Mondays 8:00 AM over [Decision Log] | Enable only after on-demand runs pass quality and cost checks; drafts only, no questions asked, `[TBD: ...]` for gaps |
| Output location | Session output or the user's own OneDrive working folder | A shared site or library ([Shared Output Folder]) requires explicit approval per save |
| Time zone | [Time Zone] | Unset: mailbox setting; else ask |

## Rules and thresholds

### Default decision criteria (confirm per decision)

Weights must total 100. Until a customer sets them, weights are unset and the brief rates options
unweighted with `[TBD: weights]`. Drop criteria that do not apply to the decision and say why;
add a decision-specific criterion only with the user's confirmation.

| Criterion | Default weight | Typical use |
| --- | --- | --- |
| Cost | [Weight] | Spend, effort, or credits |
| Revenue impact | [Weight] | Commercial decisions only; omit for internal process choices |
| Risk | [Weight] | Security, compliance, delivery, reputational |
| Time-to-value | [Weight] | How fast the option unblocks the outcome |
| Strategic fit | [Weight] | Alignment with stated priorities |

Example customer setting (not a default): Cost 20, Revenue impact 20, Risk 25, Time-to-value 15,
Strategic fit 20.

### Confidence scale

| Level | Meaning |
| --- | --- |
| High | Multiple consistent, recent, cited primary sources |
| Medium | One solid source, or partially consistent sources, or an AI-generated summary backed by one primary source |
| Low | Thin, dated, conflicting, or AI-summary-only evidence |
| Insufficient evidence | No source; do not estimate |

| Rule | Default |
| --- | --- |
| Number of options | 2-4, always including do nothing |
| Brief length | 2-4 pages |
| Statement labels | [IF] internal fact, [EF] external fact, [J] analysis/judgment |
| Web content quoted inside internal mail or chat | Internal, second-hand evidence; label it; allowed even when external research is no, but never fetch the quoted URLs when the posture is no |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Research hours saved | Hours from request to brief | Request log | Decision research time |
| Recommendation quality | Decisions made on first review vs. sent back for more research | Decision log | Decisions taken vs. deferred |
| Source traceability | Share of sampled claims (minimum 10) that trace to the cited source | Brief audit | Citation coverage sample |

## Output templates

`Decision-Brief-<Topic>-<YYYY-MM-DD>.docx` (Topic: 2-5 words, hyphenated, no customer-confidential
codes unless the label allows): 1 Draft banner and statement-label key; 2 Bottom line up front;
3 Decision question, owner, needed-by date, label, research posture; 4 Context and what changed;
5 Options; 6 Evaluation matrix with weights line; 7 Stakeholder positions and conflicts; 8 Risks and
mitigations; 9 Recommendation, conditions, reversal triggers; 10 Gaps and open questions;
11 Numbered sources; 12 Requires user confirmation before sharing.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook, Teams, transcripts | Required | Note gap; proceed with available evidence |
| [Evidence Folder] | Optional | Search the user's OneDrive and related SharePoint sites; note gap |
| Work-item or ticket systems (for example Azure DevOps) | Optional; usually not reachable | Use notification mail as evidence; note that the item's own discussion was not read |
| Public web | Optional (only if approved) | Internal-only brief; state that no external research was used |
| Finance, CRM, or BI connector | Optional | Use figures from files only; mark unsourced figures insufficient evidence |

## Never-automate list

- Saving the brief to a shared site or library
- Sharing, emailing, or posting the brief
- Sending internal content to external tools or searches
- Writing to finance, CRM, BI, ticket, or decision-log systems

## Sharing gate

Default state: not shared, saved only to the session or the user's own working folder. Before
saving to a shared location or sharing, show exact recipients or location, content, sensitivity
label, and a warning if the brief contains private mail, chat, or meeting content.

## Billing

| Item | Value |
| --- | --- |
| License-only starter (USL) | Type the example prompt into Researcher. Included with the Microsoft 365 Copilot license; answer stays in chat; no saved file; this skill file is not used |
| This skill in Cowork (UBB) | Every run of this skill is a Cowork run because it gathers evidence across sources and builds a Word file. Planning band Medium (300-700 credits per run); Heavy if the evidence window or option count is large. Check with `/cost` and record per run |

## Example prompt

> Write a decision brief on [Decision Question] for [Decision Owner], due [Decision Date]. Use
> relevant emails, Teams threads, meeting transcripts, and analyses in [Evidence Folder]. Use
> public external sources only if external research is approved. Evaluate [Options] (including
> doing nothing) against [Decision Criteria] with [Weights], show stakeholder positions and
> conflicts, and give a recommendation with risks, conditions, and what would change it. Cite
> every claim and flag gaps rather than filling them in. Save it as a Word document in my working
> folder and show me the draft.
