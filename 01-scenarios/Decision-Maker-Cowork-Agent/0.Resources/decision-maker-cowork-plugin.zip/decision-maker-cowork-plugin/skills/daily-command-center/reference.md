# Daily Command Center reference

Customer-tunable settings for `daily-command-center`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | If unfilled |
| --- | --- | --- |
| Priority folder | [Priority Folder] - OneDrive/SharePoint folder of plans, OKRs, strategy docs | Do not guess a folder. Omit priority-document signals, note the gap, offer to set it at the end |
| Key workstreams | [Key Workstreams] - optional list of initiatives to weight more heavily | Rank without weighting; no gap needed |
| Lookback window | Last 3 business days, including today | - |
| Look-ahead window | From now through the end of the current work week (see time rules) | - |
| Run time | Every weekday 7:00 AM, scheduled prompt in Cowork Automations | On-demand only |
| Time zone and working hours | From Outlook mailbox settings | Use Outlook; if unreadable, ask (interactive) or use UTC and note it (scheduled) |
| Output folder | [Output Folder] - default the executive's own OneDrive `Documents/Executive Command Center/` | Use the default. Never a shared or team location |
| Delegate operator | [Chief of Staff / EBP] - optional person who runs the skill for the executive | Executive is the only reader |

## Rules and thresholds

| Rule | Definition |
| --- | --- |
| Action day | Today if the run starts before the end of working hours; otherwise the next working day |
| Busiest day | Remaining working day in the look-ahead with the most meeting hours. Count events shown as busy, tentative, or out of office that the user accepted, tentatively accepted, organized, or has not answered. Exclude free, declined, cancelled, and all-day events. Merge overlapping time so a slot counts once; count duplicate copies of one event once |
| Working days left | Working days from the action day through the end of the work week, including the action day |
| Conflict | Two counted events overlap by 5 minutes or more on a remaining day |
| Quiet commitment | No related activity in the lookback window while its deadline or follow-up date is within the look-ahead window or already passed |

**Coverage limits**

| Source | Read | Report in data gaps |
| --- | --- | --- |
| Mail | All messages in the lookback; open bodies only for items that look actionable | Number of messages scanned; any not opened because encrypted |
| Teams | Unread chats, chats where the executive was @mentioned or asked an unanswered question, and meeting chats for look-ahead meetings, up to 15 chats | Chats read vs active chats; unreadable cards |
| Transcripts | Meetings in the lookback the executive attended or followed | Transcripts unavailable (permission, not recorded, expired) |
| Priority folder | Files modified in the lookback or pinned | Folder not set, empty, or not accessible |

### Action labels (exactly one per card)

First match wins.

| Order | Label | Use when |
| --- | --- | --- |
| 1 | Protect time | The item is about calendar pressure: focus, prep, or recovery time at risk, a conflict, or housekeeping that needs a short block |
| 2 | Re-engage | It meets the quiet-commitment rule |
| 3 | Delegate | A named team or owner other than the executive already holds it, and the executive only needs to assign, confirm, or stay informed |
| 4 | Lean in | Everything else that needs the executive: a decision, an answer owed, a risk, or a commitment the executive's involvement could change |

Delegate never judges a person's ability; it records only who already owns the work.

### Traffic lights

First match wins.

| Order | Light | Use when |
| --- | --- | --- |
| 1 | Red | Due or overdue on or before the end of the action day, a meeting on the action day that needs prep or a response, or a conflict on the action day |
| 2 | Amber | Due later in the look-ahead window, a response owed with no date, or a quiet commitment |
| 3 | Green | On track or informational only |

### Ranking

| Rule | Default |
| --- | --- |
| Urgent items in header | Max 2, taken from the highest-ranked Red cards |
| Order within a view | Red before Amber before Green; then earliest due time; then items tied to Key workstreams; then most recent signal |
| Cards per view | Max 8 in the HTML; extra items go to a collapsed "More" section |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Executive prep time | Minutes spent on morning triage before the first priority decision | User time study | Morning triage time |
| Decision speed | Share of decisions waiting on the executive closed within 48 hours | Decision log | Decisions closed within 48 hours |
| Action closure rate | Share of surfaced follow-ups closed on time | Follow-up tracker | Action closure rate |

## Output templates

| Artifact | Layout |
| --- | --- |
| HTML dashboard `Executive-Command-Center-[action day YYYY-MM-DD].html` | 1. Header: sensitivity label, run time, action day, windows 2. Strip: urgent, top item, busiest day, days left 3. Data-gap panel 4. Tabs: Meetings, Priorities, Org pulse 5. Expandable cards: label, light (text + color), signal, next action, source links 6. Offered follow-ups (drafts) |
| Word summary `Executive-Command-Center-Summary-[action day YYYY-MM-DD].docx` | One US Letter or A4 page, 0.5-0.6 inch margins, body 9-10 pt: label line, title, urgent items, top item, busiest day and days left, up to 10 labeled actions (one line each), data gaps (max 3 lines). If it overflows, drop Green cards first, then shorten signals; never shrink below 9 pt. Verify the page count before delivering |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook Calendar | Required | Stop and report; the command center needs the calendar |
| Outlook mail | Required | Show "mail not available" in the data-gap panel |
| Teams chats, channels, transcripts | Required | Note the gap; summarize meetings from invites only |
| Priority folder | Optional | Omit priority-document signals and note the gap |
| A day with no meetings | - | Say "No meetings" in Meetings and promote the top priority to the header |

## Never-automate list

- Sending replies or Teams messages
- Accepting, declining, or moving meetings
- Creating focus-time or calendar holds
- Writing to CRM, task, action-tracker, or ERP systems
- Saving outputs to a shared location or sharing them

## Sharing gate

Default state: not sent, not shared. Before any action, show exact recipients or calendar change,
exact content, and a private-data warning when the draft uses calendar, mail, chat, or file
content. Approval covers only the draft shown.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| Credit band | Indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost` |
| License-only starter | None; the multi-source dashboard needs Cowork |

## Example prompt

Setup prompt for the admin or executive, used once; it is not part of a run.

> Build an interactive HTML Executive Command Center that shows what requires my attention today
> and this week. Use my calendar, recent emails, Teams conversations, meeting transcripts, and
> priority documents from [Priority Folder]. Focus on decisions, commitments, risks, and
> workstreams where my involvement could change the outcome. At the top, show one or two urgent
> items, today's most important meeting or priority, my busiest day this week, and remaining
> working days. Organize it into Meetings, Priorities, and Org pulse views. Label each recommended
> action Lean in, Delegate, Re-engage, or Protect time, explain the signal, and give me one clear
> next action. Keep recommendations on workstreams, decisions, and commitments rather than
> individual people. Use expandable sections, traffic-light indicators, and links to the
> supporting emails, meetings, chats, and files. Create a formatted one-page summary of the key
> findings as a printable Word document.

Create the weekday schedule separately, in Cowork Automations, only after the executive confirms
the prompt, run time, time zone, and review behavior (runbook Step 6).
