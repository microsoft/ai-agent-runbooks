# Decision-Maker Concierge reference

Routing settings for `decision-maker-concierge`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Plugin | The Decision-Maker (`decision-maker-cowork-plugin.zip`) | Skills listed below, in startup order |
| Installed scenario skills | All five scenario skills (daily-command-center, board-pre-reads, cited-decision-briefs, exception-analytics, relationship-briefings), plus this concierge | Remove routing rows for skills not deployed. At run time, also confirm each skill is in the session's skill list |
| Companion plugin | The Force Multiplier (`force-multiplier-concierge`) | Route delegate workflows there only if it is installed in the session; otherwise use the no-match response |
| Time zone | [Time Zone] | Used only in schedule notes. If unfilled, use the user's mailbox time zone if readable, else omit it. Never ask the user just for this |

## Plugin directory (routing table)

Trigger phrases match each target skill's own `description` and the runbook trigger routing
matrix. Fill the bracketed slots only with facts the user gave. Leave any other slot bracketed.

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| What needs me today, morning briefing, my day and week, where to lean in | `daily-command-center` | "build my command center" | Yes - weekdays 7:00 AM |
| Board or steering meeting pre-read | `board-pre-reads` | "prepare my board pre-read for [meeting] on [date]" | Yes - 10 business days before; refresh 2 days before. If under 10 business days away, run now on demand |
| Leadership-team or staff meeting pre-read | `board-pre-reads` | "build the leadership pre-read for [meeting] on [date]" | Same as above |
| Should we do X or Y, recommendation with sources | `cited-decision-briefs` | "write me a decision brief on [decision]" | On demand |
| What's off-track, KPI variances, business review prep | `exception-analytics` | "run my exception radar for [period]" | Yes - monthly, 3 business days before the review, or weekly Mondays 8:00 AM. Needs a confirmed KPI workbook and thresholds |
| Prep for a person, company, or topic | `relationship-briefings` | "brief me on [person or company]" | Optional - weekdays 4:00 PM for next-day VIP meetings |
| Routing help | `decision-maker-concierge` | "help me choose" | Never scheduled |

## Routing tests

| If the user says | Route to | Expected trigger phrase |
| --- | --- | --- |
| "Help me choose. I need to get ready for next week's board meeting." | `board-pre-reads` | "prepare my board pre-read for [meeting] next week" |
| "What needs my attention today?" | `daily-command-center` | "build my command center" |
| "Get the board deck ready." | `board-pre-reads` | "prepare my board pre-read for [meeting] on [date]" |
| "Should we expand to [Market]?" | `cited-decision-briefs` | "write me a decision brief on expanding to [Market]" |
| "What changed that needs a decision this month?" | `exception-analytics` | "run my exception radar for this month" |
| "Prep me for my meeting with [Organization]." | `relationship-briefings` | "brief me on [Organization]" |
| "I have a big week, help." | Clarifying question | - |
| "Which of my leaders is underperforming?" | People-rating response | - |
| "Triage my inbox." / "Write my Friday note." | `force-multiplier-concierge` if installed, else no-match response | - |

## Ambiguity rules

1. A named Decision-Maker skill: that skill.
2. "Board", "pre-read", "steering committee", or a "leadership meeting" pack: `board-pre-reads`.
3. One named decision or "X or Y": `cited-decision-briefs`.
4. KPIs, variances, "off-track", or a business review: `exception-analytics`.
5. A named person or organization, or "get me up to speed on [topic]": `relationship-briefings`.
6. "Today" or "this morning" with no named meeting, decision, metric, or organization:
   `daily-command-center`.
7. Nothing above fits (for example, "big week", "help", "I'm swamped"): ask the clarifying
   question.

Tie-break: if two rules fit, choose the one whose output is a single artifact about the named
subject. For example, choose a decision brief over a full pre-read, and a person brief over the
daily command center. Name the other skill as the alternative.

**Clarifying question (only when no rule fits)**

```markdown
Happy to help. Which of these matters most right now?
1. What needs my attention today and this week
2. A board or leadership meeting
3. One decision I need to make
4. What is off-track in my numbers
5. A person or organization I'm meeting
```

Ask it once. Route on the answer without further questions.

## Starter recommendation

New users start with `daily-command-center` (fastest proof of prep-time value), then
`board-pre-reads` against the next real meeting. Suggest `cited-decision-briefs` and
`relationship-briefings` on the license-only path first, and `exception-analytics` once the KPI
workbook and thresholds are confirmed.

## Schedule guidance

Do not create, change, or offer to create a schedule from the concierge. When routing to a
schedule-worthy skill, state the default cadence in one line. Tell the user to confirm the exact
prompt, cadence, and time zone inside that skill. If the default lead time has already passed,
say to run the skill now on demand.

## No-match response

```markdown
I do not have a Decision-Maker skill for <goal> yet. This plugin covers the daily command center,
board pre-reads, cited decision briefs, exception analytics, relationship briefings, and routing
help. <If force-multiplier-concierge is installed: "For delegate work like this, try The Force
Multiplier: say 'help me choose' to force-multiplier-concierge."> I've noted "<goal>" as a
candidate expansion for your admin.
```

"Noted as a candidate expansion" means the request is stated in the reply only. Do not write it
to any file, list, or system.

**People-rating response**

```markdown
I can't rank or rate individual people. I can show where work needs attention instead:
"run my exception radar" for off-track metrics and the decisions they imply, or "build my
command center" for the Org pulse by workstream.
```

## Never-automate list

- Creating, changing, or offering to create schedules or event triggers
- Running sibling skills' outbound actions
- Reading mail, calendar, chat, or files to make a routing decision

## Sharing gate

Not applicable: the concierge produces a routing response only and shares nothing.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Light (routing only) |
| Credit band | Light planning band 100-300 Copilot Credits per run (planning estimate; routing should sit at the low end); routed skills bill separately. Check with `/cost` and record the observed value in the pilot log |

## Example prompt

> Help me choose: I need to get ready for [goal, e.g., next week's board meeting]. Which skill
> should I use and what should I say?
