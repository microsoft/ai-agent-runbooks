# Exception Analytics reference

Customer-tunable settings for `exception-analytics`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them. Any value still shown as `[Placeholder]` is resolved by
`SKILL.md` Workflow step 0 (default, look up, or ask); it is never copied into an output.

## Customer settings

| Setting | Default / placeholder | If unset |
| --- | --- | --- |
| KPI source | [KPI Workbook] or [Business Review Folder] (Excel with targets, polarity, prior values, last-refresh date) | Search OneDrive/SharePoint, ask the user to confirm; none found = stop and ask |
| BI source (optional) | [Power BI report / Fabric semantic model] | Workbook only; no report-grounded claims |
| Metrics in scope | All metrics with a target or prior-period value | Use the default |
| Metric polarity | Workbook column "Better when" (higher / lower) | Ask once for metrics where it is not obvious |
| Comparison basis | vs. target and vs. prior period | Use the default |
| Review period | [Review Period] (month or ISO week) | Last complete period, stated in the output |
| Review meeting | [Business Review Meeting] | Look up on calendar; none = skip agenda and say so |
| Schedule | Monthly, 3 business days before review; or weekly Mondays 8:00 AM | Scheduled prompt, created only after user approval |
| Output folder | [Output Folder] | Local session output or the user's own OneDrive working folder; never a shared location |
| Time zone | [Time Zone] | User's mailbox time zone |

## Rules and thresholds

All variances are relative unless the metric is itself a percentage. "Beyond" means strictly
greater than the threshold.

| Rule | Default | Formula |
| --- | --- | --- |
| Exception vs. target | Beyond ±5% | (actual - target) / target; for % metrics use ±5 percentage points instead and show both |
| Period-over-period exception | Beyond ±10% (monthly) / ±15% (weekly) | (actual - prior) / prior; for % metrics use ±10 pp |
| Trend break | Two consecutive moves in one direction, then a reversal in the review period, with the reversal beyond half the PoP threshold | Ignore smaller reversals as noise |
| Leading indicator turning | Only for metrics flagged "leading" in the workbook; same as trend break | Skip if no metric is flagged |
| Stale data | Review-period value missing, or last refresh earlier than the review-period end date | Data exception; never interpolated |
| Conflicting figures | Two sources differ for the same metric and period | Show both values and cells; compute variance on each; data exception |
| Materiality | [Materiality Threshold] (customer-defined, e.g. "variance worth more than $X" or a tier per metric) | Ask once; if user proceeds, materiality = 1 for all and print `[TBD: Materiality Threshold]` |
| Readout length | 3-5 sections | |

**Ranking score**

Score = magnitude x materiality x time-sensitivity, sorted by severity first, then score.

| Factor | Value |
| --- | --- |
| Magnitude | Largest absolute variance that fired (vs. target or PoP), as a fraction |
| Materiality | 3 = above materiality threshold, 1 = below; 1 for all when `[TBD]` |
| Time-sensitivity | 3 = decision needed before or at the next review, 2 = within the quarter, 1 = watch only |

### Severity scale

| Severity | Rule |
| --- | --- |
| Red | Adverse miss vs. target beyond threshold, and material (or materiality TBD) |
| Amber | Any other adverse signal: PoP swing, trend break, leading indicator turning, or adverse miss below materiality |
| Green | Favorable beat beyond threshold with no adverse signal |

When signals disagree (for example, a beat vs. target with an adverse PoP swing), the adverse
signal sets severity and the tracker shows every rule that fired.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Exception detection time | Days from period close to exceptions identified | Review calendar | Exception detection time |
| Business review speed | Review meeting length and time on decisions | Calendar / notes | Review meeting length |
| Decision latency | Days from exception flagged to decision made | Tracker status | Exception to decision latency |

## Output templates

| Artifact | Layout |
| --- | --- |
| `Exception-Radar-[YYYY-MM].xlsx` (weekly: `[YYYY-Www]`) | Sheet 1 Exception_Tracker: rank, metric, period, actual, target, variance vs target, PoP, prior trend, severity, severity reason, rules fired, driver (cited or "no explanation found"), decision needed, workstream, status, score, number source (file!cell). Sheet 2 Data_Quality. Sheet 3 Settings used (thresholds, materiality, TBDs) |
| Readout | 1 Top exceptions and decisions needed (drivers in the table) 2 Positives worth scaling 3 Data-quality exceptions 4 Files (5 Draft agenda, optional) |
| Draft agenda | Items ordered by decision priority, with time boxes |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [KPI Workbook] | Required unless BI source used | Stop and ask for the workbook; never create one |
| Power BI / Fabric (Fabric IQ plugin) | Optional | Use workbooks only; do not claim report-grounded analytics |
| Finance/ERP, CRM, operations connector | Optional | Use workbook figures; note the gap |
| Mail, Teams, transcripts | Required for drivers | Mark drivers "no explanation found" and list what was searched |

## Never-automate list

- Sharing the readout or tracker
- Emailing exception owners
- Updating meeting agendas or invites
- Writing back to BI, finance, ERP, or CRM systems
- Saving to a shared folder

## Sharing gate

Default state: not shared. Before sharing, show exact recipients, content, label, and confirm the
audience is approved for pre-release financial information. Remove customer names and private
mail or chat detail from the shared readout unless the user approves them.

## Billing

| Item | Value |
| --- | --- |
| Model | Hybrid: starts license-only (USL), moves to usage-based billing (UBB) for the full workflow |
| License-only path (USL) | Analyst on an exported workbook: detection and ranking only; no driver search, tracker file, or agenda; no Cowork credits |
| Cowork full workflow (UBB) | Medium: indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost` |

## Example prompt

> Run my exception radar for September 2026 using the FY27 KPI workbook and any connected BI
> source. Compare against target and prior periods using the thresholds in reference.md, rank
> material exceptions, and find explanations in related emails, Teams threads, and meeting
> transcripts - mark anything unexplained. For each, state the decision leadership needs to make.
> Build an Excel tracker and a short readout for the monthly business review, and flag
> data-quality gaps. Show me the drafts before sharing.
