# Relationship Briefings reference

Customer-tunable settings for `relationship-briefings`. These settings may tighten the guardrails
in `SKILL.md` but never loosen them. Every setting has a working default; a value left as a
`[Placeholder]` uses the default shown.

## Customer settings

| Setting | Default | Placeholder to override | Notes |
| --- | --- | --- | --- |
| History window | Last 12 months | [History Window] | |
| Internal owners | Inferred from threads and invites | [Internal Owners] | Inferred owners are labeled "inferred" |
| External research approved? | **No** | [External Research Approved: Yes/No, approver, date] | Security owner decision. While No, run internal-only and state "No external scan: not approved" |
| CRM | **None** | [CRM system and environment] | Use a CRM only when named here; never auto-discover one |
| VIP schedule | Off | [VIP Meeting Rule] | When enabled: weekdays 4:00 PM local time; default rule = next-day meetings with at least one external attendee |
| Output format | Word `.docx` | | One-page HTML on request |
| File name | `Brief-<Subject>-<YYYY-MM-DD>.docx` | | Date = meeting date; Subject without spaces |
| Output folder | Local session output (not shared) | [Output Folder] | Saving to a shared folder needs approval |
| Time zone | User's mailbox time zone | [Time Zone] | |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Subject ambiguity | Two or more plausible matches: list them and confirm before research |
| Thin history | Fewer than 3 interactions in the window: state "thin history" in At a glance. Override: [n] |
| Sentiment shift | Only when stated in a source; quote it |
| People content | Role, organization, relationship owner, last interaction only; drop personal details found in sources |
| Personal-detail requests | Decline in one sentence; offer the professional view |
| Conflicts | Show both values with sources and mark CONFLICT |
| Sensitive topics | NDA, M&A, litigation, HR, pricing, competitive evaluations: flag "handle carefully"; never in external material |
| Length | At a glance 5 bullets max; brief 2 pages max |

**History coverage minimums**

| Source | Minimum per brief |
| --- | --- |
| Meeting transcripts or recaps with the subject | The 3 most recent read in full; list the rest with dates |
| The executive's own earlier briefs or prep notes on the subject | Search by subject name; cite and build on the latest one |
| Incident, escalation, and support threads naming the subject | Search the window; list each open item |
| Teams chats with the subject's people | Scan for escalations, complaints, and commitments |
| Coverage statement | The Gaps section states what was read in full vs. only listed |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Briefing prep time | Minutes to prepare a brief | User self-report | Briefing prep time |
| Stakeholder readiness | Share of high-stakes meetings with a brief in hand | Calendar sample | Meetings with a brief in hand |
| Meeting effectiveness | Follow-ups and commitments captured and closed | Follow-up log | Commitments captured and closed |

## Output templates

`Brief-<Subject>-<YYYY-MM-DD>.docx` (or one-page HTML): label line; 1 At a glance; 2 Key people;
3 History timeline; 4 Open issues and commitments (ours vs. theirs, conflicts marked); 5 External
context or "no external scan"; 6 Likely asks; 7 Talking points, questions, sensitivities; 8 Gaps,
conflicts, and numbered sources; 9 Requires user confirmation before any follow-up: Yes.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook, Teams, transcripts, files | Required | State "thin or unavailable history" |
| Calendar | Optional | Ask for the occasion and date |
| CRM | Optional (only if named above) | Omit account, opportunity, and case history; note the gap |
| Public web and news | Optional (only if approved above) | Internal-only brief; note no external scan |

## Never-automate list

- Sending follow-ups, emails, or invites
- Writing to CRM or other business systems
- Sharing internal-only content with external parties
- Saving the brief to a shared location

## Sharing gate

Default state: not shared. Before sharing, show exact recipients, content, and a warning if the
brief contains internal-only, NDA, or private mail and meeting content.

## Billing

| Item | Value |
| --- | --- |
| Model | USL (Microsoft 365 Copilot license) |
| Intensity | Included (Copilot Chat) for the in-chat brief |
| Cowork run | Light (100-300 credits) for a brief saved as a file; Medium if many transcripts are read. Check with `/cost` |

## Example prompt

> Brief me on [Topic / Person / Organization] ahead of [Meeting or Occasion] on [Date]. My
> objective is [Objective]. Use our emails, Teams chats, meeting transcripts, and shared files
> from the last [History Window], plus approved public news and any configured CRM. Give me a
> history timeline, open issues and commitments on both sides, external context, their likely
> asks and ours, and talking points. Cite everything, label inference, and flag gaps and
> conflicts. Keep it to two pages.
