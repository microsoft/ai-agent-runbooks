# The Force Multiplier Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Force Multiplier (Chief of Staff / Executive Business Partner) · **Function:** Executives
**Runbook:** `cowork-force-multiplier-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  force-multiplier-concierge/
    SKILL.md
    reference.md
  weekly-synthesis/
    SKILL.md
    reference.md
  cross-org-leadership-brief/
    SKILL.md
    reference.md
  inbox-triage-at-scale/
    SKILL.md
    reference.md
  delegated-memo-and-deck/
    SKILL.md
    reference.md
  out-of-office-handoff/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `force-multiplier-concierge` | Routes a Chief of Staff or Executive Business Partner to the right Force Multiplier skill |
| `weekly-synthesis` | Synthesizes the leader's week of meetings (saved-skill alias "Week in Review") into a draft week-in-review email to direct reports: key decisions, recurring themes, risks and blockers, commitments with owners and due dates, next-week priorities, areas needing executive attention, and action callouts by workstream, each cited to its meeting or thread |
| `cross-org-leadership-brief` | Builds a recurring cross-org leadership brief from Teams channels, status documents, trackers, program meetings, and email: per-initiative progress, evidence-based RAG with change since the prior brief, risks, cross-team dependencies, consolidated leadership asks, and flagged gaps and conflicting status |
| `inbox-triage-at-scale` | Triages the leader's mail and Teams backlog at scale |
| `delegated-memo-and-deck` | Turns the leader's notes, data, prior materials, and voice guidance into a finished leadership artifact: a Word memo, a PowerPoint deck on the organization's template, or both |
| `out-of-office-handoff` | Prepares an out-of-office leadership handoff before the leader's time off |

Start with `force-multiplier-concierge` if you are not sure which skill to use. Recommended starters: `weekly-synthesis` and `cross-org-leadership-brief`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
