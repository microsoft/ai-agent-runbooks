# Cross-Org Leadership Brief reference

Customer-tunable settings for `cross-org-leadership-brief`. These settings may tighten the
guardrails in `SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Initiatives | [Initiative List] | Each with [Initiative Owner Workstream] |
| Status sources | [Status Sources] | Teams channels, SharePoint sites, trackers per initiative |
| Reporting period | Last 7 days | [Reporting Period] |
| Audience | [Audience] | e.g., executive leadership team |
| Distribution channel | [Leadership Channel] or [Distribution List] | Draft only until approved |
| Prior brief | [Prior Brief] | For change tracking |
| Schedule | Mondays 8:00 AM | Or the day before the leadership meeting |
| Output format | Word (default) or PowerPoint | |
| Time zone | [Time Zone] | |

## Rules and thresholds

### RAG model

| RAG | Meaning | Typical signals |
| --- | --- | --- |
| Green | On plan | Milestones met, no open blocker |
| Amber | Needs active management | Slip risk, open dependency, unclear owner |
| Red | Needs leadership intervention | Missed milestone, blocked dependency, decision stalled |
| No recent signal | No activity in the period | Never shown as Green |

| Rule | Default |
| --- | --- |
| Stale source | No update in [Reporting Period] |
| Conflicting status | Two sources disagree on RAG or milestone: show both and flag |
| Blocked dependency age | Report days open; highlight beyond [n] days |
| Top line | 3-5 bullets |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Status reporting time | Hours per week compiling cross-org status | Delegate time study | Status compilation time |
| Risk visibility | Risks surfaced before they became issues | Brief history vs. issue log | Add to baseline: risks surfaced early |
| Dependency resolution rate | Days a cross-org dependency stays blocked | Program trackers | Dependency blocked time |

## Output templates

| Artifact | Layout |
| --- | --- |
| `Leadership-Brief-[Week]` (Word or PowerPoint) | 1 Top line 2 Portfolio table 3 Dependencies and blockers 4 Leadership asks 5 Gaps and conflicting signals 6 Sources appendix |
| Distribution draft | Subject: Leadership Brief - [Week]. Body: top line, link, asks needing a decision by date |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Teams channels and chats | Required | Mark initiative "no recent signal" |
| SharePoint/OneDrive status docs, Planner/Lists | Required | Note stale or missing source |
| Program transcripts and email | Optional | Use channel and tracker evidence only |
| Azure DevOps, Jira, Smartsheet | Optional | State the tracker is not reachable; do not infer status |

## Never-automate list

- Sending or posting the brief
- Updating trackers, Planner, Lists, or work-management systems
- Sharing private-channel content beyond its members

## Sharing gate

Default state: not sent or posted. Before distribution, show exact recipients or channel, content,
attachment, and a warning if private-channel or labeled content is included.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| Credit band | Indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost` |
| License-only starter | None; multi-source recurring roll-up needs Cowork |

## Example prompt

> Build this week's cross-org leadership brief for [Audience] covering [Initiative List]. Use the
> Teams channels, status docs, trackers, meeting transcripts, and email in [Status Sources] from
> [Reporting Period]. For each initiative give RAG status with rationale and change since [Prior
> Brief], progress, risks, next milestones, and dependencies; consolidate the asks for leadership.
> Cite sources and flag stale or conflicting status. Show me the draft before sharing, and
> schedule it every Monday at 8 a.m.
