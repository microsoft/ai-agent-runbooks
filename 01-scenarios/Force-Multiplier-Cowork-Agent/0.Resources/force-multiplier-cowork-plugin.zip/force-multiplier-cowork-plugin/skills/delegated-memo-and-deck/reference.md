# Delegated Memo and Deck reference

Customer-tunable settings for `delegated-memo-and-deck`. These settings may tighten the guardrails
in `SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Templates | Org standard Word and PowerPoint templates | [Template] from the org template library |
| Voice guidance | Inferred from the leader's recent sent memos | [Voice Guidance]: tone, length, words to avoid |
| Voice samples | [Voice Samples Folder] | Optional folder of approved past artifacts |
| Output folder | [Output Folder] | Draft save location |
| Default length | [Length] | e.g., 1-page memo, 8-slide deck |
| Recurring run | Off; optional first Monday of each month 9:00 AM | For recurring comms such as all-hands updates |
| Time zone | [Time Zone] | |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Storyline | Situation, complication, resolution, asks |
| Outline check | Share outline first when long or high-stakes |
| Deck length | Title, executive summary, 4-10 content slides, asks, sources appendix |
| Memo structure | Headline, bottom line up front, body, asks/next steps, footnoted sources |
| Missing fact | Visible `[TBD: ...]`; never invented |
| External audience | Remove internal-only data; warn if label exceeds audience |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Artifact turnaround time | Hours from notes to approved artifact | Version history | Memo or deck turnaround |
| Executive review cycles | Revision rounds before approval | Version history | Memo or deck turnaround (rounds) |
| Communication quality | Stakeholder feedback on clarity | Feedback sample | Add to baseline: clarity feedback |

## Output templates

| Artifact | Layout |
| --- | --- |
| Memo `[Topic]-Memo-[Date].docx` | Headline; bottom line; body sections; asks/next steps; footnoted sources |
| Deck `[Topic]-[Date].pptx` | Title; executive summary; 4-10 content slides; asks; appendix with sources; speaker notes in the leader's voice |
| Review note | Placeholders to fill; assumptions; conflicts; open questions |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| [Notes] | Required | Ask for notes |
| [Source Files / Data] | Optional | Use notes only; mark figures [TBD] |
| Org template library | Optional | Use default Office template and note it |
| BI or finance connector | Optional | Use workbook charts; note data date |

## Never-automate list

- Sharing, posting, emailing, or publishing the artifact
- Writing to business systems
- Sending to external audiences

## Sharing gate

Default state: not shared or published. Before any share, show exact recipients or channel,
content, sensitivity label, and a warning if the audience exceeds the label.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium |
| License-only starter | Copilot in Word or PowerPoint drafts from a file or notes |
| Credit band | Cowork full workflow: indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost` |

## Example prompt

> Turn [Notes] into a [Artifact Type] for [Audience] whose purpose is to [Purpose]. Use [Source
> Files / Data] for facts and charts, write in my voice based on [Voice Guidance] and my recent
> memos, and use our [Template]. Keep it to [Length]. Cite figures, mark anything missing as
> [TBD], and show me the draft with a list of open questions.
