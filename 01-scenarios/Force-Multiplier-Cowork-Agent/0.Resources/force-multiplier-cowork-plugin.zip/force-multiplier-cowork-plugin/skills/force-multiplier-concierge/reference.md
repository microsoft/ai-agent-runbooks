# Force Multiplier Concierge reference

Routing settings for `force-multiplier-concierge`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Plugin | The Force Multiplier (`force-multiplier-cowork-plugin.zip`) | Skills listed below, in startup order |
| Installed skills | All five | Remove rows for skills not deployed |
| Companion plugins | The Decision-Maker (`decision-maker-concierge`); Chief of Staff (`leader-concierge`) | Route there only if installed |
| Leader supported | [Leader Name / Role] | Context for routing; no data access implied |
| Time zone | [Time Zone] | Used only when describing schedules |

## Plugin directory (routing table)

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Close the week, Friday note, what did we decide | `weekly-synthesis` | "synthesize my week" | Yes - Fridays 5:00 PM PST |
| Status across priority programs, dependencies stuck | `cross-org-leadership-brief` | "build the cross-org leadership brief" | Yes - Mondays 8:00 AM |
| Inbox or Teams backlog, what can I delegate | `inbox-triage-at-scale` | "triage my inbox" | Yes - weekdays 7:30 AM and 4:00 PM, or backlog trigger |
| Notes into a memo, deck, or all-hands update | `delegated-memo-and-deck` | "turn my notes into a memo" | On demand (optional monthly) |
| Coverage, delegations, auto-replies before time off | `out-of-office-handoff` | "prepare my out-of-office handoff" | Per absence |
| Routing help | `force-multiplier-concierge` | "help me choose" | On demand |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "Draft the Friday note to the directs." | `weekly-synthesis` |
| "Where are the cross-team dependencies stuck?" | `cross-org-leadership-brief` |
| "She's back from travel; clear the backlog." | `inbox-triage-at-scale` |
| "Make this a deck for the all-hands." | `delegated-memo-and-deck` |
| "He's out next week; set up coverage." | `out-of-office-handoff` |
| "What needs my attention today?" / "Board pre-read" | `decision-maker-concierge` (if installed) or no match |
| "Leader 360" / "Team pulse" | `leader-concierge` (Chief of Staff plugin, if installed) or no match |

## Ambiguity rules

- Looking back on the week's meetings: `weekly-synthesis`; across initiatives and programs:
  `cross-org-leadership-brief`.
- Backlog after return: `inbox-triage-at-scale`; preparing before leaving: `out-of-office-handoff`.
- "Write", "memo", "deck", or "update in my voice" with notes supplied: `delegated-memo-and-deck`.
- If two still fit after the rules above and the user's words do not decide between them, ask one
  concise question offering only those candidates (by outcome) and wait for the answer. Do not
  recommend, list, or invoke a skill until it is answered.
- Only after intent is resolved may a secondary skill be mentioned as "also useful later".

## Starter recommendation

New users start with `weekly-synthesis` (proves action-closure value in the first week), then
`cross-org-leadership-brief` against the real initiative list. Add `inbox-triage-at-scale` once
delegate access and the VIP list are confirmed (on demand before triggers), and start
`delegated-memo-and-deck` and `out-of-office-handoff` on the license-only path.

## Schedule guidance

Do not create a schedule or event trigger. When routing to a schedule-worthy skill, state the
default cadence and tell the user to confirm the exact prompt and cadence in that skill.

## No-match response

```markdown
I do not have a Force Multiplier skill for <goal> yet. This plugin covers weekly synthesis,
cross-org leadership briefs, inbox triage, delegated memos and decks, out-of-office handoffs, and
routing help.
```

## Never-automate list

- Creating or changing schedules or event triggers
- Running sibling skills' outbound actions

## Sharing gate

Not applicable: the concierge produces a routing response only and shares nothing.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Light (routing only) |
| Credit band | Light planning band 100-300 Copilot Credits per run; routed skills bill separately. Check with `/cost` |

## Example prompt

> Help me choose: I support [Leader Name / Role] and need to [goal, e.g., get ahead of next week's
> status chasing]. Which skill should I use and what should I say?
