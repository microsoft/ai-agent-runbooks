# Inbox Triage at Scale reference

Customer-tunable settings for `inbox-triage-at-scale`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Backlog window | Since last triage or last 3 days | [Backlog Window] |
| VIP list | Manager, direct reports, board, top external contacts | [VIP List] |
| Delegates | [Delegates] | e.g., Chief of Staff, function leads |
| Scopes | Inbox, Focused, @mentions, 1:1 and group chats | [Folders / Channels in Scope] |
| Trigger threshold | Off | [Trigger Threshold], e.g., unread count above an agreed number |
| Schedule | Weekdays 7:30 AM and 4:00 PM | Scheduled prompt or event trigger |
| FYI / Noise folders | [FYI Folder], [Noise Folder] | Moves only on approval |
| Time zone | [Time Zone] | |

## Rules and thresholds

### Categories

| Category | Use when |
| --- | --- |
| Decide | Needs the leader's call |
| Reply | Needs the leader's voice |
| Delegate | Someone else should own it |
| FYI | Read-only |
| Noise | Newsletters, automated notifications |

### Priority

| Rule | Default |
| --- | --- |
| Sender importance | [VIP List] first |
| Deadline | Stated deadline within [n] days ranks higher |
| Business impact | Decision, customer, or financial impact ranks higher |
| Age | Older unresolved items rank higher at equal priority |
| Already resolved | Later message closes the ask: mark resolved |
| Excluded | Legal-hold, HR-flagged, encrypted items: skip automated handling |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Inbox backlog reduced | Unread count before vs. after triage | Outlook counts | Inbox backlog |
| Response time | Median time to respond to VIP and decision items | Mail/Teams sample | Response time to VIP and decision items |
| Delegation completion rate | Delegated items closed within agreed time | Delegation log | Delegated items closed on time |

## Output templates

| Artifact | Layout |
| --- | --- |
| `Inbox-Triage-[Date]` (HTML or Word) | 1 Counts and time-saved estimate 2 Ranked decision queue 3 Reply drafts 4 Delegations 5 FYI digest and resolved items |
| Reply draft | Greeting, answer or decision, next step, sign-off in the leader's voice |
| Delegation note | Context, expected outcome, deadline, source link |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook mail | Required | Stop and report |
| Teams chats and @mentions | Required | List as not triaged |
| Calendar, org chart | Optional | Skip meeting links; ask for [Delegates] |
| Ticketing or approval system | Optional | Note pending approvals not retrieved |

## Never-automate list

- Sending, forwarding, or replying to mail or Teams messages
- Deleting, moving, flagging, or categorizing mail
- Accepting or declining meetings
- Forwarding labeled or encrypted content to delegates
- Handling legal-hold or HR-flagged items

## Sharing gate

Default state: nothing sent, moved, or saved as Outlook drafts. Before any action, show exact
recipients, content, and the action, item by item or as an approved bulk list.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| Credit band | Indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost`; review event-trigger frequency against per-user limits |
| License-only starter | None; cross-channel backlog triage needs Cowork |

## Example prompt

> Triage my inbox and Teams messages from [Backlog Window]. Collapse duplicate threads, then sort
> everything into Decide, Reply, Delegate, FYI, and Noise, prioritizing [VIP List] and anything
> with a deadline. Draft replies in my voice for Reply items and delegation notes to [Delegates]
> for Delegate items. Give me a ranked decision queue with links. Don't send, move, or delete
> anything until I approve.
