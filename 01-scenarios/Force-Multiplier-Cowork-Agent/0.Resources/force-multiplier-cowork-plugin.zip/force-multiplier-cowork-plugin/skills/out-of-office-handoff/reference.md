# Out-of-Office Handoff reference

Customer-tunable settings for `out-of-office-handoff`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Absence dates | [OOO Start], [OOO End] | From calendar when possible |
| Delegates | [Delegates] by workstream | e.g., Chief of Staff, function leads |
| Decision authority | [Decision Authority] | What delegates may decide vs. hold or escalate |
| Emergency contact rule | [Emergency Contact Rule] | When and how to reach the leader |
| Lookback window | Last 2 weeks | [Lookback Window] |
| Schedule | 3-5 business days before; refresh afternoon before; return-day 7:00 AM | Per absence |
| Output folder | [Output Folder] | Handoff document and tracker |
| Time zone | [Time Zone] | |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Meeting disposition | Attend-by-delegate if a delegate owns the workstream; reschedule if the leader's decision is required; decline if informational |
| Uncovered deadline | Due during absence with no delegate: Red risk |
| Single point of failure | Workstream with one person and no backup: flag |
| Restricted document | Delegate lacks access: "executive-only, held until return" |
| Return re-entry | Schedule `inbox-triage-at-scale` on return day (draft schedule only) |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Handoff prep time | Hours to prepare coverage | Delegate self-report | Handoff prep time |
| Coverage continuity | Items dropped or escalated late during absence | Post-absence review | Items dropped during absence |
| Return-to-productivity time | Days to clear backlog after return | Outlook counts | Days to clear backlog after return |

## Output templates

| Artifact | Layout |
| --- | --- |
| `OOO-Handoff-[Dates].docx` | Summary; coverage matrix; work in flight with links; meetings with disposition; risks and gaps; emergency contact rule |
| Coverage tracker (optional Excel) | Item, workstream, delegate, due date, status |
| Internal auto-reply | Dates, coverage by topic with delegate names, emergency rule |
| External auto-reply | Dates and a general contact; no internal detail |
| Return-priorities brief | Waiting items, first-week meetings, re-entry plan |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook Calendar and mail | Required | Stop and report |
| Teams, transcripts, files | Required | Note gap in risks |
| Org chart | Optional | Ask for [Delegates] |
| Approval or workflow system | Optional | List the system as a coverage gap |

## Never-automate list

- Sending handoff notes, announcements, or stakeholder messages
- Setting internal or external auto-replies
- Forwarding invites, rescheduling, or declining meetings
- Granting mailbox or calendar delegation
- Sharing restricted documents with delegates

## Sharing gate

Default state: nothing sent or set. Before any action, show exact recipients, content, the
auto-reply text and dates, and each meeting change, with a private-data warning.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Light |
| License-only starter | Copilot in Outlook drafts the handoff note |
| Credit band | Cowork full workflow: indicative 100-300 Copilot Credits per run; actual use varies. Check with `/cost` |

## Example prompt

> I'm out from [OOO Start] to [OOO End]. Prepare my out-of-office handoff: find open decisions,
> commitments, pending approvals, and awaiting-reply threads from the last [Lookback Window], and
> every meeting during my absence. Group work in flight by workstream and propose coverage by
> [Delegates] with [Decision Authority]. Draft delegate handoff notes, a team announcement, and
> internal/external auto-replies, plus a return-priorities brief. Show me everything before
> sending, setting auto-replies, or changing meetings.
