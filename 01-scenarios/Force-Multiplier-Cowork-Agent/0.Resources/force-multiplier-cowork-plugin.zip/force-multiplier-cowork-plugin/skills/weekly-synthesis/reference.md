# Weekly Synthesis reference

Customer-tunable settings for `weekly-synthesis`. These settings may tighten the guardrails in
`SKILL.md` but never loosen them.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Time period | Monday through today of the current week | [Time Period] |
| Recipients | The user's direct reports (org chart) | [Recipients] |
| Excluded meetings | Personal, HR, and confidential 1:1s | [Excluded Meetings] |
| Run time | Fridays 5:00 PM PST | [Run Time]; use local equivalent |
| Time zone | [Time Zone] | |
| Tracker | Off | Optional one-tab Excel commitments tracker |
| Operator | [Chief of Staff / EBP] | Runs on the leader's behalf within delegated access |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Recurring theme | Seen in 3+ meetings: flag |
| Low-evidence meeting | No transcript or recap: summarize from invite, chat, and mail only; footnote |
| Friction signal | Conflicting direction, confusion, or a missing decision across sources |
| Length | At most one page |
| Callout scope | Workstream owner + expected action + date |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Meeting synthesis time | Minutes to produce the weekly note | Delegate self-report | Weekly synthesis time |
| Action closure rate | Share of commitments closed by due date | Commitment tracker | Action closure rate |
| Decision follow-through | Decisions revisited without new information | Meeting recaps | Decisions revisited |

## Output templates

| Artifact | Layout |
| --- | --- |
| Email `Week in Review - [Week of Date]` | 1 Key decisions 2 Recurring themes 3 Risks and blockers 4 Commitments 5 Next-week priorities 6 Executive-attention areas 7 Action callouts 8 Sources footnote |
| Tracker (optional) | Item, owner, due date, source |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Outlook Calendar | Required | Stop and report |
| Meeting transcripts | Required where available | Mark meeting low-evidence |
| Teams, Outlook, files | Required | Note gap in footnote |
| Org chart | Optional | Ask for [Recipients] |

## Never-automate list

- Sending the Week in Review email or Teams posts
- Writing to task or business systems
- Forwarding restricted meeting content

## Sharing gate

Default state: not sent. Before sending, show exact recipients, content, and a private-data warning
if the note uses chat, calendar, or restricted meeting content.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| Credit band | Indicative 300-700 Copilot Credits per run; actual use varies. Check with `/cost` |
| License-only starter | None; cross-meeting synthesis needs Cowork |

## Example prompt

> Review my meetings from [Time Period] and use the related meeting transcripts, Teams
> conversations, emails, and files connected to those discussions. Identify the most important
> decisions made, open questions that remain unresolved, risks, blockers, or dependencies that
> surfaced repeatedly, themes that appeared across multiple meetings, and areas where there is
> confusion, conflicting direction, or a missing decision. Create a week-in-review email covering
> key decisions, recurring themes, risks and blockers, important commitments made, priorities for
> next week, and areas that require executive attention. Highlight anything that appeared
> repeatedly across multiple meetings. Keep it concise and focused on what matters most rather
> than summarizing every meeting. Send this review to [Recipients], calling out areas they need to
> respond to or act upon heading into next week. Show me the draft before sending. Save this
> process as a skill named [Weekly Synthesis] and run it at the end of each week at [Run Time].
