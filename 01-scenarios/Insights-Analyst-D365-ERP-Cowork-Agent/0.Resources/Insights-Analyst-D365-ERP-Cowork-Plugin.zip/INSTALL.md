# Insights Analyst_D365 ERP - install and first run

## Prerequisites

- **Access to Dynamics 365 finance and operations instance** - an active, licensed user in the target Dynamics 365 Finance and Operations environment, set
  up as a user in each company / legal entity you will run against.
- **Necessary access to modules within the ERP system** - the Dynamics 365 licence and the security roles, duties and privileges for the module(s) in
  scope (Finance, Supply Chain Management). Every output reflects exactly what your own role-based access grants;
  the plugin never elevates or works around a permission boundary.
- **Ensure the Microsoft published Dynamics 365 ERP plugin enabled** - the Microsoft-published **Dynamics 365 ERP** plugin must be added to Copilot Cowork and
  connected to the approved Dynamics 365 Finance and Operations environment, signed in with your own Microsoft
  Entra ID account (never a shared or service account). All 11 skills in this package read through that
  one connection; none carries its own credential.
- Copilot Cowork itself must be enabled for your account by your administrator.
- Optional, for the email follow-up: Microsoft 365 Outlook access enabled for you in Cowork. Emails go only to your own
  mailbox and only after you approve the send.

## Install

1. Open Copilot Cowork and go to **Customize > Plugins**.
2. Choose **Upload plugin** and select `Insights-Analyst-D365-ERP-Cowork-Plugin.zip`.
3. Confirm the plugin appears as **Insights Analyst_D365 ERP** and switch it on for your conversations.
4. Make sure the **Dynamics 365 ERP** plugin is also on and connected (gear icon next to it > choose your
   environment > sign in if prompted). The first ERP query in a conversation will prompt you to connect if you
   have not done so.
5. If you previously installed this package as loose skills (version 1.x), remove those skills first so the two
   copies do not compete.
6. Optionally install **Chief of staff_D365 ERP**; the two packages hand off to each other and are designed to be used together.

## First run

Start a **new** conversation (skill descriptions are loaded when a conversation starts) and type the demo prompt:

> "Give me the daily cash position and liquidity report." - the report asks once for the company / legal entity and the Dynamics 365 URL, then delivers the HTML report.

What you should see, in this order:

1. The skill asks you once for two inputs: the **company / legal entity** (for example a company code) and your
   **Dynamics 365 Finance and Operations URL** (the address you sign in to). Later prompts in the same conversation
   reuse both without asking; a new conversation asks again.
2. A short summary in the chat, plus a self-contained **HTML** file - the default deliverable - following the
   skill's visual standard (header band with legal entity and query timestamp, colour-coded cards, one section per
   table, callout boxes for the summary and source gaps).
3. Every row shows the record's own business number as plain text - order, invoice, journal, requisition, account
   or item number - so you can find it in Dynamics 365 in seconds. Nothing is a hyperlink, and internal IDs or GUIDs
   are never shown. The header band repeats the legal entity and the environment URL exactly as you entered them.
4. One follow-up question: **"Would you like (1) an editable Word (.docx) version, (2) this emailed to you, and/or
   (3) a scheduled run emailed to you?"** The Word version is written from the same data as the report you just
   received (no second query) as a structured document and is checked to be populated before it is offered. The email goes to your own address only - you see recipient, subject, summary and attachments and approve
   the send first. A scheduled run re-runs the same prompt on its natural cadence and emails it to you; each run asks you to approve its email before it is sent (approving the schedule or an earlier email does not approve the next one), and you can change or stop it in Cowork at any time.

Nothing is written to Dynamics 365 at any point. The only outbound action is the email to your own address, and only
after your approval. If Microsoft 365 Outlook access is not enabled for you in Cowork, the skill says so and skips it.

## Skills in this package

- `insights-analyst-concierge`
- `ap-payment-readiness-pulse`
- `ar-aging-collections-pulse`
- `cash-liquidity-pulse`
- `close-readiness-analytics`
- `inventory-health-pulse`
- `pl-budget-variance-report`
- `procurement-po-health-pulse`
- `production-planning-pulse`
- `supplier-performance-report`
- `warehouse-fulfillment-pulse`

### Prompt-to-skill quick reference

| Prompt | Skill | What you get in seconds |
| --- | --- | --- |
| "Give me the daily cash position and liquidity report." | `cash-liquidity-pulse` | Bank balances, 7/14-day cash forecast, unreconciled lines |
| "Give me the weekly AR ageing and collections report." | `ar-aging-collections-pulse` | Ageing buckets, DSO, top-10 overdue customers |
| "Give me the weekly AP ageing and payment-run readiness report." | `ap-payment-readiness-pulse` | AP ageing, DPO, payment-run due list, holds |
| "Give me the monthly P&L, trial balance, and budget vs actual report." | `pl-budget-variance-report` | Revenue, COGS and margin, top-5 budget variances |
| "Give me the monthly period-end close readiness report." | `close-readiness-analytics` | Ledger status by module, blockers ranked |
| "Give me the weekly inventory health report." | `inventory-health-pulse` | On-hand value, turns, days of supply, slow movers |
| "Give me the weekly procurement and open-PO health report." | `procurement-po-health-pulse` | Open and late POs, requisition queue, purchase price variance |
| "Give me the monthly supplier performance report." | `supplier-performance-report` | OTIF, delay days, rejection and mismatch rates by vendor |
| "Give me the weekly production and master-planning status report." | `production-planning-pulse` | Late orders, shortages, action messages, capacity load |
| "Give me the daily warehouse and fulfilment operations report." | `warehouse-fulfillment-pulse` | Open work, pending loads, backorders, count variances |

Fastest for a first run or a demo: the daily cash and warehouse reports and the weekly AR report (single-module reads with many visible rows). The monthly supplier performance report sweeps several modules and takes longer - run it after the quick ones. Trend needs a stored snapshot, so a first run says "trend not yet available"; run one report twice to show movement. If Cowork asks to approve storing the snapshot, check the path and file name and approve that write; declining keeps it in the Output folder and the next run shows no trend. One conversation, one question: the first prompt asks for the legal entity and environment URL; the rest reuse them.

Each skill's `SKILL.md` lists its demo prompt, other ways to ask, required inputs, workflow, output format, record
identifier rule, visual standard and guardrails; its `reference.md` holds the definitions, the data the skill reads
(never asked of the user), the record identifiers shown, scope resolution and hand-off table. The package `README.md` describes
the package standards.

## Troubleshooting

| Symptom | What to do |
| --- | --- |
| The plugin shows "Disabled by your organization's administrator" | Ask your administrator to enable Copilot Cowork plugins and the Dynamics 365 ERP plugin for your tenant. |
| The skill reports a source gap or "not available from the connected source" | Check that you are a user in that legal entity and hold the module's security roles; the skill never substitutes another company or sample data. |
| You want to switch company or environment mid-conversation | Say so in your next prompt (for example "switch to company <code>"); the skill confirms the new value and uses it from then on. |
| You expected clickable links to Dynamics 365 records | By design the outputs carry no hyperlinks; every row shows the record's business number, which you can paste into Dynamics 365 search or a list page filter. |
| The Word version is empty or missing sections | Re-run with the current package: the skill writes the document from the report data as structured content and verifies it is populated before offering it; if it still cannot, it says so and the HTML remains the deliverable. |
| The email follow-up is declined or fails | Microsoft 365 Outlook access must be enabled for you in Cowork; the email is only ever addressed to your own mailbox and is sent only after you approve it. |
| A scheduled run did not arrive | Open Cowork's scheduled runs, check the schedule is still active and that its prompt text states the legal entity, the environment URL and "email the result to me". |
| The wrong package answered (a report instead of a brief, or the reverse) | Use the demo prompt wording; briefs are "Run the ... brief", reports use the official report name. Both routers hand off to each other. |
| Nothing happens after changing skills | Start a new conversation; descriptions are read at conversation start. |
