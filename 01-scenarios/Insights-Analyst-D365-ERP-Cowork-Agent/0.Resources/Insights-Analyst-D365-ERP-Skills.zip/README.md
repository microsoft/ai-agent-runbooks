# Insights-Analyst-erp

A Finance and Supply Chain Management (SCM) **Insights Analyst** skill package grounded
directly in the Dynamics 365 ERP plugin: daily, weekly, and monthly KPI trend reports - cash and
liquidity, receivables and payables, P&L and budget variance, close readiness, inventory,
procurement, supplier performance, production and planning, and warehouse fulfillment - plus
skill routing. Independent of the Chief-of-staff-erp package and of any Power BI/Fabric-based
Insights Analyst packages; install any or all.

**Version 1.1.3.** Snapshots are now keyed by legal entity and environment URL, not legal entity
alone: a sandbox and a production environment that share the same company code (for example USMF)
never match each other's prior snapshot, because the same code can sit in front of different
settings, structure and data in each environment. The cash-flow forecast-precedence rule now
matches by source document across one or more forecast entries (so a split invoice, for example
6,000 and 4,000 forecast entries against one 10,000 invoice, is still recognized and not
double-counted), and the worked example is marked as illustrative rather than a reconciliation
guarantee. `ap-payment-readiness-pulse` and `ar-aging-collections-pulse` now name the posted
invoice lines they retrieve for DPO/DSO explicitly in the workflow's data-retrieval step, not only
in the KPI definition.

**Version 1.1.2.** Before generating, emailing, or saving a report, the skill confirms the plugin's
connected environment and legal entity against what was entered and pauses with a source gap if
either cannot be confirmed; a sandbox and a production environment sharing the same company code
are treated as different environments and never compared. Cash and liquidity pulse now states that
a cash-flow forecast entry takes precedence over a matching open transaction, so an invoice is
never counted twice. AR and AP aging buckets are mutually exclusive (adding a Not yet due bucket)
and reconcile to the full open balance; DSO/DPO name their posted-invoice source, lookback period
and currency basis, and report "not computable" when that source is unavailable or sums to zero.
Clarifies that the 20,000-character `SKILL.md` figure is a recommended authoring target, not
Cowork's platform limit (1 MB per `.md` skill file). Skill names and KPI logic are otherwise
unchanged.

**Version 1.1.1.** Every scheduled run now requests approval before its email is sent; approval of a schedule or of an earlier send no longer covers the next send, and a declined or unanswered send leaves the report in the session Output folder. Every skill declares `license: MIT` and the package includes the MIT licence notice as `LICENSE`. Storing a snapshot outside the session Output folder now needs approval for that write only, after the path and file name are shown. Skill names, logic and KPI definitions are unchanged.

**Version 1.1.0.** Adds an explicit hand-off to the Chief-of-staff-erp package in every skill description,
asks once per conversation for the company / legal entity and the environment URL, delivers a self-contained HTML file by
default and offers a Word (.docx) version once the results are generated, and restates the prerequisites.

## Reports, not briefs

This package produces recurring KPI **reports**: cadence-driven, entity-wide, trend-aware. It never produces
chief-of-staff **briefs** - attention lists, approval and decision queues, week-ahead views, customer and
supplier call preparation, order traces - those belong to the Chief-of-staff-erp package. Rule of thumb for
users: if the answer belongs in a report, say "report" or "pulse"; if it belongs in your inbox or your to-do
list, say "brief". Keep both packages installed; they are designed to be used together (a report flags a
customer, a brief preps the call).

This package is the **D365-ERP-native** variant of the Insights Analyst scenario: instead of
reading a Power BI report or Fabric semantic model, every skill queries the Dynamics 365 ERP
plugin directly for raw rows and computes each KPI, trend, and flag in the skill itself.

## Skills

| Skill | Purpose |
| --- | --- |
| `insights-analyst-concierge` | Front door that routes the user's goal to the right Insights-Analyst-erp skill |
| **Finance** | |
| `cash-liquidity-pulse` | Daily cash position and liquidity: bank balances, net movement, 7/14-day cash forecast |
| `ar-aging-collections-pulse` | Weekly AR aging, DSO, top overdue customers, credit-limit and dispute flags |
| `ap-payment-readiness-pulse` | Weekly AP aging, DPO, 7/14-day payment-run ledger, discounts at risk, holds and match exceptions |
| `pl-budget-variance-report` | Monthly P&L, budget-vs-actual variance by account/dimension, top-5 variances, MoM/YoY trend |
| `close-readiness-analytics` | Monthly period-end close readiness trend, ranked blocker list, days-to-close |
| **Supply Chain Management** | |
| `inventory-health-pulse` | Weekly on-hand value, turns, days of supply, stock-level exceptions, slow-moving/obsolete |
| `procurement-po-health-pulse` | Weekly open-PO health, late POs, requisition-approval queue, spend and purchase price variance |
| `supplier-performance-report` | Monthly vendor scorecard: OTIF, delay days, quality rejection rate, invoice-match rate, lead time |
| `production-planning-pulse` | Weekly production order status, master-planning messages, shortages, capacity load |
| `warehouse-fulfillment-pulse` | Daily warehouse work, pending shipments, backorders, transfers in transit, cycle-count variances |

## Folder standard

Each skill folder contains:

- `SKILL.md` - the executable skill definition, workflow, output format, and guardrails
- `reference.md` - KPI definitions, the data the skill reads (never asked of the user), the record identifier
  rule, the snapshot/trend rule, scope-resolution rules, output delivery rule and hand-off table

## Prerequisites

- **Access to Dynamics 365 finance and operations instance**
- **Necessary access to modules within the ERP system**
- **Ensure the Microsoft published Dynamics 365 ERP plugin enabled**

In detail:

- **Finance / SCM instance access.** The user must have an active, licensed account in the target
  Dynamics 365 Finance and Operations environment, and must be set up as a user in the specific
  legal entity (company) that the report is scoped to. A user who is not added to a company
  cannot retrieve that company's data, regardless of what the request asks for.
- **License and RBAC.** The user must hold the Dynamics 365 ERP license required for the
  module(s) in scope - Finance or Supply Chain Management - and must be assigned the security
  roles, duties, and privileges needed to view the relevant records. Every output reflects
  exactly what the user's role-based access control (RBAC) already grants; the package never
  elevates, bypasses, or works around a permission boundary.
- **Plugin enabled and connected.** The Dynamics 365 ERP plugin must be enabled, and the
  connection must point at the approved Dynamics 365 Finance and Operations environment,
  authenticated with the same Microsoft Entra ID (Azure AD) account the user signs in with -
  never a shared or service account.
- **Legal entity and environment URL are asked once per conversation.** On the first report in a conversation, ask the user once - in a single question - for two inputs:
  the company / legal entity code, and the Dynamics 365 Finance and Operations environment URL
  (the address they sign in to, for example https://<name>.operations.dynamics.com). Remember both
  for the rest of the conversation and reuse them silently on every later prompt, stating them in
  each report's header band; if a later prompt names a different legal entity or URL, use that
  instead and confirm it back. Never guess or substitute either value. The URL is recorded and
  shown in the header band; it does not redirect the plugin, which reads the environment it is
  connected to. If a deployment default environment URL is set in reference.md, use it and ask
  only for the legal entity. A new conversation asks again; a scheduled prompt should state both
  values in its text.
  Every skill states the confirmed legal entity in the output.
- **Microsoft 365 Outlook access in Cowork (optional, for the email follow-up).** "Email this report to me" sends
  through Cowork's Microsoft 365 Outlook capability to the signed-in user's own mailbox only, after the user
  approves the send; if Outlook access is not enabled for the user in Cowork, the report says so and skips it.
- **Entity names may vary by environment.** Every skill's `reference.md` lists the standard F&O
  OData collections it expects (for example, `CustomersV3`, `VendorsV2`, `InventSum`,
  `PurchaseOrderHeadersV2`). These are illustrative examples confirmed against typical F&O
  environments; custom fields, ISV solutions, or renamed entities in your tenant may differ.
  Confirm exact names against your own environment's metadata - a skill will report a source gap
  rather than guess or substitute a similarly named entity.
- **Module access determines results.** A user who lacks a license for, or security access to, a
  given module (for example, an SCM-only user asking for the P&L and budget variance report, or a
  Finance user asking for supplier performance) will not be able to fetch results for that
  module. The affected skill reports this plainly as a source gap - it never substitutes,
  guesses, or fabricates a result to compensate.
- **Attribute-level inputs.** Several skills return their most precise output only when the user
  supplies the exact scope for the attribute they want analyzed. Users should expect to be asked
  for inputs such as: **legal entity** (always), **as-of date or fiscal period**, **bank account**,
  **customer or vendor account**, **site or warehouse**, or **resource group**, whenever the
  request implies analytics scoped to one of those exact attributes rather than the full
  portfolio. Each skill's `SKILL.md` lists the specific parameters it may ask for under "Required
  parameters."

## Package standards

- Requires the Dynamics 365 ERP plugin enabled and connected to the approved environment per the
  Prerequisites above; the user needs a Dynamics 365 ERP license and appropriate security roles
  for each module in scope.
- Every skill calls the same out-of-box Dynamics 365 ERP plugin connection and computes its own
  KPIs from the raw rows returned; no skill relies on a Power BI report, Fabric semantic model,
  or pre-built KPI measure.
- **All ten functional skills are read-only.** This package has no write path anywhere; it never
  posts, approves, releases a hold, adjusts inventory, or updates any Dynamics 365 ERP record.
  (Compare this to the Chief-of-staff-erp package, which has exactly one write-capable skill.)
- **HTML report with a chat summary by default.** Every functional skill delivers a self-contained,
  colorful HTML report plus a short chat summary, always grounded in the Dynamics 365 ERP plugin connection
  detail - legal entity, environment URL as entered and query timestamp.
- **HTML by default, one follow-up question.** When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
  no external dependencies) together with a short chat summary. Once the results are generated,
  ask exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2)
  this report emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" -
  act only on the options chosen and ask nothing further. Word: produce the .docx from the data
  already in this conversation - the same summary, header details, sections, tables and figures
  used for the HTML, with no second query to Dynamics 365 - written as structured document content
  through Cowork's Word / document creation capability: title, header line (legal entity,
  environment, as-of date, query timestamp), one heading per section, each table as a real table,
  summary and Source gaps as bold call-out paragraphs, same palette where the capability allows.
  Never pass HTML markup or the HTML file as the document content. Before offering it, check the
  document contains every section and the same row counts as the HTML; if a populated Word
  document cannot be produced, say so and keep the HTML - never deliver an empty file. Email: To
  and From are the signed-in user's own address and nobody else; subject "<report title> - <legal
  entity> - <as-of date>"; body = the summary and the top items; the HTML file (and the Word file
  if produced) attached; send through Cowork's Microsoft 365 Outlook capability only after the
  user approves the send. Schedule: set up a Cowork scheduled run of this report's demo prompt on
  its natural cadence, with the legal entity, the environment URL and "email the result to me"
  stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All
  files are drafts for the user's review.
- **Ask once per conversation for the legal entity and environment URL.** On the first report in a conversation, ask the user once - in a single question - for two inputs:
  the company / legal entity code, and the Dynamics 365 Finance and Operations environment URL
  (the address they sign in to, for example https://<name>.operations.dynamics.com). Remember both
  for the rest of the conversation and reuse them silently on every later prompt, stating them in
  each report's header band; if a later prompt names a different legal entity or URL, use that
  instead and confirm it back. Never guess or substitute either value. The URL is recorded and
  shown in the header band; it does not redirect the plugin, which reads the environment it is
  connected to. If a deployment default environment URL is set in reference.md, use it and ask
  only for the legal entity. A new conversation asks again; a scheduled prompt should state both
  values in its text.
- **Hand-off, not overlap.** Every report's description declines chief-of-staff brief requests and names the
  Chief-of-staff-erp package; the Chief-of-staff-erp briefs do the same in reverse for reports, KPIs and trends.
- **Snapshot-based trend.** Point-in-time metrics (balances, aging, on-hand, open POs, and
  similar) have no history inside the source entities. Each skill persists its own run's snapshot
  so the next run can compute period-over-period movement; a first run, or a gap in the snapshot
  history, is reported as "trend not yet available" rather than estimated. Writing a snapshot outside the session Output folder needs approval for that write only, after the path and file name are shown; no earlier approval covers the next write.
- Ground claims in Dynamics 365 ERP records or retrieved evidence; show source gaps instead of
  hiding or filling them.
- Report accounts, vendors, customers, items, and orders, not people: no ranking, rating,
  comparison, sentiment inference, wellbeing inference, or surveillance of Finance, procurement,
  or warehouse staff. `supplier-performance-report` reports vendor facts only - never a composite
  vendor "score" beyond the named metrics.

## Trigger phrases by skill

Each skill's `SKILL.md` includes a full "Prompt trigger examples" section (at least seven phrases
per skill), led by a phrase that mirrors the report's official name. A minimum reference set -
five Finance and five SCM - one per skill:

| Module | Skill | Official report name | Example trigger phrase |
| --- | --- | --- | --- |
| Finance | `cash-liquidity-pulse` | Daily cash position & liquidity (Treasury / CFO) | "Give me the daily cash position and liquidity report." |
| Finance | `ar-aging-collections-pulse` | Weekly AR ageing & collections (AR manager / Controller) | "Give me the weekly AR ageing and collections report." |
| Finance | `ap-payment-readiness-pulse` | Weekly AP ageing & payment-run readiness (AP manager) | "Give me the weekly AP ageing and payment-run readiness report." |
| Finance | `pl-budget-variance-report` | Monthly P&L / trial balance & budget vs actual (Controller / FP&A) | "Give me the monthly P&L, trial balance, and budget vs actual report." |
| Finance | `close-readiness-analytics` | Monthly period-end close readiness (Controller) | "Give me the monthly period-end close readiness report." |
| SCM | `inventory-health-pulse` | Weekly inventory health (Inventory / Supply chain manager) | "Give me the weekly inventory health report." |
| SCM | `procurement-po-health-pulse` | Weekly procurement & open-PO health (Procurement manager) | "Give me the weekly procurement and open-PO health report." |
| SCM | `supplier-performance-report` | Monthly supplier performance (Procurement / Quality) | "Give me the monthly supplier performance report." |
| SCM | `production-planning-pulse` | Weekly production & master-planning status (Production planner / Plant manager) | "Give me the weekly production and master-planning status report." |
| SCM | `warehouse-fulfillment-pulse` | Daily warehouse & fulfilment operations (Warehouse manager) | "Give me the daily warehouse and fulfilment operations report." |

## Demo prompts

Every report's `SKILL.md` opens its prompt examples with one demo prompt - the official report name, for
example "Give me the daily cash position and liquidity report." On the first report in a conversation the skill
asks once for the company / legal entity and the Dynamics 365 URL, then delivers the HTML report (visual standard
in each skill) with every record's number shown as plain text, then asks once whether a Word version, an email to
yourself or a scheduled run is wanted; later reports
in the same conversation reuse both inputs without asking. Further trigger phrases are kept for reference.

### Prompt-to-skill quick reference

| Prompt | Skill | What you get in seconds |
| --- | --- | --- |
| "Give me the daily cash position and liquidity report." | `cash-liquidity-pulse` | Bank balances, 7/14-day cash forecast, unreconciled lines |
| "Give me the weekly AR ageing and collections report." | `ar-aging-collections-pulse` | Ageing buckets, DSO, top-10 overdue customers |
| "Give me the weekly AP ageing and payment-run readiness report." | `ap-payment-readiness-pulse` | AP ageing, DPO, payment-run due list, holds |
| "Give me the monthly P&L, trial balance, and budget vs actual report." | `pl-budget-variance-report` | Revenue, COGS and margin, top-5 budget variances |
| "Give me the monthly period-end close readiness report." | `close-readiness-analytics` | Ledger status by module, blockers ranked |
| "Give me the weekly inventory health report." | `inventory-health-pulse` | On-hand value, turns, days of supply, slow movers |
| "Give me the weekly procurement and open-PO health report." | `procurement-po-health-pulse` | Open and late POs, requisition queue, purchase price variance |
| "Give me the monthly supplier performance report." | `supplier-performance-report` | OTIF, delay days, rejection and mismatch rates by vendor |
| "Give me the weekly production and master-planning status report." | `production-planning-pulse` | Late orders, shortages, action messages, capacity load |
| "Give me the daily warehouse and fulfilment operations report." | `warehouse-fulfillment-pulse` | Open work, pending loads, backorders, count variances |

Fastest for a first run or a demo: the daily cash and warehouse reports and the weekly AR report (single-module reads with many visible rows). The monthly supplier performance report sweeps several modules and takes longer - run it after the quick ones. Trend needs a stored snapshot, so a first run says "trend not yet available"; run one report twice to show movement. One conversation, one question: the first prompt asks for the legal entity and environment URL; the rest reuse them.

## Record identifiers - no hyperlinks

Row-level tables in every report show each record's own business number as plain text - account, invoice, PO,
order, item, load or transfer number (each `reference.md` lists them under "Record identifiers"). Nothing in a
report is a hyperlink; RecIds, GUIDs and other internal identifiers are never shown; computed KPI figures carry
no identifier. The header band names the legal entity and the environment URL exactly as the user entered them.

## Follow-ups: Word, email, scheduled run

When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
no external dependencies) together with a short chat summary. Once the results are generated, ask
exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this
report emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only
on the options chosen and ask nothing further. Word: produce the .docx from the data already in this
conversation - the same summary, header details, sections, tables and figures used for the HTML,
with no second query to Dynamics 365 - written as structured document content through Cowork's Word
/ document creation capability: title, header line (legal entity, environment, as-of date, query
timestamp), one heading per section, each table as a real table, summary and Source gaps as bold
call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML
file as the document content. Before offering it, check the document contains every section and the
same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the
HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and
nobody else; subject "<report title> - <legal entity> - <as-of date>"; body = the summary and the
top items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft
365 Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled
run of this report's demo prompt on its natural cadence, with the legal entity, the environment URL
and "email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.

## Recommended cadence

Unlike an on-demand Chief-of-staff brief, every skill in this package has a natural recurring
cadence stated in its own metadata and "At a glance" table:

| Cadence | Skills |
| --- | --- |
| Daily | `cash-liquidity-pulse`, `warehouse-fulfillment-pulse` |
| Weekly | `ar-aging-collections-pulse`, `ap-payment-readiness-pulse`, `inventory-health-pulse`, `procurement-po-health-pulse`, `production-planning-pulse` |
| Monthly | `pl-budget-variance-report`, `close-readiness-analytics`, `supplier-performance-report` |

All ten are also available on demand; scheduling is offered but never forced.

## Avoiding collisions with Chief-of-staff-erp

Copilot Cowork selects a skill by matching the request against each skill's description. To keep the two
packages apart:

1. Use the vocabulary split: **report / pulse / KPI / trend** (this package) versus **brief**
   (Chief-of-staff-erp). Every description in both packages carries an explicit hand-off sentence.
2. Teach the official report name as the trigger - "Give me the weekly AR ageing and collections report."
3. After installing or changing either package, test in a **new** conversation; descriptions are loaded when
   a session starts.
4. If a prompt lands on either concierge, the phrase you typed is missing from the functional skill's
   description - add it there.
