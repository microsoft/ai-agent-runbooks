# Cash and liquidity pulse reference

## KPI definitions

| Metric | Definition |
| --- | --- |
| Closing balance | Bank account balance as of the requested as-of date, per the ledger's bank main account posting |
| Net cash movement | Today's closing balance minus the prior persisted snapshot's closing balance, per bank account |
| Expected inflows (7/14-day) | Sum of positive cash-flow forecast entries within the window, plus open customer transaction amounts due within the window that are not already represented by a forecast entry (see "Forecast and open-transaction precedence") |
| Expected outflows (7/14-day) | Sum of negative cash-flow forecast entries within the window, plus open vendor transaction amounts due within the window that are not already represented by a forecast entry (see "Forecast and open-transaction precedence") |
| Unreconciled bank statement line | A bank statement line not yet matched to a ledger transaction |

## Forecast and open-transaction precedence

Dynamics 365 Finance's cash-flow forecast can already include open customer and vendor invoices as
forecast entries. Counting both the forecast entry and the underlying open transaction would double
the amount, so **the cash-flow forecast entry takes precedence**: an invoice is counted once, from
the forecast, whenever one or more forecast entries can be matched to it by source document number
(for example, invoice or voucher number) - a single invoice may appear as one forecast entry or be
split across several; sum every forecast entry that references the same source document before
comparing to the open transaction's amount. An open transaction is added on top of the forecast
total only when no forecast entry references its source document at all. This example is
illustrative of the matching rule, not a guarantee that it reconciles to a connected environment's
real forecast totals.

Example (illustrative, not a reconciliation guarantee for a connected environment's real forecast
totals): a customer invoice for 10,000 that appears both as an open customer transaction and as a
single 10,000 cash-flow forecast entry is counted once, from the forecast entry; it is not added
again from the open-transaction total. If that same 10,000 invoice instead appears as two forecast
entries referencing it (6,000 and 4,000), the two are summed to 10,000 against that source document
and the open transaction is still excluded, not added a second time. A second open invoice for
4,000 with no matching forecast entry at all is added in full. Expected inflows for that window are
14,000, not 24,000 and not 20,000.

## Data the skill reads (never asked of the user)

The user supplies only the company / legal entity (and, optionally, a narrowing scope such as a site or vendor). The skill itself reads the following through the Dynamics 365 ERP plugin:

| Area | Illustrative F&O OData entity |
| --- | --- |
| Bank accounts | Company bank accounts |
| Bank transactions / reconciliation | Bank transaction and reconciliation lines |
| Cash-flow forecast | Cash-flow forecast entries |
| Open customer transactions | Customer transactions (open, by due date) |
| Open vendor transactions | Vendor transactions (open, by due date) |
| Posted GL on bank accounts | `GeneralJournalAccountEntries`, filtered to bank main accounts |

Entity names are illustrative examples of standard F&O OData collections; confirm exact names
against the connected environment's metadata, as custom or ISV entities may differ.

## Snapshot and trend rule

Point-in-time metrics (bank balances, forecast totals, unreconciled counts) have no built-in
history in the source entities. Persist each run's snapshot (values plus as-of date and legal
entity) so the next run can compute period-over-period movement.

- Persist and compare snapshots only within the same environment: key each snapshot by the
  legal entity and the environment URL as entered. A legal entity code (for example USMF) is not
  the same data in Sandbox and Production - different settings, structure and data sets can sit
  behind the identical code - so a prior snapshot counts only when both the legal entity and the
  environment URL match the current run; otherwise treat it as no prior snapshot.
- If a prior snapshot exists for the same legal entity, show net movement and label it with the
  comparison date.
- If no prior snapshot exists, state "No prior snapshot - trend not yet available" rather than
  estimating a movement.
- Storing the snapshot outside the session Output folder is a file write. Show the destination path
  and file name and request approval for that write only. If approval is declined or not given, keep
  the snapshot in the session Output folder, and say so in the next report if no prior snapshot is
  available. Approval of a schedule or of an earlier write does not authorize the next write.

## Session inputs and record identifiers

**Deployment parameter (optional):** Environment URL: `<not set>` - if a deployment sets this to the Dynamics 365
Finance and Operations URL (for example `https://<name>.operations.dynamics.com`), the skill uses it and asks the
user only for the legal entity; otherwise the skill asks for the URL once per conversation together with the legal
entity. The URL is recorded and shown in the header band as entered; it does not redirect the Dynamics 365 ERP
plugin, which reads the environment it is connected to. Before generating, emailing, or saving output, confirm
that the plugin's connected environment and the legal entity can both be confirmed against what was entered; if
either cannot be confirmed, pause and report it as a source gap instead of continuing. A sandbox and a production
environment that happen to share the same company code are different environments - their snapshots must never
be compared or combined.

Record identifiers shown in this report (plain text, never a hyperlink, never a RecId, GUID or internal ID):

| Record type | Identifier shown (plain text) |
| --- | --- |
| Bank account | Bank account ID (as shown in Cash and bank management) |
| Posted customer invoice / open customer transaction | Invoice number and voucher |
| Posted vendor invoice / open vendor transaction | Invoice number and voucher |

Identifiers are business numbers the reader can type into Dynamics 365 search or a list page filter; the legal
entity is stated once in the header band, not repeated in every row.

## Scope resolution

1. Company / legal entity: On the first report in a conversation, ask the user once - in a single
   question - for two inputs: the company / legal entity code, and the Dynamics 365 Finance and
   Operations environment URL (the address they sign in to, for example
   https://<name>.operations.dynamics.com). Remember both for the rest of the conversation and reuse
   them silently on every later prompt, stating them in each report's header band; if a later prompt
   names a different legal entity or URL, use that instead and confirm it back. Never guess or
   substitute either value. The URL is recorded and shown in the header band; it does not redirect
   the plugin, which reads the environment it is connected to. If a deployment default environment
   URL is set in reference.md, use it and ask only for the legal entity. A new conversation asks
   again; a scheduled prompt should state both values in its text.
2. Run only for the confirmed legal entity. A legal entity outside the user's membership is reported as a
   scope limitation, never silently included or dropped.
3. If no as-of date is named, default to today and state that default in the output.
4. Never proceed on a guessed bank account scope for an ask that names one; ask instead.

## Output delivery rule

When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
no external dependencies) together with a short chat summary. Once the results are generated, ask
exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this
report emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only
on the options chosen and ask nothing further. Word: produce the .docx from the data already in this
conversation - the same summary, header details, sections, tables and figures used for the HTML,
with no second query to Dynamics 365 - written as structured document content through Cowork's Word
/ document creation capability: title, header line (legal entity, environment, as-of date, query
timestamp), one heading per section, each table as a real table, summary and Source gaps as bold
call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML
file as the document content. Before offering it, check the document contains every section and the
same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the
HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and
nobody else; subject "<report title> - <legal entity> - <as-of date>"; body = the summary and the
top items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft
365 Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled
run of this report's demo prompt on its natural cadence, with the legal entity, the environment URL
and "email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.

## Hand-off rule

This report answers "how are we doing on these KPIs and which way are they trending?". Chief-of-staff
briefs - what needs my attention today, what is waiting on my approval or decision, what is coming this
week, where is this order stuck, prep me for my call with a customer or vendor - belong to the
Chief-of-staff-erp package (`finance-morning-brief`, `finance-approvals-brief`, `customer-account-brief`,
`project-portfolio-brief`, `finance-week-ahead-brief`, `scm-morning-brief`, `procurement-decisions-brief`,
`operations-week-ahead-brief`, `order-trace-brief`, `supplier-brief`). Name the matching brief instead of
running this report.

## Email and sharing gate

Default state: not shared. The only distribution this report performs is an email to the signed-in user's own
address (To and From are the user), sent through Cowork's Microsoft 365 Outlook capability after the user approves
the send - recipient, subject, summary body and attachments are shown first. No other recipient, no Teams post, no
file share. A scheduled run emails the same way and requests approval for each send: if approval is declined or not given, the output stays in the session Output folder and nothing is sent. Approval of the schedule or of an earlier send does not authorize the next send.