# Close readiness analytics reference

## KPI and blocker definitions

| Term | Definition |
| --- | --- |
| Ledger period status | Per-module status of the fiscal period: open, on hold, or closed |
| Unposted journal | Journal batch created but not yet posted to the general ledger (posted = No) |
| Pending vendor invoice | Vendor invoice submitted but not yet posted, sitting in approval workflow |
| Unreconciled bank statement line | A bank statement line not yet matched to a ledger transaction |
| Unposted depreciation proposal | A generated depreciation proposal not yet posted to the general ledger |
| Open inventory-close item | A site, warehouse, or item group not yet recalculated or closed for the period |
| Days to close | Calendar days from period-end date to the date the period's status is set to closed |

## Data the skill reads (never asked of the user)

The user supplies only the company / legal entity (and, optionally, a narrowing scope such as a site or vendor). The skill itself reads the following through the Dynamics 365 ERP plugin:

| Area | Illustrative F&O OData entity |
| --- | --- |
| Unposted journals | `LedgerJournalHeaders` (posted = No) |
| Ledger period status | Ledger period settings |
| Bank reconciliation | Bank statement and reconciliation lines |
| Fixed-asset depreciation | Fixed-asset books and depreciation proposals |
| Inventory close | Inventory close/recalculation records |
| Pending vendor invoices | `VendorInvoiceHeaders` (pending) |

Entity names are illustrative examples of standard F&O OData collections; confirm exact names
against the connected environment's metadata, as custom or ISV entities may differ.

## Snapshot and trend rule

Blocker counts and days-to-close have no built-in period-over-period history in the source
entities. Persist each run's snapshot (blocker counts by module, days-to-close once the period
closes, fiscal period, legal entity) so the next run can compute trend.

- If a prior period's snapshot exists, show the movement and label it with the comparison period.
- If no prior snapshot exists, state "No prior snapshot - trend not yet available" rather than
  estimating a movement.
- Storing the snapshot outside the session Output folder is a file write. Show the destination path
  and file name and request approval for that write only. If approval is declined or not given, keep
  the snapshot in the session Output folder, and say so in the next report if no prior snapshot is
  available. Approval of a schedule or of an earlier write does not authorize the next write.

## Session inputs and record identifiers

**Deployment parameter (optional):** Environment URL: `<not set>` - if a deployment sets this to the Dynamics 365
Finance and Operations URL (for example `https://<name>.operations.dynamics.com`), the skill uses it and asks the
user only for the legal entity; otherwise the skill asks for the URL once per conversation together with the legal
entity. The URL is recorded and shown in the header band as entered; it does not redirect the Dynamics 365 ERP
plugin, which reads the environment it is connected to. Before generating, emailing, or saving output, confirm
that the plugin's connected environment and the legal entity can both be confirmed against what was entered; if
either cannot be confirmed, pause and report it as a source gap instead of continuing. A sandbox and a production
environment that happen to share the same company code are different environments - their snapshots must never
be compared or combined.

Record identifiers shown in this report (plain text, never a hyperlink, never a RecId, GUID or internal ID):

| Record type | Identifier shown (plain text) |
| --- | --- |
| General journal (unposted or pending) | Journal batch number |
| Pending vendor invoice | Invoice number |
| Bank account | Bank account ID (as shown in Cash and bank management) |
| Fixed asset | Fixed asset number |

Identifiers are business numbers the reader can type into Dynamics 365 search or a list page filter; the legal
entity is stated once in the header band, not repeated in every row.

## Scope resolution

1. Company / legal entity: On the first report in a conversation, ask the user once - in a single
   question - for two inputs: the company / legal entity code, and the Dynamics 365 Finance and
   Operations environment URL (the address they sign in to, for example
   https://<name>.operations.dynamics.com). Remember both for the rest of the conversation and reuse
   them silently on every later prompt, stating them in each report's header band; if a later prompt
   names a different legal entity or URL, use that instead and confirm it back. Never guess or
   substitute either value. The URL is recorded and shown in the header band; it does not redirect
   the plugin, which reads the environment it is connected to. If a deployment default environment
   URL is set in reference.md, use it and ask only for the legal entity. A new conversation asks
   again; a scheduled prompt should state both values in its text.
2. Run only for the confirmed legal entity. A legal entity outside the user's membership is reported as a
   scope limitation, never silently included or dropped.
3. If no period is named, default to the current open fiscal period and state that default in
   the output.

## Output delivery rule

When the prompt runs, the default deliverable is a self-contained HTML file (one page, inline CSS,
no external dependencies) together with a short chat summary. Once the results are generated, ask
exactly one follow-up question - "Would you like (1) an editable Word (.docx) version, (2) this
report emailed to you, and/or (3) a scheduled run emailed to you on its natural cadence?" - act only
on the options chosen and ask nothing further. Word: produce the .docx from the data already in this
conversation - the same summary, header details, sections, tables and figures used for the HTML,
with no second query to Dynamics 365 - written as structured document content through Cowork's Word
/ document creation capability: title, header line (legal entity, environment, as-of date, query
timestamp), one heading per section, each table as a real table, summary and Source gaps as bold
call-out paragraphs, same palette where the capability allows. Never pass HTML markup or the HTML
file as the document content. Before offering it, check the document contains every section and the
same row counts as the HTML; if a populated Word document cannot be produced, say so and keep the
HTML - never deliver an empty file. Email: To and From are the signed-in user's own address and
nobody else; subject "<report title> - <legal entity> - <as-of date>"; body = the summary and the
top items; the HTML file (and the Word file if produced) attached; send through Cowork's Microsoft
365 Outlook capability only after the user approves the send. Schedule: set up a Cowork scheduled
run of this report's demo prompt on its natural cadence, with the legal entity, the environment URL
and "email the result to me" stated in the scheduled prompt text; each scheduled run requests approval before its email is sent, approval of the schedule or of an earlier send does not authorize the next send, and a declined or unanswered send leaves the output in the session Output folder; the user can change or stop the schedule in Cowork at any time. All files are drafts for the user's review.

## Hand-off rule

This report answers "how are we doing on these KPIs and which way are they trending?". Chief-of-staff
briefs - what needs my attention today, what is waiting on my approval or decision, what is coming this
week, where is this order stuck, prep me for my call with a customer or vendor - belong to the
Chief-of-staff-erp package (`finance-morning-brief`, `finance-approvals-brief`, `customer-account-brief`,
`project-portfolio-brief`, `finance-week-ahead-brief`, `scm-morning-brief`, `procurement-decisions-brief`,
`operations-week-ahead-brief`, `order-trace-brief`, `supplier-brief`). Name the matching brief instead of
running this report.

## Email and sharing gate

Default state: not shared. The only distribution this report performs is an email to the signed-in user's own
address (To and From are the user), sent through Cowork's Microsoft 365 Outlook capability after the user approves
the send - recipient, subject, summary body and attachments are shown first. No other recipient, no Teams post, no
file share. A scheduled run emails the same way and requests approval for each send: if approval is declined or not given, the output stays in the session Output folder and nothing is sent. Approval of the schedule or of an earlier send does not authorize the next send.