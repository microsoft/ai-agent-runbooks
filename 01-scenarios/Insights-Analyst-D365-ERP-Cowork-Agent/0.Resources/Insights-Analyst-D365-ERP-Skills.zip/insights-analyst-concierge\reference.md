# Insights Analyst concierge reference

## Routing authority

| Signal in the user's ask | Route to |
| --- | --- |
| "cash", "liquidity", "bank balance", "cash flow forecast" | `cash-liquidity-pulse` |
| "AR", "receivables", "collections", "DSO", "customer aging", "customer ageing" | `ar-aging-collections-pulse` |
| "AP", "payables", "payment run", "DPO", "vendor aging", "vendor ageing", "discount at risk" | `ap-payment-readiness-pulse` |
| "P&L", "profit and loss", "trial balance", "budget vs actual", "variance" | `pl-budget-variance-report` |
| "period close", "close readiness", "days to close", "unposted journals" | `close-readiness-analytics` |
| "inventory", "on-hand", "turns", "slow-moving", "safety stock" | `inventory-health-pulse` |
| "purchase orders", "open PO", "procurement", "requisitions" | `procurement-po-health-pulse` |
| "supplier performance", "OTIF", "vendor scorecard", "lead time" | `supplier-performance-report` |
| "production", "master plan", "planned orders", "capacity", "BOM variance" | `production-planning-pulse` |
| "warehouse", "picking", "put-away", "shipments", "cycle count", "fulfilment" | `warehouse-fulfillment-pulse` |

Tie-break: if the ask names both a Finance and an SCM topic (for example, "cash and inventory"),
ask the user which to run first; never blend two skills' outputs into one response.

## Disambiguation question

"Do you want (a) a Finance report (cash, receivables, payables, P&L/budget, or close readiness),
or (b) a Supply Chain report (inventory, procurement, supplier performance, production, or
warehouse)?"

Ask it only when the routing authority produces no single match.

## Scheduling guidance

Each sibling skill states its own natural cadence (daily, weekly, or monthly) in its metadata and
"At a glance" table. Offer that cadence as the default schedule whenever the user asks to automate
a report; never invent a different default cadence for a skill.

## No-match handling

Say: "The Insights-Analyst-erp package does not cover that yet. Current menu: cash and
liquidity, AR aging and collections, AP payment readiness, P&L and budget variance, close
readiness, inventory health, procurement and open-PO health, supplier performance, production and
planning, and warehouse and fulfillment." Capture the goal as a candidate expansion; do not
improvise.

## Hand-off to Chief-of-staff-erp

Route to `erp-concierge` (Chief-of-staff-erp) - never to a report skill - when the request contains any of:
brief, what needs my attention, on fire, waiting on my approval, approval queue, decisions, week ahead,
coming up this week, prep me for my call, everything open with <customer or vendor>, where is <order>
stuck, trace <order>. Say plainly: "That is a chief-of-staff brief, not a report - say '<brief trigger
phrase>'."

## Legal-entity and delivery reminder

Every report in this package asks the user to enter the company / legal entity name before it runs, even
when only one is available, delivers a self-contained HTML file by default and, once the results are
generated, asks once whether a Word version, an email to the user themselves or a scheduled run is wanted.
The concierge tells the user to expect this; it does not collect the legal entity itself.
