# Insights Analyst D365 Sales Cowork Plugin (v1.0.0)

Seven Cowork custom skills that produce scheduled, definition-locked analytics from the **Sales**
plugin (Dynamics 365 Sales). Where the Chief of Staff Sales package answers "what should I do
this week", this package answers "what are the numbers, how did they move, and why" on a fixed
cadence, with identical definitions every run.

## Contents

```text
manifest.json
color.png                      192x192
outline.png                    32x32
skills/
  analytics-concierge/         SKILL.md, references/reference.md
  pipeline-trend-weekly/       SKILL.md, references/reference.md
  forecast-variance-monthly/   SKILL.md, references/reference.md
  win-loss-quarterly/          SKILL.md, references/reference.md
  key-account-health/          SKILL.md, references/reference.md
  pipeline-anomaly-watch/      SKILL.md, references/reference.md
  analytics-report-pack/       SKILL.md, references/reference.md
shared/metric-dictionary.md    (copied into every skill's references/ as metric-dictionary.md)
```

## Skills

| Skill | Cadence | Output |
| --- | --- | --- |
| `analytics-concierge` | On demand | Which analytics skill fits; metric definitions on request |
| `pipeline-trend-weekly` | Monday | Coverage, movement, conversion, velocity, week-over-week deltas |
| `forecast-variance-monthly` | 1st working day | Forecast category vs closed, variance explained by driving deals |
| `win-loss-quarterly` | Quarter start | Win/loss by segment, product, competitor, loss reasons, patterns |
| `key-account-health` | Monthly | Health score per key account from pipeline, activity, open issues |
| `pipeline-anomaly-watch` | Daily or weekly | Unusual value, date, stage, or ownership changes since last run |
| `analytics-report-pack` | After any run | Excel workbook plus PowerPoint from the latest analytics output |

All skills are read-only against Dynamics 365. No skill sends, posts, or updates records.

## Design rules

- **One metric dictionary.** Every skill computes from `references/metric-dictionary.md`. Change a
  definition there, bump the package version, and state the change in the next report's header.
- **Period-over-period without memory.** Cowork sessions do not share state. Comparisons use
  Dynamics 365 record history (stage, value, close-date, owner changes) and, where configured,
  the previous report saved in the **report archive folder** (OneDrive or SharePoint path given
  in the prompt). If neither is available, the skill reports a single-period snapshot and says so.
- **Filing.** Reports land in the session Output folder. Saving a copy to the archive folder is
  the one action a schedule owner may pre-approve in Cowork's approval dialog; it is documented
  in the pilot boundary. Sends and posts are never pre-approved.
- **Handoffs.** Built-in Sales skills (pipeline prioritizer, activity synthesis) supply record
  sets; built-in Excel and PowerPoint skills build files; if the Fabric IQ plugin is enabled and
  a certified semantic model is named in the prompt, aggregate metrics come from it and the
  skill labels the source.
- **Environment.** Cowork asks for the Dynamics 365 environment on the first sales prompt and
  remembers it; the user changes it with `list environments` or
  `Set environment to [environment name]`. Skills name the environment in the header, stop on a
  mismatch, and never change it.
- **Parameters** come from the prompt first (scheduled-prompt text), then a one-time ask, then
  the defaults in `references/reference.md`.
- **People safety.** Metrics are by segment, product, territory, account, or stage, never by
  seller, even when the prompt asks.
- **Mobile.** Custom skills run on Cowork desktop and web only.

## Prerequisites

- Cowork enabled and licensed; tenant Dataverse-in-Copilot setting scoped to the pilot group;
  Dataverse MCP server enabled on the approved Sales environment.
- Users hold Dynamics 365 Sales licences and roles that can read opportunity history (audit or
  change-tracking enabled on opportunity stage, value, close date, and owner).
- Sales plugin switched on (Customize > Plugins > Installed > Sales).
- Optional: Fabric IQ plugin enabled and a certified sales semantic model.

## Packaging

Upload the ZIP built from this folder (opens at `manifest.json`). Manifest stays `devPreview`;
switch to 1.28 or 1.29 only if the upload channel requires it. Validate with
`wiqd plugin validate --mode deep` when available. Recommended distribution: admin upload
(Microsoft 365 admin center > Manage apps > Upload custom app > ... > Add agent) targeted at the
pilot security group.
