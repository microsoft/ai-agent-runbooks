## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Archive path | None (files stay in the session Output folder) |
| Naming pattern | `<skill>_<period>_<environment>.xlsx` / `.pptx` |

## Workbook layout

Summary · one sheet per table in source order · Driving deals (record links) · Definitions
(dictionary version and full text) · Source gaps

## Deck map

| Source | Slides |
| --- | --- |
| `pipeline-trend-weekly` | Title · KPIs · Movement bridge · Ledgers · Driving deals · Gaps |
| `forecast-variance-monthly` | Title · Variance · Drivers · Trailing months · Gaps |
| `win-loss-quarterly` | Title · Summary · By dimension · Loss reasons · Competitors · Patterns · Gaps |
| `key-account-health` | Title · Scores · Band changes · Not scored · Gaps |
| `pipeline-anomaly-watch` | Title · Counts · Ledger · Gaps |

## Filing gate

Archive filing: show the path and filename; Cowork's approval dialog follows; the schedule
owner may pre-approve this one action. Email or Teams distribution: per-run approval only.
