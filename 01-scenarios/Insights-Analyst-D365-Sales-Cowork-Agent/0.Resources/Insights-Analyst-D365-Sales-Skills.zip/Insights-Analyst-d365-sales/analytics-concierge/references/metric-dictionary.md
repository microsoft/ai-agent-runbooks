# Metric dictionary (v1.0.0)

Every analytics skill in this package computes from these definitions and states the dictionary
version in its report header. Change here, bump the package version, and note the change in the
next report.

## Scope rules

| Rule | Definition |
| --- | --- |
| In-scope opportunity | Open, or closed in the period; not on hold; estimated value at or above the configured threshold (below-threshold deals are summarized as one line) |
| Period boundaries | Weekly: Monday 00:00 to Sunday 23:59. Monthly: calendar month. Quarterly: fiscal quarter as configured in Dynamics 365 |
| Currency | Report in the environment base currency unless the prompt names another; state conversions |
| Record history | Stage, value, close-date, and owner changes read from opportunity audit or change tracking |

## Pipeline metrics

| Metric | Definition |
| --- | --- |
| Open pipeline | Sum of estimated value of open in-scope opportunities with estimated close date in the horizon |
| Weighted pipeline | Sum of estimated value × stage probability |
| Coverage | Open pipeline ÷ remaining quota for the period (quota from the prompt or Dynamics 365 goals) |
| Created | Opportunities created in the period (count and value) |
| Won / Lost | Opportunities closed Won / Lost in the period, at final amount |
| Win rate | Won ÷ (Won + Lost) by count, closed in the period |
| Stage conversion | Share of opportunities that advanced from stage N to N+1 during the period |
| Velocity | Median days from creation to Won for deals won in the period |
| Slipped | Open opportunity whose estimated close date moved later during the period |
| Pulled in | Open opportunity whose estimated close date moved earlier during the period |
| Stalled | Open opportunity with no activity for 14 or more days at period end |
| Movement | Net change in open pipeline explained by created, won, lost, value changes, and date moves across the horizon boundary |

## Forecast metrics

| Metric | Definition |
| --- | --- |
| Forecast category | Dynamics 365 forecast category on the opportunity (Pipeline, Best case, Committed, Omitted, Won) |
| Commit at period start | Sum of Committed opportunities with close date in the period, as of the first day |
| Closed Won | Won in the period |
| Variance | Closed Won − Commit at period start, as value and % |
| Variance drivers | Deals that moved between commit and outcome: won not in commit, committed and lost, committed and slipped, committed and value changed |

## Win/loss metrics

| Metric | Definition |
| --- | --- |
| Loss reason | Dynamics 365 close reason / status reason on Lost opportunities |
| Competitor | Competitor records linked to the opportunity |
| Segment, product, territory | Account segment field, primary product line, account territory |

## Account health (0–100)

| Component | Weight | Scoring |
| --- | --- | --- |
| Open pipeline vs prior period | 25 | Up = 25, flat = 15, down = 5 |
| Activity recency | 25 | Activity in last 7 days = 25, 8–14 = 15, 15–30 = 5, >30 = 0 |
| Slip and stall exposure | 25 | None = 25, one deal = 15, two or more = 5 |
| Open issues (cases, if visible) | 25 | None = 25, open with no escalation = 15, escalated = 0 |

Bands: Green 70–100, Amber 40–69, Red 0–39.

## Anomaly thresholds

| Anomaly | Trigger |
| --- | --- |
| Large value change | Estimated value changed by ≥ 30% or ≥ configured threshold in one change |
| Mass slip | Three or more opportunities from one account or owner slipped on the same day (reported by account only) |
| Stage skip | Opportunity advanced two or more stages in one change |
| Close-date past | Open opportunity with estimated close date more than 7 days in the past |
| Ownership churn | Opportunity owner changed twice or more in 30 days (reported as a count, no names) |
| Probability override | Probability differs from stage default by ≥ 25 points |

## Exclusions and safety

Metrics are never computed per seller or team member. "Owner" is used only to detect ownership
churn and mass slips, and reported without names.
