# Analytics concierge reference

## Disambiguation question

"Do you want (a) weekly pipeline numbers, (b) forecast vs actual, (c) win/loss patterns,
(d) key-account health scores, (e) unexpected record changes, or (f) Excel and slides from an
existing report?"

## Cadence table

| Skill | Cadence | Template in |
| --- | --- | --- |
| `pipeline-trend-weekly` | Monday 08:00 | its reference.md |
| `forecast-variance-monthly` | First working day 08:00 | its reference.md |
| `win-loss-quarterly` | First Monday of fiscal quarter | its reference.md |
| `key-account-health` | First Monday of month | its reference.md |
| `pipeline-anomaly-watch` | Daily 07:00 or Monday | its reference.md |
| `analytics-report-pack` | Add "With report pack" to any scheduled prompt | its reference.md |

## No-match handling

Say: "The Insights Analyst D365 Sales package does not cover that yet. Current menu: weekly
trend, forecast variance, win/loss, key-account health, anomaly watch, report pack." Capture as
a candidate expansion; do not improvise a metric.
