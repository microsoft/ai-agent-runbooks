## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Month | Previous calendar month |
| Cuts | Segment; add product or territory on request |
| Include Best case | No |
| Archive path | None (history only) |

## Comparison basis

| Basis | When used |
| --- | --- |
| Forecast-category history | Audit enabled on the forecast category field |
| Archived first-of-month pipeline trend report | History unavailable, archive configured |
| Not computable | Neither; report closed won only and say so |

## Scheduled-prompt template

```
Forecast variance monthly. Environment: <name>. Month: previous. Cuts: segment, product.
Archive: <SharePoint path>. With report pack.
```

## Cadence notes

Schedule for the first working day at 08:00. Confirm the remembered environment first.
