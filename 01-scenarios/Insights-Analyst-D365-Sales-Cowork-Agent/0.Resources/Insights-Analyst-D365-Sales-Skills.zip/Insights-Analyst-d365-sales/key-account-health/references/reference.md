## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Key-account list | Required; ask if missing (no default) |
| Month | Previous calendar month |
| Case data | Use if the Service plugin is enabled and the user can see cases; else "not scored" |
| Archive path | None |

## Rescaling rule

If a component cannot be scored, drop it and rescale the remaining weights to 100; mark the
account "partial score".

## Scheduled-prompt template

```
Key account health. Environment: <name>. Accounts: <A>, <B>, <C>. Month: previous.
Archive: <SharePoint path>. With report pack.
```

## Cadence notes

Schedule for the first Monday of the month at 08:00.
