## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Look-back window | Since 07:00 the previous working day (daily) or 7 days (weekly) |
| Thresholds | Per `metric-dictionary.md` anomaly table |
| Value threshold | Ask / "not configured" |
| Archive path | None (counts vs prior run not shown) |

## Scheduled-prompt template

```
Pipeline anomaly watch. Environment: <name>. Window: since yesterday 07:00.
Threshold: <amount> <currency>. Archive: <SharePoint path>.
```

## Cadence notes

Daily at 07:00 on working days, or weekly on Monday. Daily runs are the highest-volume
schedule in the package; bound scope by threshold and horizon.
