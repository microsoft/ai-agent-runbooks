## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Reporting week | Previous Monday 00:00 to Sunday 23:59 |
| Horizon | Current and next quarter |
| Value threshold | Ask / "not configured" |
| Quota source | Dynamics 365 goals; else "coverage not computed" |
| Archive path | None (history only) |
| Fabric IQ model | None |

## Alert bands (flag in the Alert column)

| Metric | Flag when |
| --- | --- |
| Open pipeline | Changes by more than 10% week over week |
| Coverage | Falls below 3.0x or drops by more than 0.5x |
| Slipped value | Exceeds 5% of open pipeline |
| Stalled count | Rises by more than 20% |
| Win rate | Moves more than 10 points on 10+ closed deals |

## Scheduled-prompt template

```
Pipeline trend weekly. Environment: <name>. Horizon: current and next quarter.
Threshold: <amount> <currency>. Quota: Dynamics 365 goals. Archive: <SharePoint path>.
With report pack.
```

## Cadence notes

Create the schedule on a Monday at 08:00 with "Activate and run now"; confirm the remembered
environment with `list environments` first. Maximum 25 scheduled prompts per user.
