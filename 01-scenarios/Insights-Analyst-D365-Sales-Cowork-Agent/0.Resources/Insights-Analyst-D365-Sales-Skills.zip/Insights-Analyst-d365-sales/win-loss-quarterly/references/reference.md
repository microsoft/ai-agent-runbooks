## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Quarter | Previous fiscal quarter (Dynamics 365 fiscal settings) |
| Dimensions | Segment, product, territory, competitor |
| Value threshold | Ask / "not configured" |
| Archive path | None |

## Small-sample rule

Flag any dimension value with fewer than 10 closed deals; state the observation, not a pattern.

## Scheduled-prompt template

```
Win loss quarterly. Environment: <name>. Quarter: previous. Dimensions: segment, product,
competitor. Archive: <SharePoint path>. With report pack.
```

## Cadence notes

Schedule for the first Monday of the fiscal quarter at 08:00.
