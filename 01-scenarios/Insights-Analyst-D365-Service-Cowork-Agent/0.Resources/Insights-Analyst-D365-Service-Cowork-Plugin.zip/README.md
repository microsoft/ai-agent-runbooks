# Insights Analyst D365 Service Cowork Plugin (v1.0.1)

Seven Cowork custom skills that produce scheduled, definition-locked analytics from the **Service**
plugin (Dynamics 365 Customer Service). Where the Chief of Staff Service package answers "what
should I do this week", this package answers "what are the numbers, how did they move, and why"
on a fixed cadence, with identical definitions every run. Read-only against Dynamics 365.

## Contents

```text
manifest.json
color.png / outline.png
shared/metric-dictionary.md          master; identical copy in every skill's references/
skills/
  service-analytics-concierge/
  backlog-trend-weekly/
  sla-attainment-monthly/
  case-mix-quarterly/
  account-service-health/
  case-anomaly-watch/
  service-report-pack/
```
Each skill folder holds `SKILL.md`, `references/reference.md`, `references/metric-dictionary.md`.

## Skills

| Skill | Cadence | Output |
| --- | --- | --- |
| `service-analytics-concierge` | On demand | Which skill, which cadence, what a metric means |
| `backlog-trend-weekly` | Monday 08:00 | Backlog, inflow, resolved, reopened, aging, waiting, SLA, week-over-week deltas |
| `sla-attainment-monthly` | First working day | Attainment by KPI, queue, priority, channel; breach drivers |
| `case-mix-quarterly` | Quarter start | Volume, resolution, escalation, reopen, transfer, knowledge link, CSAT by dimension |
| `account-service-health` | First Monday | 0-100 score and band per key account |
| `case-anomaly-watch` | Working days 07:00 or Monday | Inflow spikes, breach clusters, reopen bursts, priority inflation, queue hops |
| `service-report-pack` | After any run | Excel workbook plus PowerPoint; optional archive filing |

## Design rules

- **One metric dictionary** (`shared/metric-dictionary.md`); every report states its version.
- **Period-over-period without memory**: record history first, archived previous report second,
  otherwise a labelled snapshot. Configure the archive folder from day one.
- **Filing**: reports land in the session Output folder. Before each archive filing, the skill
  shows the destination path and filename and requests approval for that filing only. If approval
  is declined or not given, the report stays in the session Output folder and nothing is written
  to the archive. Approval of a schedule or an earlier filing does not authorize the next filing.
  Sends and posts are per-run.
- **Handoffs**: built-in Customer Service skills (case enrichment, incident resolution) supply
  record sets; built-in Excel and PowerPoint build files; Fabric IQ supplies aggregates when a
  certified model is named in the prompt.
- **Environment**: chosen on the first service prompt and remembered; changed with
  `list environments` / `Set environment to [name]`; an administrator may configure a default.
  Skills name it, stop on mismatch, never change it.
- **Parameters**: prompt first (scheduled-prompt text), then one ask, then reference defaults.
- **People safety**: metrics by queue, category, product, channel, or account, never by agent.
- **Mobile**: desktop and web only.

## Prerequisites

- Cowork enabled; tenant Dataverse-in-Copilot setting scoped to the pilot group; Dataverse MCP
  server enabled on the approved Customer Service environment.
- Audit or change tracking on case status, priority, queue, owner, and SLA KPI instances.
- Users hold Dynamics 365 Customer Service licences and roles that can read case history.
- Service plugin switched on (Customize > Plugins > Installed > Service).

## Packaging

Upload the ZIP built from this folder (opens at `manifest.json`). Manifest stays `devPreview`;
switch to 1.28 or 1.29 only if required. Validate with `wiqd plugin validate --mode deep` when
available. Recommended distribution: admin upload (Microsoft 365 admin center > Manage apps >
Upload custom app > ... > Add agent) targeted at the pilot security group.
