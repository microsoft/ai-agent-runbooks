# Service metric dictionary (v1.0.0)

Every analytics skill in this package computes from these definitions and states the dictionary
version in its report header. Change here, bump the package version, and note the change in the
next report.

## Scope rules

| Rule | Definition |
| --- | --- |
| In-scope case | Active in the period, or resolved/cancelled in the period, in a queue in scope |
| Period boundaries | Weekly: Monday 00:00 to Sunday 23:59. Monthly: calendar month. Quarterly: fiscal quarter per Dynamics 365 |
| Business hours | SLA and resolution times use the SLA calendar configured on the environment |
| Record history | Status, priority, queue, owner, and SLA KPI changes read from case audit or change tracking |

## Backlog metrics

| Metric | Definition |
| --- | --- |
| Open backlog | Active cases at period end, by queue and priority |
| Inflow | Cases created in the period |
| Resolved | Cases resolved in the period |
| Reopened | Cases reactivated in the period |
| Net change | Inflow − resolved (+ reopened) |
| Aging | Active cases older than 10 days at period end |
| Waiting on customer | Active cases in "waiting on customer" for 48 or more hours at period end |
| Unowned | Active cases with no owner at period end |
| Median resolution | Median business hours from creation to resolution, cases resolved in the period |
| First response | Median business hours to first outbound response, cases created in the period |
| Backlog bridge | Opening backlog → + inflow → + reopened → − resolved → − cancelled → closing backlog |

## SLA metrics

| Metric | Definition |
| --- | --- |
| SLA KPI instance | One tracked KPI (first response, resolution) on one case |
| Attainment | KPI instances succeeded ÷ KPI instances due in the period |
| Breached | KPI instances past target in the period |
| At risk | Active KPI instances within 20% of target at period end |
| Breach drivers | Cases that breached, grouped by queue, priority, category, and status at breach time |

## Case mix metrics

| Metric | Definition |
| --- | --- |
| Category, product, channel | Case category/subject, product field, origin channel |
| Escalation rate | Escalated ÷ created in the period |
| Reopen rate | Reopened ÷ resolved in the period |
| Transfer rate | Cases that changed queue two or more times ÷ created |
| CSAT | Survey score where a survey record is linked; "not available" otherwise |
| Knowledge link rate | Resolved cases with a linked knowledge article ÷ resolved |

## Account service health (0–100)

| Component | Weight | Scoring |
| --- | --- | --- |
| Open cases vs prior period | 25 | Down = 25, flat = 15, up = 5 |
| SLA breaches in period | 25 | None = 25, one = 15, two or more = 0 |
| Escalations and reopens in period | 25 | None = 25, one = 15, two or more = 5 |
| Aging and waiting exposure | 25 | None = 25, one case = 15, two or more = 5 |

Bands: Green 70–100, Amber 40–69, Red 0–39.

## Anomaly thresholds

| Anomaly | Trigger |
| --- | --- |
| Inflow spike | Inflow for a category, product, or channel ≥ 2× its trailing 4-week average and ≥ 10 cases |
| Breach cluster | Three or more SLA breaches in one queue in one day |
| Reopen burst | Three or more reopens on one product or category in 7 days |
| Priority inflation | Priority raised on ≥ 20% of a queue's active cases in the window |
| Queue hop | Case changed queue three or more times |
| Silent high-priority | High-priority active case with no activity for 24 business hours |

## Exclusions and safety

Metrics are never computed per agent or team member. "Owner" is used only for the Unowned
metric and reported as a count, never as names.
