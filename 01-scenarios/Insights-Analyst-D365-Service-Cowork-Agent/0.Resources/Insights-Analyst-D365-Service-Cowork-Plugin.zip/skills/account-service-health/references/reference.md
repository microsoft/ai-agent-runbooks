# Account service health reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Key-account list | Required; ask if missing (no default) |
| Month | Previous calendar month |
| Archive path | None |

## Rescaling rule

If a component cannot be scored, drop it and rescale the remaining weights to 100; mark the
account "partial score".

## Scheduled-prompt template

```
Account service health. Environment: <name>. Accounts: <A>, <B>, <C>. Month: previous.
Archive: <SharePoint path>. With report pack.
```

## Cadence notes

First Monday of the month at 08:00.
