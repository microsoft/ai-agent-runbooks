# Backlog trend weekly reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Reporting week | Previous Monday 00:00 to Sunday 23:59 |
| Queues in scope | All queues the user can see |
| Priorities | All |
| Archive path | None (history only) |
| Fabric IQ model | None |

## Alert bands

| Metric | Flag when |
| --- | --- |
| Open backlog | Changes by more than 10% week over week |
| Aging | Rises by more than 20% |
| Waiting on customer | Exceeds 25% of open backlog |
| SLA attainment | Falls below 90% or drops more than 5 points |
| First response | Rises by more than 25% |

## Scheduled-prompt template

```
Backlog trend weekly. Environment: <name>. Queues: <Q1>, <Q2>. Archive: <SharePoint path>.
With report pack.
```

## Cadence notes

Create on a Monday at 08:00 with "Activate and run now"; confirm the remembered environment with
`list environments` first. Maximum 25 scheduled prompts per user.
