# Case anomaly watch reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Look-back window | Since 07:00 the previous working day (daily) or 7 days (weekly) |
| Thresholds | Per `metric-dictionary.md` anomaly table |
| Queues in scope | All queues the user can see |
| Archive path | None (counts vs prior run not shown) |

## Scheduled-prompt template

```
Case anomaly watch. Environment: <name>. Window: since yesterday 07:00. Queues: all.
Archive: <SharePoint path>.
```

## Cadence notes

Working days at 07:00, or Monday if daily is too noisy. Highest-volume schedule in the package;
bound scope by queue.
