# Case mix quarterly reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Quarter | Previous fiscal quarter |
| Dimensions | Category, product, channel |
| Archive path | None |

## Small-sample rule

Flag any dimension value with fewer than 20 cases; state the observation, not a pattern.

## Scheduled-prompt template

```
Case mix quarterly. Environment: <name>. Quarter: previous. Dimensions: category, product,
channel. Archive: <SharePoint path>. With report pack.
```

## Cadence notes

First Monday of the fiscal quarter at 08:00.
