# Service analytics concierge reference

## Disambiguation question

"Do you want (a) weekly backlog numbers, (b) SLA attainment and breach drivers, (c) case mix
patterns, (d) key-account service scores, (e) spikes and unusual changes, or (f) Excel and
slides from an existing report?"

## Cadence table

| Skill | Cadence |
| --- | --- |
| `backlog-trend-weekly` | Monday 08:00 |
| `sla-attainment-monthly` | First working day 08:00 |
| `case-mix-quarterly` | First Monday of fiscal quarter |
| `account-service-health` | First Monday of month |
| `case-anomaly-watch` | Working days 07:00 or Monday |
| `service-report-pack` | Add "With report pack" to any scheduled prompt |

## No-match handling

Say: "The Insights Analyst D365 Service package does not cover that yet. Current menu:
backlog trend, SLA attainment, case mix, account service health, anomaly watch, report pack."
Capture as a candidate expansion; do not improvise a metric.
