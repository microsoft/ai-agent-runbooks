# Service report pack reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Archive path | None (files stay in the session Output folder) |
| Naming pattern | `<skill>_<period>_<environment>.xlsx` / `.pptx` |

## Workbook layout

Summary · one sheet per table in source order · Driving items (record links) · Definitions
(dictionary version and full text) · Source gaps

## Deck map

| Source | Slides |
| --- | --- |
| `backlog-trend-weekly` | Title · KPIs · Backlog bridge · Ledgers · Driving items · Gaps |
| `sla-attainment-monthly` | Title · Attainment · Breach drivers · At risk · Trailing months · Gaps |
| `case-mix-quarterly` | Title · Summary · By dimension · Incident-driven · Patterns · Gaps |
| `account-service-health` | Title · Scores · Band changes · Not scored · Gaps |
| `case-anomaly-watch` | Title · Counts · Ledger · Gaps |

## Filing gate

Archive filing: show the path and filename; Cowork's approval dialog follows; the schedule owner
may pre-approve this one action. Email or Teams distribution: per-run approval only.
