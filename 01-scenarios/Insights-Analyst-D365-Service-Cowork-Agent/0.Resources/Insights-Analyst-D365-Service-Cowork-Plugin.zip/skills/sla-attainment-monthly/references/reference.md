# Sla attainment monthly reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Month | Previous calendar month |
| KPIs | First response, resolution |
| Cuts | Queue, priority; add channel on request |
| Archive path | None (history only) |

## Scheduled-prompt template

```
SLA attainment monthly. Environment: <name>. Month: previous. Cuts: queue, priority, channel.
Archive: <SharePoint path>. With report pack.
```

## Cadence notes

First working day at 08:00. Confirm the remembered environment first.
