# Insights Analyst D365 Service - Cowork custom skills (v1.0.0)

Skills-only copy of the plugin package, for author testing (Upload skill or OneDrive). The
recommended pilot path is the plugin package uploaded by an admin; see the plugin README and the
runbook. `metric-dictionary.md` at this root is the master; every skill carries an identical copy.

## Before first use

1. Turn on the Service plugin: Customize > Plugins > Installed > Service toggle.
2. Enter a service prompt; choose the Dynamics 365 environment when asked; confirm with
   `list environments`; change with `Set environment to [name]`.
3. Put parameters in the prompt (scheduled-prompt templates are in each skill's reference.md).
