# Service report pack reference

## Parameters

Take values stated in the prompt first (scheduled-prompt text is the carrier). Otherwise ask
once in an interactive run, or use the defaults below in a scheduled run, and state the values
used in the report header.

| Parameter | Default |
| --- | --- |
| Archive path | None (files stay in the session Output folder) |
| Naming pattern | `<skill>_<period>_<environment>.xlsx` / `.pptx` |

## Workbook layout

Summary · one sheet per table in source order · Driving items (record links) · Definitions
(dictionary version and full text) · Source gaps

## Deck map

| Source | Slides |
| --- | --- |
| `backlog-trend-weekly` | Title · KPIs · Backlog bridge · Ledgers · Driving items · Gaps |
| `sla-attainment-monthly` | Title · Attainment · Breach drivers · At risk · Trailing months · Gaps |
| `case-mix-quarterly` | Title · Summary · By dimension · Incident-driven · Patterns · Gaps |
| `account-service-health` | Title · Scores · Band changes · Not scored · Gaps |
| `case-anomaly-watch` | Title · Counts · Ledger · Gaps |

## Filing gate

Archive filing: Before each archive filing, show the destination path and filename and request
approval for that filing only. If approval is declined or not given, leave the report in the
session Output folder and do not write to the archive. Approval of a schedule or an earlier
filing does not authorize the next filing. Email or Teams distribution: per-run approval only.
