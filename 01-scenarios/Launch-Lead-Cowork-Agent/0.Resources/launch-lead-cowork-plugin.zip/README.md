# The Launch Lead Cowork Plugin

This package is structured for Cowork plugin upload surfaces that expect a Microsoft 365 app
manifest plus expanded agent skill folders. Behavioral verification is still required.

**Persona:** The Launch Lead (Launch Lead / Product Marketing Manager) · **Function:** Marketing
**Runbook:** `cowork-launch-lead-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  launch-lead-concierge/
    SKILL.md
    reference.md
  launch-activation-kit/
    SKILL.md
    reference.md
  competitive-response/
    SKILL.md
    reference.md
  messaging-docs/
    SKILL.md
    reference.md
  post-launch-readout/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `launch-lead-concierge` | Routes the user to the right Launch Lead skill |
| `launch-activation-kit` | Builds an audience-specific launch activation kit for customer, field, and partner audiences (announcement blog, value proposition, seller FAQ, explainer video script, LinkedIn organic and paid social copy, web page copy) from the launch folder, approved messaging guide, Launch Kickoff decisions, and recent executive guidance, then prepares a Notebooks launch workspace and a 45-minute distribution meeting |
| `competitive-response` | Researches a specific competitor move (launch, pricing change, acquisition, campaign, or claim) and produces one consistent response kit across PR, sales, and field: a cited situation brief, response positioning, PR holding statement and Q&A, seller talk track with objection handling, an updated one-page battlecard, and a partner/field brief |
| `messaging-docs` | Builds and governs messaging and positioning documents: a messaging framework with positioning statement, value pillars, cited proof points, persona variants, and boilerplate (Build mode), then monitors message usage across assets and field feedback, routes fixes for approval, and drafts updated field guidance (Govern mode) |
| `post-launch-readout` | Closes the loop after a launch or campaign by compiling results against goals by channel and audience, capturing evidence-linked lessons, prioritizing optimization actions with owners, and producing a 5-7 slide stakeholder readout deck, a KPI and action tracker, and a draft summary message |

Start with `launch-lead-concierge` if you are not sure which skill to use. Recommended starters: `launch-activation-kit` and `competitive-response`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, action boundaries and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

Scenario skills are draft-first and scoped to the user's request. The concierge only routes and
never drafts sibling outputs or schedules. Before any otherwise permitted action, show exact
content, action, destination, recipients, permission roles, and confidentiality/sensitivity warnings,
then obtain explicit execution approval for that action alone. Content approval is not execution
approval. Scenario skills retain requested, explicitly approved saves, shares, sends, posts, and
distribution scheduling within their reference action boundaries; never perform them unattended.
Messaging framework publication/replacement additionally needs exact-version sign-off and a write
preview; battlecard delivery must not silently overwrite its source. Other source documents,
campaign budgets/settings, and CRM/analytics writes are not authorized. No autonomous task
assignments; external activation publishing stays with channel owners. The concierge takes no
actions even with approval. Billing bands are indicative, not guaranteed charges or caps; validate
current tenant billing and actual use.

## Cumulative revision 3.1.0

All five skills and their references retain the launch workflows, IDs, routing triggers, metadata,
output types, and safeguards, with integrated evidence-state, supplied-only, approved-copy,
numerical-integrity, readiness, privacy, and per-action boundary instructions. Reference templates
and compact acceptance examples support targeted repeat QA; they are specifications, not test
execution results. Manifest and skill versions are 3.1.0; `verified: false` remains unchanged.

These safeguards are cross-persona improvements informed by observed Campaign Operator failures.
No actual Launch Lead test responses were available, so this revision is not a validated
Launch Lead defect-specific fix. Run the reference acceptance cases and live artifact/connector,
permission, and scheduling boundary tests in the target Cowork environment before marking verified.
Structural checks alone do not establish runtime compliance, connector access, or real file creation.
