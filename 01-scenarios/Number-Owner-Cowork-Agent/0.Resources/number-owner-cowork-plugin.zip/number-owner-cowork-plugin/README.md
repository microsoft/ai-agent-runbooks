# The Number Owner Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Number Owner (Sales Manager / Regional Sales Leader) · **Function:** Sales
**Runbook:** `cowork-number-owner-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  number-owner-concierge/
    SKILL.md
    reference.md
  at-risk-commit-deals/
    SKILL.md
    reference.md
  pipeline-vs-budget-gap/
    SKILL.md
    reference.md
  expansion-and-upsell/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `number-owner-concierge` | Optional guide for explicit questions about which skill in the Number Owner plugin to use |
| `at-risk-commit-deals` | Reviews Commit opportunities closing this week or earlier in Dynamics 365 Sales, validates them against recent customer emails, and flags deals with clear risk evidence (slipped milestones, unresolved questions, missing approvals, weak engagement, or a close date that no longer matches customer communication) |
| `pipeline-vs-budget-gap` | Explains why a team's pipeline is not lining up with budget for a period |
| `expansion-and-upsell` | Scans a book of business for expansion, upsell, and cross-sell potential and turns the signals into ranked account opportunities, each with cited evidence, recommended offer, labelled value estimate, next action, and pitch inputs |

Cowork selects skills automatically from session context; there is no mandatory concierge step.
Use `number-owner-concierge` for explicit plugin-selection questions such as "Which skill in the
Number Owner plugin should I use?" Direct task requests should reach the task skill normally.
Recommended starter workflows are team Commit review and pipeline vs. budget gap.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

Before deployment, configure concierge cross-plugin routing for the actual user audience. If only
one persona plugin is deployed, edit its concierge `reference.md` routing row to use the no-match
response instead of recommending the unavailable concierge. Direct referrals to meeting or renewal
skills also require confirmed access to those Quota Carrier skills. Generic meeting requests stay
with Cowork's native handling.

Configure the leader's approved team/territory in both shared skills before first use or scheduling.
There is no personal-account fallback. Missing scope stops an unattended run and is reported as a
configuration gap. The concierge describes cadence only; the target skill configures scheduling
after user confirmation.

For Pipeline vs. Budget Gap, approve the authoritative workbook or model, fiscal period boundaries,
reporting currency/exchange rates, financial measure, source snapshot, probability units, and
forecast definition. A valid approved model does not require a workbook. Unusable financial inputs
block the final numerical readout, and missing history blocks only unsupported historical driver
claims. Review the source and destination audiences before including budget details in shared slides
or follow-ups; approval alone does not grant access.

## Shared-skill maintenance and deployment

`at-risk-commit-deals` and `expansion-and-upsell` are shared with Quota Carrier. This release
includes version 3.0.2 of each skill. Their approved source folders are `skills/at-risk-commit-deals/`
and `skills/expansion-and-upsell/`; retain the release's unpacked source in one governed repository
and assign one maintainer before distributing further builds.

Maintain common workflow and safety changes in that single source, not by independently editing
the two ZIPs. Keep reviewed persona deployment profiles for scope, concierge help, and optional
cross-plugin referrals; the Number Owner profile requires team/territory scope, while a seller
profile must be explicitly configured for its audience. Build each persona package from the common
source plus its approved profile and release the shared changes together. Record source revision,
shared-skill versions, and profile in the admin deployment record.

Do not deploy both persona packages unchanged to overlapping users: they contain the same shared
skill names and can expose competing copies. Until a reviewed consolidated package is available,
use non-overlapping security-group audiences for the separate packages. A consolidated package
must contain exactly one registered copy of each shared skill with explicit, approved scope/profile
selection. Do not assume equal names or version numbers make duplicate copies safe, and do not
rename shared skills just to hide the conflict.

This ZIP updates Number Owner only. It does not update a previously generated Quota Carrier ZIP,
create an enterprise source repository, change deployment assignments, or provide a consolidated
dual-persona package. Align that companion release and review audience membership before any
overlapping rollout.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
