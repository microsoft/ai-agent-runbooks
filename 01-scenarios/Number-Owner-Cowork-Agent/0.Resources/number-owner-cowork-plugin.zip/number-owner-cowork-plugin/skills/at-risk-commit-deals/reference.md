# At-Risk Commit Deals reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Scope]` | Approved team/territory mapping; required before first run | Number Owner profile; never default to the leader's personal opportunities |
| `[Team]` | `[Approved CRM business units or territories]`; unset until configured | Required, unambiguous scope; deals only, never a per-seller view |
| `[Forecast Category]` | Commit | Confirm the forecast category field and values in Dynamics 365 Sales |
| `[Close Window]` | This week or earlier | Includes open Commit deals whose close date has already passed |
| `[Signal Lookback]` | Last 14 days of customer email | Lengthen for long-cycle segments |
| `[Check-in Meeting Length]` | 30 minutes | Account-team check-in invite length |
| `[D365 View]` | `[My Commit opportunities view]` | Optional saved view used to scope the pull |
| `[CRM Write-back Fields]` | Risk flag, follow-up task, next step, close date | Only fields approved by sales operations and security |
| `[Time Zone]` | PST | Used for the schedule and "this week" |
| `[Schedule]` | Fridays at 12:00 PST | Configure only after the user confirms prompt and cadence |

Resolve and approve the team/territory mapping before enabling a schedule. If missing or ambiguous,
ask in an interactive run; in a scheduled run report "team scope not configured" and stop. Never
replace missing team scope with personal scope or silently widen it to the whole organization.

## Rules and thresholds

| Risk signal | Flag when | Evidence required |
| --- | --- | --- |
| Slipped milestone | A customer or internal milestone passed without completion | Email, meeting, or CRM activity |
| Unresolved customer question | A customer question has no answer in the lookback | Customer email |
| Missing approval | Legal, procurement, security, or budget approval is not confirmed | Email or approval thread |
| Weak engagement | A successful, appropriately scoped email search covering `[Signal Lookback]` returns zero customer emails | Record scope, lookback, successful completion, and zero-result finding; failed, inaccessible, or incomplete searches do not prove weak engagement |
| Close-date mismatch | Latest customer communication implies a date after the CRM close date | Email plus CRM close date |

| Status | Meaning |
| --- | --- |
| On track | Required evidence was reviewed and no risk signal remains, or signals were resolved by recent evidence; missing coverage alone cannot establish this status |
| At risk | One or more risk signals; outcome still achievable this period |
| Likely to slip | Evidence shows the close date will not hold |
| Unverified | Evidence is insufficient to establish deal health; state the missing coverage. Retain any other evidence-supported risk and mark email coverage separately |

Priority rule for risk-flagged deals:

1. Put overdue close dates first, using `[Time Zone]` to determine today.
2. Order by earliest CRM close date; show any conflicting evidence date without silently changing it.
3. For the same close date, order by amount descending in a comparable reporting currency.
4. For remaining ties, explain the evidence-backed intervention rationale; keep a stable order
   when the evidence does not distinguish the deals.

Do not multiply by time remaining or invent a probability of successful intervention. Keep On
track and otherwise Unverified deals visible without treating missing evidence as a confirmed
risk or a healthy outcome. Only a successful scoped zero-result search supports weak engagement.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Close rate | Share of flagged Commit deals that close in period | Dynamics 365 Sales | Close rate |
| Forecast accuracy | Commit forecast at period start vs. actual closed-won | Dynamics 365 Sales forecasting | Forecast accuracy |
| At-risk pipeline recovered | Value of at-risk deals that closed after intervention | Opportunity history | At-risk pipeline recovered |
| Weekly Commit review time | Time spent each Friday reviewing Commit deals | Time study | Weekly Commit review (prep) time |

## Output templates

| Artifact | Layout |
| --- | --- |
| Review table | Priority, Account, Opportunity, Amount, Close date (CRM vs. evidence), Status, What changed, Risk evidence (cited), Next action, Owner role |
| Customer email | Greeting; the open item in the customer's words; proposed next step and date; no internal risk or forecast language |
| Account-team note | Deal, risk evidence, next action, owner role, check-in time |
| Check-in invite | Title "Action plan - <account>"; agenda: issues, evidence, plan, owners |
| CRM preview | Opportunity, Field, Before, After, Evidence |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Dynamics 365 Sales | Required | Stop; ask for an opportunity export; make no CRM-grounded claims |
| Outlook customer email | Required | Review available CRM evidence; label "not validated against email" and "engagement unverified - email unavailable" (or describe incomplete coverage). Do not flag weak engagement or infer On track from missing email alone; retain other supported risks |
| Teams, transcripts | Optional | Omit and note as a source gap |

## Never-automate list

- Sending customer follow-up emails or account-team notes
- Creating or sending check-in meeting invites
- Writing risk flags, tasks, close dates, or next steps to Dynamics 365 Sales
- Changing forecast category or stage

## Sharing gate

Default state: not sent. Before any send, invite, or write, show exact recipients, exact content,
the CRM before/after values, and a private-data warning when content draws on mail or meetings.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Medium |
| Indicative credit band | Medium 300-700 per run (Light 100-300, Heavy 700+); actual use varies |
| License-only starter | None defined |

## Example prompt

> It's the end of the week, and I need to know which of my commit deals require attention before
> next week begins. Review the approved [Team] opportunities closing this week or earlier in
> Dynamics 365 Sales; do not substitute my personal opportunities for missing team scope.
> Use recent emails from the relevant customers to validate deal progress, surface unresolved
> issues, and capture the latest customer commitments. Flag deals showing clear signs of risk, such
> as slipped milestones, unresolved customer questions, missing approvals, weak recent engagement,
> or a close date that no longer matches the latest customer communication. For each at-risk deal,
> tell me what changed, the evidence behind the risk, and the most important action to take next,
> prioritizing overdue deals first, then earliest close date, comparable amount, and supported
> intervention rationale. Distinguish an unavailable email source from a successful search finding
> no customer emails. Draft a targeted
> follow-up email for each customer, draft notes to each account team summarizing the issues, and
> prepare a check-in meeting to discuss an action plan. Stage any recommended CRM risk flags and
> follow-up tasks, but show me the analysis, customer emails, and proposed updates before anything
> is sent or written back. Save this process as a skill named [At-Risk Commit Deals] and run it
> every Friday at noon PST.
