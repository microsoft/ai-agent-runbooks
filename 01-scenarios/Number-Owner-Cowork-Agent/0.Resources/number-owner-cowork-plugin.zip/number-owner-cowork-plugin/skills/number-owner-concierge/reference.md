# Number Owner Concierge reference

Settings here tune routing for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Plugin Skills]` | The three skills below | Remove a row if the customer does not deploy that skill |
| `[Overlap Decision]` | Custom skill for each row below | Record whether built-in Deal Rescue or Pipeline Prioritizer is kept for any phrase |
| `[Starter Recommendation]` | `at-risk-commit-deals` | Suggested first skill for new leaders |
| `[Time Zone]` | PST | Used only when describing default cadences |

## Plugin directory (routing table, startup order)

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Review the team's Commit deals at risk before next week | `at-risk-commit-deals` | "Friday commit deal review for my team" | Fridays at noon PST |
| Explain why pipeline misses budget; build the monthly readout | `pipeline-vs-budget-gap` | "run my monthly gap readout" | 1st of the month, 9 a.m. PST |
| Find expansion plays across a team, segment, or region | `expansion-and-upsell` | "build cross-sell plays for my team's territory" | Monthly first Monday 9 a.m., or quarterly ahead of planning |
| Explicit help choosing among this plugin's skills | `number-owner-concierge` | "which skill in the Number Owner plugin should I use" | On demand |

## Activation and cross-plugin deployment

Use this concierge only for explicit questions about choosing among Number Owner's skills. It is
not general onboarding or a substitute for Cowork's context-based task selection. The directory
and positive routing examples below guide recommendations inside a plugin-selection conversation;
they are not standalone triggers for the concierge.

**Cross-plugin deployment note:** Cross-persona referrals require the destination plugin to be
deployed and available to the same user. If only Number Owner is deployed, edit the seller-goal
routing row below to use the **No-match response** rather than recommend `quota-carrier-concierge`.
If only Quota Carrier is deployed, make the equivalent change in
`skills/quota-carrier-concierge/reference.md` so leader goals do not recommend
`number-owner-concierge`. When availability is unconfirmed, use the no-match response.

## Routing tests

| If the user says | Route to |
| --- | --- |
| "Which of my team's commit deals are at risk?" | `at-risk-commit-deals` |
| "Draft follow-ups for slipping deals" | `at-risk-commit-deals` |
| "Why is pipeline short of budget this quarter?" | `pipeline-vs-budget-gap` |
| "What's driving our coverage gap?" | `pipeline-vs-budget-gap` |
| "Where can my team find expansion?" | `expansion-and-upsell` |
| "Which sellers are behind?" | Decline; offer `pipeline-vs-budget-gap` by industry, stage, account, or opportunity |
| Within plugin-selection help: seller meeting, RFP, proposal, or QBR workflow | `quota-carrier-concierge` only when Quota Carrier is confirmed available to this user; otherwise use the No-match response. Generic meeting requests remain with Cowork's native handling |
| Standalone general onboarding or generic sales-help request | Do not activate this concierge; leave selection to Cowork |
| Standalone request for Commit review, a budget-gap readout, or expansion analysis | Let Cowork select the task skill directly; do not add a concierge step |

## Ambiguity rules

- "Commit", "slipping", "this week", or "before Friday" routes to `at-risk-commit-deals`.
- "Budget", "gap", "coverage", "readout", or "Sales Review Presentation" routes to
  `pipeline-vs-budget-gap`.
- "Expansion", "upsell", "cross-sell", or "whitespace" routes to `expansion-and-upsell`.
- If the gap analysis names missing expansion as a driver, route to `pipeline-vs-budget-gap` first
  and mention `expansion-and-upsell` as the follow-on.
- If two fit, pick the narrower artifact first and mention the alternative.
- Any "by seller", leaderboard, or ranking request is declined, not routed.

## Starter recommendation

New leaders start with `at-risk-commit-deals` on one team's Commit deals: it is the weekly anchor
with the most bounded scope. Add `pipeline-vs-budget-gap` once the budget source is confirmed.

## Schedule guidance

Do not create a schedule from the concierge. Name the default cadence from the directory and let the
target skill configure it after the leader confirms the exact prompt and cadence.

## No-match response

```markdown
I do not have an available Number Owner skill for <goal>. This plugin covers team Commit review,
pipeline vs. budget gap, team expansion plays, and plugin-selection help.
```

## Never-automate list and sharing gate

The concierge sends, shares, writes, and schedules nothing. Any action belongs to the target skill
and its own sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Light (routing only) |
| Indicative credit band | Light 100-300 per run; actual use varies |

## Example prompt

> Which skill in the Number Owner plugin should I use for [team Commit review / pipeline vs.
> budget gap / team expansion plays]? Explain which included skill fits and give me its trigger
> phrase; do not perform the task yet.
