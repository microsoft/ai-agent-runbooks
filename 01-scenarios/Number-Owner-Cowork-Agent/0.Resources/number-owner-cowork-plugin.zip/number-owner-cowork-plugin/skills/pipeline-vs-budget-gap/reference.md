# Pipeline vs. Budget Gap reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`. No setting may enable a by-seller breakdown.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Team]` | `[Approved CRM business units or territories]`; required | Resolve before analysis; never silently use personal scope |
| `[Time Period]` | Current fiscal quarter | Confirm fiscal start inclusive/end exclusive and reporting time zone; do not assume calendar-quarter boundaries |
| `[Budget Source]` | Approved workbook or approved model; select before first run | Either is sufficient. If both are supplied, record the authoritative source and resolve conflicts with finance |
| `[Budget Workbook]` | `[SharePoint site / library / workbook]` | Budget and quota targets, forecast assumptions |
| `[Budget Model]` | None | Optional Fabric IQ / Power BI pipeline-budget model |
| `[Reporting Currency]` | `[Finance-approved currency]`; required | Normalize budget, actuals, pipeline, and forecast before arithmetic |
| `[Exchange Rate Source]` | `[Approved rates, effective dates, and conversion convention]` | Required only for mixed currencies; no inferred rate or mixed-currency sum |
| `[Financial Measure]` | `[Approved target basis, such as bookings]`; required | Budget and opportunity amounts must use the same measure and recognition basis |
| `[Data Snapshot]` | `[Approved reporting as-of date/time]`; required | Record each source timestamp; incompatible snapshots block the final numerical readout |
| `[Probability Units]` | `[Workbook and CRM units: 0-1 or 0-100]`; required | Convert percentages to fractions once; do not infer units from values |
| `[Forecast Definition]` | `[Official forecast measure and aggregation rule]` | State whether categories are mutually exclusive or cumulative; never sum overlapping categories |
| `[Sales Review Presentation]` | `[SharePoint path to existing deck]` | Receives the 3-slide section after approval |
| `[Coverage Target]` | 3x | Confirm from the approved budget source's assumptions |
| `[Forecast Categories]` | Commit / Best case / Pipeline | Confirm values in Dynamics 365 Sales |
| `[Signal Lookback]` | Recent (`[Days]`) | Mail, meetings, Teams for deal movement; set with sales operations |
| `[Stalled Threshold]` | `[Days]` with no stage change or customer activity | Forecast definition accepted by sales operations |
| `[Supporting Workbook]` | Off | Optional Excel with opportunity-level data and driver calculations |
| `[Driver Allocation Rule]` | `[Finance-approved primary-driver rule]` | Required for an additive financial bridge; without one show explanatory observations only |
| `[Historical Pipeline Source]` | `[Approved opportunity snapshots or stage/close-date history]` | Needed for measured slippage/conversion; absent history means the affected driver is unverified |
| `[Time Zone]` | PST | Used for the schedule |
| `[Schedule]` | 1st of each month, 9:00 a.m. PST | Configure only after the user confirms prompt and cadence |

## Source selection and input checks

Read budget from the approved source selected in `[Budget Source]`. A valid approved model is a
complete alternative to the workbook, not a reason to ask for a missing workbook. If neither
approved source is available, stop; ask for an approved source interactively or report the source
gap without asking questions in an unattended run. Switch to another source only after its
authority, scope, period, and basis are approved. Show conflicts between supplied sources and
request a finance decision interactively; an unattended run reports the conflict and stops.
Never pick one silently or combine duplicate targets.

Before calculating, align budget, closed-won, open pipeline, and forecast to `[Team]`, the same
fiscal period boundaries, `[Reporting Currency]`, `[Financial Measure]`, and `[Data Snapshot]`.
Record source timestamps, query filters, excluded records, and approved currency conversions.
If a required input is missing, stale beyond the accepted reporting basis, or incompatible,
report "financial inputs not comparable" and block the final numerical readout; do not substitute
zero or present a partial calculation as the complete result.

Count distinct opportunity IDs. Closed-won is actuals within the approved fiscal period. Open
pipeline includes eligible open opportunities closing in that period, excludes closed-won/lost,
and uses the same amount basis as budget. Normalize probabilities to 0-1 using the configured
units; 25% is 0.25, not 25. Validate the resulting weight is between 0 and 1. Use the approved budget
source's stage assumptions first, or explicitly labelled CRM probability if those are absent.
Missing or invalid weights are a source gap, not an invented probability.

If the official forecast is unavailable, the explicitly labelled estimate in the aggregation rule
below may be used for that comparison; do not label the estimate as an official forecast. The
budget, actuals, open-pipeline amounts, weights, and comparison basis must still be usable.

Negative budget or incompatible financial measures require finance clarification before a final
numerical readout. Zero budget is allowed but does not have a meaningful percentage denominator.

## Rules and thresholds

| Calculation | Formula |
| --- | --- |
| Remaining budget | Budget - Closed-won |
| Weighted open pipeline | Sum(amount_i x normalized probability_i), once per distinct eligible open opportunity |
| Signed projected gap | Budget - Closed-won - weighted open pipeline; positive = shortfall, zero = projected on target, negative = projected surplus |
| Coverage | Unweighted eligible open pipeline / remaining budget only when remaining budget > 0, compared with `[Coverage Target]`; otherwise N/A - target achieved/exceeded |
| Forecast variance | Approved forecast - Budget; percentage = variance / Budget x 100 only when Budget > 0, otherwise percentage N/A |
| Forecast aggregation | Use the approved forecast measure; do not sum cumulative/overlapping categories or add actuals twice. If unavailable, label Closed-won + weighted open pipeline as an estimate, not the official forecast |
| Weighting | Approved budget-source stage assumptions, otherwise explicitly labelled CRM probability; normalize the configured units once and validate 0 <= weight <= 1 |

If closed-won equals budget, state "budget achieved"; if it exceeds budget, state "budget
exceeded". Coverage is N/A in either case, including zero remaining budget; never divide by zero
or show negative coverage. Closed-won below budget with a non-positive projected gap is still a
projection, not an already achieved target.

Illustrative arithmetic checks (amounts in one reporting currency, not customer data):

| Budget | Closed-won | Open pipeline | Weight | Signed gap | Coverage | Meaning |
| --- | --- | --- | --- | --- | --- | --- |
| 100 | 40 | 100 | 0.5 | 10 | 1.67x | Projected shortfall; target not yet achieved |
| 100 | 100 | 20 | 0.5 | -10 | N/A | Budget achieved; projected surplus |
| 100 | 120 | 20 | 0.5 | -30 | N/A | Budget exceeded |
| 100 | 40 | 120 | 0.5 | 0 | 2.00x | Projected on target; target not yet achieved |
| 0 | 0 | 0 | 0.5 | 0 | N/A | Zero target achieved; forecast percentage N/A |

| Driver | Default definition |
| --- | --- |
| Weak coverage | Coverage below `[Coverage Target]` for a segment or stage |
| Stalled deals | No stage change or customer activity within `[Stalled Threshold]` |
| Slippage | Close date moved out of `[Time Period]` |
| Low conversion | Stage conversion below the approved budget-source assumption |
| Missing expansion | Expansion mix below the approved budget-source assumption |
| Insufficient new pipeline | Created pipeline below what the period requires |
| Assumption mismatch | Approved budget-source assumption (deal size, conversion, mix) no longer matches pipeline |

## Driver accounting

Driver flags are explanatory observations by default, not automatically additive amounts.
A stalled deal may also have slipped and weakened coverage. Show all supported flags, but do not
add the same opportunity amount under several headings.

Build an additive financial bridge only with `[Driver Allocation Rule]`, a documented comparison
baseline, and enough historical evidence. Assign each contribution once to a primary driver,
use signed amounts, and show the allocation method. Additive contributions + an explicitly
labelled unexplained remainder must equal the signed projected gap. Do not force an explanation
by inventing a driver or spreading the remainder across unsupported causes.

Measured slippage requires close-date history or comparable snapshots; measured conversion needs
the relevant cohort and outcome/stage history. Without those sources, say "driver unverified -
historical data unavailable" and omit its monetary attribution. Keep estimated upside from
recommended motions separate from the gap bridge and official forecast; do not assume it closes.

Allowed breakdowns: industry, stage, account, opportunity. Owner is used only to route follow-ups.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Opportunities won | Value and count of priority opportunities won in period | Dynamics 365 Sales | Opportunities won |
| Close rate | Closed-won / (closed-won + closed-lost) | Dynamics 365 Sales | Close rate |
| Pipeline coverage vs. budget | Coverage ratio at period start vs. prior month | Approved budget source + CRM | Coverage vs. budget |
| Readout prep time | Time to build the monthly readout | Time study | Monthly gap readout prep time |

## Output templates

| Artifact | Layout |
| --- | --- |
| Slide 1 | Total gap and pipeline coverage vs. budget |
| Slide 2 | Largest drivers, quantified, with industry, stage, and account breakdown |
| Slide 3 | Priority accounts and opportunities; 3-5 recommended sales motions |
| Readout notes | Scope/period/currency/snapshot, source timestamps, probability units, exchange rates, exclusions, allocation method, unexplained remainder, historical limits, and CRM-vs-evidence conflicts |
| Rep note | Account, opportunity, what the analysis shows, ask, meeting-prep request; no performance language |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Budget workbook (SharePoint) | Required only when selected as `[Budget Source]`; an approved model is an alternative | Use an alternative only after its authority and reporting basis are approved; if no approved source is available, stop without a numerical gap |
| Fabric IQ / Power BI budget model | Complete alternative when selected and approved | A missing workbook does not block a valid approved model. If the model is unavailable, do not silently switch; apply the source-selection rules above |
| Dynamics 365 Sales | Required | Stop; ask for a pipeline export |
| Outlook, Teams, transcripts | Required for deal signals | Run on CRM only; note "deal signals not checked" |
| Comparable financial inputs or required weights | Required | Block the final numerical readout; list missing/incompatible inputs, not zero defaults |
| Historical snapshots or conversion history | Required for measured historical drivers only | Continue current-state analysis if otherwise valid; mark affected drivers unverified and omit unsupported amounts |

## Never-automate list

- Updating or sharing the Sales Review Presentation
- Sending rep follow-up notes or meeting-prep requests
- Writing any change to Dynamics 365 Sales
- Producing any seller leaderboard, ranking, or performance view

## Sharing gate

Default state: not sent and presentation unchanged. Before including source-derived details in a
shared destination, check source permissions, source sensitivity labels, the presentation's
existing audience, and each note's proposed recipients. The authorized audience is limited by
the source rights and labels as well as the destination; membership of a broader presentation
audience alone does not authorize access to restricted budget details.

If any destination or recipient is outside the authorized audience, do not update or send there.
Prepare a permitted version with restricted details removed or propose a restricted destination,
then preview it for approval. Apply the same rule to speaker notes, appendices, supporting
workbooks, and rep follow-ups; sending an extract does not bypass source restrictions. If audience
or label rights cannot be verified, block the affected update/send and report the access gap.

Show exact permitted slides, recipients, note text, source/destination restrictions, and a private-
data warning before requesting explicit approval. A warning, confirmation, or approval prompt
does not itself grant disclosure rights. Do not modify source sharing or destination permissions
as part of this skill.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Heavy |
| Indicative credit band | Heavy 700+ per run (Light 100-300, Medium 300-700); actual use varies |
| License-only starter | None defined |

## Example prompt

> I need to understand the pipeline vs. budget gap for my team for [Time Period]. Pull the budget
> target and assumptions from the approved [Budget Source], using [Budget Workbook] or [Budget
> Model]. Use the same fiscal period, reporting currency, financial measure, and approved snapshot
> across all sources. Pull pipeline, forecast,
> account, opportunity, stage, and close-date data from Dynamics 365 Sales. Cross-reference recent
> emails, meetings, and Teams conversations for deal movement or blockers that may not yet be
> reflected in CRM. Show me where the gap is coming from by industry, stage, account, and
> opportunity. Show shortfall, on-target projection, or surplus clearly, and show coverage as N/A
> when budget is already achieved. Identify the biggest drivers, including weak coverage, stalled deals, slippage, low
> conversion, missing expansion, insufficient new pipeline, or budget assumptions that no longer
> match the pipeline. Do not count overlapping driver impacts twice; show any unexplained remainder
> and historical-data gaps. Draft a 3-slide executive
> summary section covering the total gap, largest drivers, priority accounts and opportunities,
> and recommended sales motions for [Sales Review Presentation]. Check source rights and each
> destination's audience before proposing any update. Draft follow-up notes and meeting-prep requests to the sales reps
> on the highest-priority accounts. Show me the readout and notes before anything goes out. Save
> this process as a skill named [Pipeline vs. Budget Gap] and schedule it to run monthly on the 1st
> at 9 a.m. PST, using the latest approved comparable reporting snapshot each time.
