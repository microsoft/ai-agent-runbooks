# The Portfolio Counsel Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Portfolio Counsel (Deal Lawyer / Legal Ops / Compliance and Litigation Counsel) · **Function:** Legal
**Runbook:** `cowork-portfolio-counsel-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  portfolio-counsel-concierge/
    SKILL.md
    reference.md
  portfolio-key-terms-extraction/
    SKILL.md
    reference.md
  obligations-and-deadlines-tracker/
    SKILL.md
    reference.md
  map-how-contracts-fit-together/
    SKILL.md
    reference.md
  regulatory-gaps/
    SKILL.md
    reference.md
  case-chronology/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `portfolio-counsel-concierge` | Routes the user to the right Portfolio Counsel skill |
| `portfolio-key-terms-extraction` | Answers the same diligence questions across every agreement in a contract portfolio in one consistent pass (deck alias "Compare Key Terms"): extracts parties, term and renewal, payment, change of control and assignment, liability caps, indemnities, termination rights, data protection, IP ownership, and governing law; links each answer to its source clause; highlights material differences in an Excel tracker; and drafts a red-flag summary only after the user confirms material issues |
| `obligations-and-deadlines-tracker` | Finds which obligations are owed by whom and when across a contract portfolio: extracts obligations, notice periods, renewal and termination windows, reporting duties, and payment or milestone deadlines from every agreement and amendment; computes due dates with visible formulas; proposes an internal owner; and maintains an Excel tracker with an upcoming-deadlines digest |
| `map-how-contracts-fit-together` | Establishes what has actually been agreed across a contract family (master agreement, schedules, statements of work, amendments, side letters, and waivers) by reading every document in order of precedence and date, tracing each change to the clause it amends, and producing a current-state view with a family map and a list of conflicting or unclear terms |
| `regulatory-gaps` | Checks the compliance of a contract portfolio against new regulatory requirements (deck title "Identify regulatory gaps"): turns the regulation into a cited requirements checklist for counsel to confirm, tests each agreement's relevant clauses against it, classifies each as Meets, Partial, Gap, or Unclear with clause/section references, and prioritizes remediation in an Excel gap register and a Word summary |
| `case-chronology` | Builds a sourced case chronology from case documents, correspondence, and filings: collects the matter's documents, emails, Teams messages, meeting records, and pleadings; extracts dated events with the people and documents involved; orders them on a timeline with every entry cited to its source; and flags conflicting accounts, undated items, gaps, and privileged-derived entries |

Start with `portfolio-counsel-concierge` if you are not sure which skill to use. Recommended starters: `portfolio-key-terms-extraction` and `obligations-and-deadlines-tracker`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
