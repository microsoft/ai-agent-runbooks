# Case Chronology reference

Customer-tunable settings for `case-chronology`. This file may tighten, never loosen, the guardrails
in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Case file locations | [Case File Locations] (document management workspace, SharePoint, review platform exports) | Per matter |
| Custodian scope | [Custodians and Date Range] | Only if permitted by the matter team and eDiscovery owner |
| Research source | [Harvey / Legora connector or research memo] | Optional; labeled as research |
| Output location | [Matter SharePoint folder] | Matter team access only |
| Matter team | [Named matter team members] | Only audience without further approval |
| Privilege banner | DRAFT - PRIVILEGED & CONFIDENTIAL - ATTORNEY WORK PRODUCT | Per firm practice |
| Display time zone | [Matter time zone] | Source time zone kept per entry |

## Issue tags

Default: [Issue 1], [Issue 2], [Issue 3] from the matter's issue list. Add "Untagged" for events
that fit no issue.

## Rules and thresholds

| Flag | Meaning |
| --- | --- |
| Conflict | Two or more sources give different accounts or dates; all shown |
| Approximate date | Source gives a month, period, or "around" date |
| Undated | No date can be established from the source |
| Gap | Period or expected event with no record in scope |
| Privileged-derived | Entry draws on privileged material; lawyer controls use |
| Research | Content from a research source, not the record |

| Rule | Default | Tunable |
| --- | --- | --- |
| Legal-hold items | Read-only; never moved, edited, or deleted | Not loosenable |
| Credibility | Never characterized | Not loosenable |
| Re-run behavior | New entries marked "Added <date>" | Yes |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Chronology prep hours | Hours to a reviewed chronology vs. baseline | Time records | Chronology prep hours |
| Fact traceability | Share of entries with a verifiable source | Lawyer sample | Chronology prep hours |
| Case readiness | Gaps found before key deadlines | Conflicts and gaps list | Chronology prep hours |

## Output templates

**Chronology columns:** Date | Time | Event | People/Entities | Issue Tags | Source (cited, linked) |
Privilege Flag | Conflict/Gap Flag | Notes.

**Conflicts and gaps list:** Event/period | Flag | Sources | Lawyer follow-up.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Case file documents and filings | Required | Cannot run |
| Document management connector | Optional | SharePoint or export copies; record copy date |
| Outlook, Teams custodians | Optional (if permitted) | Note custodian gap |
| Research source | Optional | Omit research labels; say so |

## Never-automate list

- Filing with a court or tribunal
- Sending to opposing parties or opposing counsel
- Sharing outside the matter team
- Moving, editing, or deleting items under legal hold
- Signing or accepting/rejecting tracked changes

## Sharing gate

Default state: matter team only. Before any wider share, show exact recipients, content, privilege
flags, and sensitivity label; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (indicative 700+ Copilot Credits per run) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Bound custodians and date range for first runs; check `/cost` |

## Example prompt

> Build a chronology for [Matter] from [Case File Locations], [Filings], and correspondence from
> [Custodians and Date Range]. For every event, give the date, what happened, who was involved, and
> a cited source; tag it against [Issues]; flag conflicting accounts, undated items, gaps, and
> anything derived from privileged material. Don't share or file anything. Save this as a skill
> named [Case Chronology].
