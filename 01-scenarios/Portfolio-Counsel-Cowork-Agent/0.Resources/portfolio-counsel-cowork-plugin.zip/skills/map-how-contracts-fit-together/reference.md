# Map How Contracts Fit Together reference

Customer-tunable settings for `map-how-contracts-fit-together`. This file may tighten, never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Document locations | [Document Locations] (document management workspace, SharePoint library, email folders) | Per contract family |
| Document management system | [Document Management System] | Read-only connector, if approved |
| Output location | [Matter SharePoint folder] | Draft until reviewed |
| Matter team | [Named matter team members] | Only audience without further approval |
| Default as-of date | Today | Override per run |
| Time zone | [Customer time zone] | For document dates |

## Terms of interest

Default: all terms. Focused set example: pricing; term; termination; liability; data protection;
service levels; IP; governing law. Tunable per run.

## Rules and thresholds

| Rule | Default | Tunable |
| --- | --- | --- |
| Operative documents | Executed documents only | Not loosenable |
| Order of application | Order-of-precedence clause, then date order | Customer may add house rules |
| Unsigned/draft | Listed separately; never changes current state | Not loosenable |
| Email-suggested change | Flagged as "Possible unrecorded change" | Not loosenable |

| Flag | Meaning |
| --- | --- |
| Conflict - no precedence | Documents disagree and no precedence rule resolves it |
| Broken reference | Amendment refers to a clause that no longer exists |
| Possible unrecorded change | Email or Teams suggests a change not in an executed document |
| Unresolved - lawyer review | Operative position cannot be stated without interpretation |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Contract analysis time | Hours to a current-state view vs. baseline | Time study | Contract analysis time |
| Conflicting terms found | Conflicts surfaced before negotiation or dispute | Change trail | Conflicting terms found |
| Risk visibility | Unresolved terms escalated to counsel | Output reports | Contract analysis time |

## Output templates

**Change trail columns (Excel):** Term | Original Clause | Each Amendment (doc + clause) | Current
Position | Controlling Source | Conflict/Ambiguity Flag.

**Family map:** table or diagram of Document | Date | Execution status | Amends/Supplements | Source.

**Current-state terms (Word):** term-by-term operative position, controlling document and clause,
unresolved items highlighted.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Executed documents | Required | Cannot run |
| Document management connector | Optional | SharePoint copies; record copy date |
| Outlook, Teams | Optional | Skip unrecorded-change check; say so |

## Never-automate list

- Sending to counterparties or issuing notices
- Signing or filing
- Accepting or rejecting tracked changes
- Sharing outside the matter team without approval

## Sharing gate

Default state: matter team only. Before any wider share, show exact recipients, content, and
sensitivity label; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (indicative 700+ Copilot Credits per run) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Start with one family and a focused term set; check `/cost` |

## Example prompt

> Map how the [Counterparty] contracts fit together. Collect the master agreement, every amendment,
> side letter, order form, and waiver from [Document Locations]. Show the family map and order of
> precedence, then trace [Terms of Interest] through each executed amendment and give me the
> current-state position as of [As-of Date], citing the controlling document and clause for each.
> Flag conflicts, broken cross-references, and unsigned documents rather than interpreting them.
> Save this as a skill named [Map How Contracts Fit Together].
