# Obligations and Deadlines Tracker reference

Customer-tunable settings for `obligations-and-deadlines-tracker`. This file may tighten, never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Portfolio location | [Portfolio Location] | Document management workspace or SharePoint library |
| Tracker location | [Tracker Location] (SharePoint/Excel) | Writes only after approval |
| Owner map | [Contract / counterparty / obligation type] -> [Business or legal owner] | Maintained by legal ops |
| Distribution | [Digest Recipients] | Named recipients only |
| Monthly sweep | First business day, [e.g., 07:00], [time zone] | Confirm before creating schedule |
| Weekly digest | [e.g., Monday 07:00], [time zone] | Confirm before creating schedule |
| Event refresh | New agreement or amendment filed in [Portfolio Location] | Optional |
| Business-day calendar | [Holiday calendar / jurisdiction] | Used for business-day rules |

## Obligation types

Default: notice and renewal windows; termination rights windows; reporting and audit duties;
payment and milestone dates; insurance and certification; confidentiality return/destroy; data
protection duties.

## Rules and thresholds

| Rule | Default | Tunable |
| --- | --- | --- |
| Lookahead window | 90 days (v2 example) | Yes |
| Urgent window | [Urgent window, set by legal ops] | Yes |
| Overdue | Due date before run date and status not Done | Not loosenable |
| Trigger date unknown | Date depends on an event not evidenced in sources | Not loosenable |
| Owner needed | No match in owner map | Not loosenable |
| Conflict | Two documents give different deadlines with no clear precedence | Flag always shown |
| Statutory notice check | Legal AI assistant, cited separately | Optional |

| Priority | Condition |
| --- | --- |
| Red | Overdue, or due within [Urgent window] with no owner |
| Amber | Due within the lookahead window |
| Green | Due after the lookahead window |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Missed deadlines avoided | Deadlines missed in pilot vs. baseline period | Tracker, matter records | Missed deadlines |
| Obligation tracking effort | Hours per month maintaining the tracker | Time study | Obligation tracking effort per month |
| Compliance exposure | Overdue or unowned obligations at each sweep | Tracker | Missed deadlines |

## Output templates

**Tracker columns:** Contract | Counterparty | Obligation | Obligor | Clause/Section | Trigger |
Deadline Rule | Due Date (formula) | Days Remaining (formula) | Owner | Status | Source Link | Flag.

**Digest skeleton:** Subject: Upcoming contract deadlines - next [Lookahead Window]. Body: table of
due date, contract, obligation, owner, clause; exceptions; link to tracker. Held for approval.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Agreements and amendments | Required | Cannot run |
| Document management connector | Optional | SharePoint library copy; record copy date |
| Legal AI assistant | Optional | Skip statutory check; say so |
| Existing tracker | Optional | Create new tracker draft |

## Never-automate list

- Sending notices to counterparties
- Exercising renewals, non-renewals, or terminations
- Writing to the tracker or sending the digest without approval
- Signing, filing, or accepting/rejecting tracked changes

## Sharing gate

Default state: not sent, not written. Before any send or write, show exact recipients or file,
content, and sensitivity label; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (recurring) (indicative 700+ Copilot Credits per sweep) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Run on demand before scheduling; record `/cost` for each recurring run |

## Example prompt

> Find every obligation and deadline across the agreements in [Portfolio Location]: notice and
> renewal windows, termination windows, reporting duties, payments, and [Obligation Types]. For
> each, cite the clause, say who owes it, compute the due date with the formula shown, and propose
> an owner from [Owner Map]. Flag anything due in the next [Lookahead Window], unknown triggers, and
> conflicts. Show me changes before updating [Tracker Location] and draft a digest for [Digest
> Recipients]. Save this as a skill named [Obligations and Deadlines Tracker] and run it on the
> first business day of each month.
