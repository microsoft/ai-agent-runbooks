# Portfolio Counsel Concierge reference

Routing authority for `portfolio-counsel-concierge`. This file may tighten, never loosen, the
guardrails in `SKILL.md`.

## Package directory

Skills in startup order (The Portfolio Counsel plugin).

| User goal | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Routing help across the plugin | `portfolio-counsel-concierge` | "help me choose" | On demand |
| Same diligence questions across many agreements; Excel tracker; red flags | `portfolio-key-terms-extraction` | "extract and compare key terms across [Portfolio Location]" | On demand |
| Obligations, notice and renewal windows, owners, upcoming deadlines | `obligations-and-deadlines-tracker` | "build an obligations and deadlines tracker for [Portfolio]" | Yes - monthly sweep and weekly digest |
| Current-state terms across a master, amendments, and side letters | `map-how-contracts-fit-together` | "map how these contracts fit together" | On demand |
| Portfolio tested against a new or amended regulation | `regulatory-gaps` | "check our contracts against [Regulation]" | Optional quarterly re-test |
| Sourced timeline from case documents, correspondence, and filings | `case-chronology` | "build a chronology for [Matter]" | On demand |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "Run Compare Key Terms on the data room" | `portfolio-key-terms-extraction` |
| "Which contracts have change-of-control issues?" | `portfolio-key-terms-extraction` |
| "Which renewals or notice windows are coming up?" | `obligations-and-deadlines-tracker` |
| "Run the monthly obligations sweep" | `obligations-and-deadlines-tracker` |
| "Six amendments later, what have we actually agreed?" | `map-how-contracts-fit-together` |
| "Which agreements need updating for the new rules?" | `regulatory-gaps` |
| "What happened and when in the [Dispute]?" | `case-chronology` |
| "Which skill should I use?" | `portfolio-counsel-concierge` |
| "Review this NDA using our playbook" | Out of scope - suggest `contract-counsel-concierge` |

## Ambiguity rules

- "Diligence", "data room", "compare key terms", "red flags" -> key terms extraction.
- "Obligations", "deadlines", "notice", "renewal window", "who owes what" -> obligations tracker.
- One counterparty with "amendments", "side letters", "which document controls" -> family map.
- A named regulation, "compliance", "remediation" -> regulatory gaps.
- "Matter", "dispute", "timeline", "disclosure", "what happened" -> case chronology.
- If two fit, pick the narrower artifact first and mention the alternative.
- Requests to send notices, file, or contact regulators: explain these stay with the lawyer, then
  route to the skill that prepares the draft.

## Starter recommendation

For a first-time user, recommend `portfolio-key-terms-extraction` on a bounded, closed portfolio
where a lawyer-reviewed answer set exists. Then add `obligations-and-deadlines-tracker` (on demand
before scheduling), `map-how-contracts-fit-together`, `regulatory-gaps`, and `case-chronology` in
that order.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Skills installed | All five scenario skills | Remove rows for skills not deployed |
| Sibling concierge | `contract-counsel-concierge` | Remove mention if not deployed |
| Default portfolio | [Portfolio Location] | Named only in trigger phrases |

## Schedule guidance

`obligations-and-deadlines-tracker` is the default recurring workflow: monthly sweep on the first
business day and a weekly upcoming-deadlines digest. Do not create a schedule unless the user
explicitly confirms the exact prompt and cadence. All runs produce drafts only.

## Never-automate list

- Running sibling-skill work from the concierge
- Creating or changing triggers or schedules without confirmation of exact prompt and cadence
- Sending, signing, filing, issuing notices, or accepting/rejecting tracked changes

## Sharing gate

Default state: nothing shared. The concierge produces a routing recommendation only; any sharing
happens in the routed skill under that skill's sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Light (routing only) |
| Note | Routed skill billing applies when the user runs the routed skill |

## No-match response

```markdown
I do not have a Portfolio Counsel skill for <goal> yet. This plugin covers portfolio key terms
extraction, obligations and deadlines, contract family maps, regulatory gaps, case chronologies,
and routing help.
```

## Example prompt

> Help me choose: [describe the portfolio or matter situation, e.g., "we are buying a company and
> have 40 customer contracts in the data room"].
