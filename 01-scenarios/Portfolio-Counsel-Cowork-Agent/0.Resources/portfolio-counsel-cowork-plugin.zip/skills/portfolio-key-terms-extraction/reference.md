# Portfolio Key Terms Extraction reference

Customer-tunable settings for `portfolio-key-terms-extraction`. This file may tighten, never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Portfolio location | [Portfolio Location] (document management workspace, data room export, or SharePoint library) | Record document count |
| Document management system | [Document Management System] (e.g., iManage, NetDocuments, HighQ) | Read-only connector, if approved |
| Legal requirements source | [Harvey / Legora connector or counsel memo] | Used for termination-rights check |
| Tracker location | [Matter SharePoint folder] | Draft until reviewed |
| Distribution | [Deal Team] | Red-flag summary recipients (draft only) |
| Clean-team rules | [Clean-team restrictions for the deal] | Applied before extraction |
| First-run size limit | [Max agreements per run, e.g., 10-20 for pilot] | Cost control |
| Time zone | [Customer time zone] | For coverage log |

## Key terms

Default (slide 28): Parties; Term and renewal; Payment terms; Change of control and assignment;
Liability caps; Indemnities; Termination rights; Data protection; IP ownership; Governing law.
Add or remove per deal.

## Rules and thresholds

| Materiality criterion (default) | Flag when |
| --- | --- |
| Change of control | Change of control or assignment requires counterparty consent or triggers termination |
| Liability | Liability is uncapped or the cap departs from [Standard cap rule] |
| Governing law | Governing law outside [Approved jurisdictions] |
| Termination | Termination for convenience by counterparty, or rights inconsistent with [Legal Requirements Source] |
| Data protection | No data protection terms where personal data is processed |

| Status label | Meaning |
| --- | --- |
| Not found | Term absent from the agreement and its amendments |
| Ambiguous - review | Text unclear or internally inconsistent |
| Amended | Later document changes the term; both cited |
| Unreadable | Scan without text or password-protected |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Diligence hours saved | Lawyer hours per 10 agreements vs. baseline | Time records | Diligence hours per 10 agreements |
| Review consistency | Agreement between skill answers and a lawyer-reviewed sample | Sample review | Review consistency vs. lawyer sample |
| Deal timeline reduced | Days from data-room access to red-flag summary | Deal records | Deal timeline |

## Output templates

**Tracker tabs:** Tracker (one row per agreement; per key term: answer + clause/section + source
link; Materiality Flag; Review Needed; Notes) | Differences | Coverage log.

**Red-flag summary skeleton (Word):** scope and coverage; confirmed material issues by key term;
agreements affected; recommended lawyer follow-ups; source gaps. Drafted only after confirmation.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Agreements (any approved location) | Required | Cannot run |
| Document management connector | Optional | Use SharePoint library copy; record copy date |
| Legal AI assistant | Optional | Use counsel-supplied requirements memo; say so |
| Outlook, Teams | Optional | Diligence questions supplied by user |

## Never-automate list

- Sending to counterparties, sellers, or opposing counsel
- Uploading to a data room
- Sending the red-flag summary without approval
- Signing, filing, or accepting/rejecting tracked changes

## Sharing gate

Default state: not sent. Before any send, show exact recipients (deal team only), content, and
sensitivity label; wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (indicative 700+ Copilot Credits per run) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Bound portfolio size for first runs; check `/cost` per run |

## Example prompt

> Extract and compare the key terms across all agreements in [Portfolio Location] and create an
> Excel portfolio tracker. Include: parties; term and renewal; payment terms; change of control and
> assignment; liability caps; indemnities; termination rights; data protection; IP ownership;
> governing law. Link each result to its source clause. Check termination rights against [Legal
> Requirements Source]. Highlight material differences across the portfolio and surface anything
> that requires my review. Once I confirm the material issues, draft a red-flag summary for [Deal
> Team]. Save this as a skill named [Portfolio Key Terms Extraction].
