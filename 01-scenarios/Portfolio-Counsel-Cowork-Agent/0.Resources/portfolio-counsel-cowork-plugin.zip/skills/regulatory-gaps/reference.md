# Regulatory Gaps reference

Customer-tunable settings for `regulatory-gaps`. This file may tighten, never loosen, the guardrails
in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Regulation source | [Published text location] and [Requirements memo] | Cited to article/section |
| Legal AI assistant | [Harvey / Legora connector] | Optional; via connector only |
| Portfolio location | [Portfolio Location] | Agreements in scope |
| Scope | [Contract Types / Counterparty Types] | Per regulation |
| Distribution | [Remediation Owner] | Draft addressing only |
| Gap register location | [Compliance SharePoint folder] | Draft until reviewed |
| Re-test schedule | Quarterly, [day/time, time zone] | Optional; confirm before creating |
| Amendment template | [Location of approved remediation amendment template] | Referenced, not sent |

## Rules and thresholds

| Status | Meaning |
| --- | --- |
| Meets | Clause satisfies the requirement as stated in the confirmed checklist |
| Partial | Clause addresses the requirement but omits an element |
| Gap | No clause addresses the requirement |
| Unclear | Clause wording ambiguous against the requirement |
| Interpretation required | The requirement itself is unsettled; counsel decides |

| Prioritization criterion (default) | Notes |
| --- | --- |
| Data volume or sensitivity | Where the regulation concerns data |
| Contract criticality | [Criticality tiers] |
| Renewal date | Earlier renewals offer a remediation window |
| Regulation effective date | Gaps open at the effective date ranked higher |

Ranking uses visible factors only; never individual owners.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Gap assessment time | Hours to a reviewed gap register | Time study | Gap assessment time |
| Remediation prioritization | Share of gaps with a prioritized remediation path | Gap register | Gap assessment time |
| Regulatory exposure | Gaps open at the regulation's effective date | Gap register | Gap assessment time |

## Output templates

**Gap register columns:** Agreement | Counterparty | Requirement (cited) | Clause/Section | Clause
Text | Status | Priority Factors | Proposed Remediation | Owner | Due Date.

**Gap summary (Word):** scope and coverage; confirmed checklist; results by status; themes;
proposed remediation approaches; interpretation questions; source gaps.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Regulation text or counsel memo | Required | Cannot build checklist |
| Agreements | Required | Cannot test |
| Legal AI assistant | Optional | Use counsel memo; say so |
| Document management connector | Optional | SharePoint copies; record copy date |

## Never-automate list

- Sending remediation requests or amendments to counterparties
- Contacting regulators
- Signing, filing, or accepting/rejecting tracked changes
- Testing before counsel confirms the checklist

## Sharing gate

Default state: not shared. Before any share, show exact recipients, content, and sensitivity label;
wait for explicit confirmation.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB |
| Intensity | Heavy (indicative 700+ Copilot Credits per run) |
| License-only starter | None; runs in Cowork on Copilot Credits |
| Cost control | Bound portfolio scope for first runs; check `/cost` |

## Example prompt

> Check the agreements in [Portfolio Location] against [Regulation]. First turn the regulation into
> a cited checklist of contractual requirements for me to confirm. Then test each agreement, cite the
> clause and requirement for every finding, classify Meets / Partial / Gap / Unclear, prioritize
> remediation by [Prioritization Criteria], and draft a gap summary for [Remediation Owner]. Flag
> interpretation questions rather than answering them. Save this as a skill named [Regulatory Gaps].
