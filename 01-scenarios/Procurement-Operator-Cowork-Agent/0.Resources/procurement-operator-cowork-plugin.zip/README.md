# The Procurement Operator Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Procurement Operator (Procurement Lead / Sourcing Analyst / Master Data) · **Function:** Finance & Operations
**Runbook:** `cowork-procurement-operator-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  procurement-operator-concierge/
    SKILL.md
    reference.md
  master-data-automation/
    SKILL.md
    reference.md
  expense-itemization/
    SKILL.md
    reference.md
  rfq-response/
    SKILL.md
    reference.md
  bid-to-award/
    SKILL.md
    reference.md
  regulatory-response/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `procurement-operator-concierge` | Routes the user to the right Procurement Operator skill |
| `master-data-automation` | Turns requests and specifications (emails, forms, spec sheets, tax and supplier forms, customer onboarding documents) into governed customer, vendor, or product master-data records without rekeying: extracts fields, validates them against data standards and existing records, detects duplicates, flags bank-detail and compliance checks, and stages a load-ready record for the target ERP |
| `expense-itemization` | Reads receipts and invoices (hotel folios, travel, meals, card statements), itemizes every charge, assigns expense categories and cost centers, reconciles itemized totals to the receipt and the corporate card transaction, checks each line against expense policy, and prepares a governed expense entry |
| `rfq-response` | Turns an incoming supplier or customer RFQ into a structured response package: extracts every requirement, line item, quantity, delivery term, and compliance clause into a compliance matrix, maps each to internal capability, pricing inputs, and prior responses, flags gaps and clarifications, and plans pricing and commercial approvals |
| `bid-to-award` | Runs the procurement bid-to-award workflow (saved in the deck as the "Supplier Analyzer" skill) after supplier bids are received: gathers bids, vendor information, purchasing history from Fabric IQ, and evaluation-meeting decisions; compares each supplier on cost, capability, delivery timeline, risks and exceptions, and prior pricing and performance; and recommends a supplier with the evidence and tradeoffs |
| `regulatory-response` | Coordinates a response to a regulator or agency information request (tax, financial regulator, customs, statistical, or data request): parses each numbered item and deadline, maps it to evidence and source data, recomputes figures, drafts a precise item-by-item response with citations, flags gaps and privilege concerns, and back-schedules approvals |

Start with `procurement-operator-concierge` if you are not sure which skill to use. Recommended starters: `master-data-automation` and `expense-itemization`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
