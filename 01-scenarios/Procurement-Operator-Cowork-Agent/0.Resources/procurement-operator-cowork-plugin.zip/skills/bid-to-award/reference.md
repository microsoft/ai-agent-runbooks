# Bid-to-Award reference

Customer-tunable settings for `bid-to-award` (alias: Supplier Analyzer). Settings here may
tighten, but never loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Subject | [Subject] | Category, scope, sourcing event name |
| Bid folder | [Bid Folder] | Supplier responses and pricing sheets |
| Vendor information | [Document] | Profiles, certifications, capability statements |
| Purchasing history | [Purchasing History] | Fabric IQ semantic model, Power BI report, or workbook |
| Evaluation meeting | [Evaluation Meeting] | Recap, notes, or transcript |
| Manager | [Manager] | Receives the review email |
| Approval matrix | [Approval Matrix] | Award approvers by value and category |
| Volume and budget | [Volume / Demand Assumptions], [Budget] | Optional; for total cost and savings |
| Reporting currency | [Reporting Currency] | For normalization |
| Time zone | [Time Zone] | For schedule |
| Schedule | On demand; optional daily handoff refresh until PO issue | |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Criteria and weights | [Evaluation Criteria & Weights] (example: cost 40%, capability 25%, delivery 20%, risk 15%) | Optional; editable in workbook |
| Bid compliance | Complete, on time, mandatory items answered | Else Incomplete / Late / Non-compliant |
| Prior performance | From [Purchasing History] only | "No history" when absent |
| Qualitative scores | From evaluator inputs or meeting decisions, cited | Never generated |
| FX source | [FX Source] | Cite rate and date |
| Stale history | Model not refreshed within [Refresh Window] | Show refresh time; flag |
| Conflict-of-interest check | [COI Rule] | Flag only; humans decide |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Bids evaluated | Bids compared per sourcing event and per month | Comparison workbooks | Bids evaluated |
| Recommendation time | Hours from bid close to recommendation ready for manager review | Event files | Recommendation time |
| POs or award drafts created | Award or PO drafts prepared for approval per awarded event | Handoff tracker | POs or award drafts created |

## Output templates

| Artifact | Layout |
| --- | --- |
| Supplier recommendation (Word) | Subject and scope; bids received; comparison summary; preferred supplier; evidence; risks and tradeoffs; open questions |
| Bid comparison workbook (Excel) | Comparison (pricing, capabilities, delivery, prior performance, strengths, weaknesses, exceptions); Normalized Pricing (formulas); Scoring (editable weights, optional); Sources |
| Manager email | Subject: Supplier recommendation - [Subject]; recommendation, top reasons, risks, links to both files |
| Award drafts (on request) | Approval request; PO or award inputs; supplier-setup sheet; award/regret notices; handoff tracker |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Fabric IQ / Power BI purchasing history | Required (or documented extract) | Use extract with date and scope; never infer prior pricing |
| ERP / procurement system | Optional | Use provided extract |
| Bid folder, vendor docs, meeting recap | Required | Mark bid incomplete or state source gap |

## Never-automate list

- Sending the manager email or award approvals
- Awarding a supplier; signing or issuing contracts or POs
- Creating vendor records
- Sending award or regret notifications to suppliers

## Sharing gate

Default state: not shared. Before any send, show exact recipients, content, attachments, and a
warning that bid data is confidential between suppliers.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Heavy |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> We've received supplier bids for [Subject] and need to determine which supplier to recommend.
> Use the supplier responses in [Bid Folder], vendor information from [Document], historical
> pricing and performance from [Purchasing History], and key decisions from [Evaluation Meeting].
> Compare each supplier on cost, capability, delivery timeline, risks and exceptions, and prior
> pricing and performance, where available. Create a doc with a supplier recommendation explaining
> the preferred supplier, the evidence, and the major risks or tradeoffs. Create a comparison
> spreadsheet showing each supplier's pricing, capabilities, delivery commitment, prior
> performance, strengths, weaknesses, and exceptions. Draft an email to [Manager] summarizing the
> recommendation and linking to both files. Show me everything before anything is shared. Save this
> process as a skill named [Bid-to-Award] (alias: Supplier Analyzer).
