# Expense Itemization reference

Customer-tunable settings for `expense-itemization`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Trip or period | [Trip / Period] | Dates and business purpose |
| Receipts location | [Receipts] | Folder, email confirmations, photos |
| Card statement | [Card Statement] | Used when the card feed is unavailable |
| Expense policy | [Expense Policy] | Current policy document |
| Default coding | [Cost Center / Project] | Plus any splits |
| Expense system | [Expense System] | e.g., Dynamics 365 Expense Management, SAP Concur |
| Approver | [Expense Approver] | Designated approver; never the submitter |
| Reporting currency | [Reporting Currency] | For FX conversion |
| Time zone | [Time Zone] | For schedule |
| Schedule | Weekly (Friday afternoon) or within 2 business days of a trip | Monthly before card cut-off |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Meal caps and per-diem | [Meal Caps / Per-Diem] | From [Expense Policy] |
| Lodging rate limits | [Lodging Rates] | By location if the policy specifies |
| Receipt-required threshold | [Receipt Threshold] | Lines above need an itemized receipt |
| Attendee rule | [Attendee Rule] | Business meals require attendees |
| Alcohol and non-reimbursable items | [Non-Reimbursable List] | Mark Exception with clause |
| Split-transaction flag | Multiple charges same vendor/day near a cap | Flag for review |
| Duplicate flag | Same vendor, date, and amount on two receipts or reports | Flag for review |
| FX source | [FX Source] | Cite rate and date |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Expense processing time | Minutes per report from receipts gathered to draft entry | Time study | Expense processing time |
| Reconciliation accuracy | Receipts matched to card ÷ card transactions | Workbook | Receipt-to-card match rate |
| Policy compliance | Exceptions caught pre-submission ÷ total exceptions | Expense system history | Policy compliance |
| Late or missing receipts | Card charges without receipts at cut-off | Workbook | Receipt-to-card match rate (missing) |

## Output templates

| Artifact | Layout |
| --- | --- |
| Itemization workbook (Excel) | Receipts; Line Items (category, cost center, amount, currency, FX rate, reporting amount - formulas); Reconciliation (receipt vs. items vs. card, difference formulas); Policy Exceptions |
| Exception summary | Missing receipts, unmatched card charges, policy exceptions with justification needed |
| Draft expense entry | [Expense System] field order: date, vendor, category, cost center, amount, currency, purpose, attendees |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Expense system / card feed | Optional | Reconcile to [Card Statement]; state source |
| ERP cost-center and category values | Optional | Use values in the policy or provided list |
| Fabric IQ / Power BI spend analytics | Optional | Skip spend context |
| Receipts, email, calendar | Required | Flag missing items |

## Never-automate list

- Submitting, approving, or modifying expense reports
- Creating entries in [Expense System]
- Approving one's own expenses
- Sending the report to the approver

## Sharing gate

Default state: not submitted. Before any submission or routing, show the exact entry, approver,
attachments, and a warning when personal data from receipts or calendar is included.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Light |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Prepare my expense report for [Trip / Period]. Read all [Receipts] and email confirmations,
> itemize every charge (split hotel folios into room, tax, meals, and incidentals), code to
> [Cost Center / Project], and reconcile each receipt to [Card Statement] with formulas. Check
> every line against [Expense Policy], draft business-purpose text from my calendar, and list
> missing receipts and policy exceptions. Give me the Excel workbook and a draft entry for
> [Expense System] - don't submit anything.
