# Master-Data Automation reference

Customer-tunable settings for `master-data-automation`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Record types | [Record Type] | Customer, vendor, product/item, other |
| Request source | [Request Source] | Shared mailbox, form, request list, or ticket queue |
| Target system | [Target System] | e.g., Dynamics 365 Finance & Supply Chain, SAP S/4HANA |
| Data standards | [Data Standards] | Required fields, naming, formats, picklists |
| Master extract | [Master Extract] | Used when the ERP cannot be queried live |
| Staging folder | [Staging Folder] | OneDrive / SharePoint location for staging workbooks |
| Approvers | [Approvers] | Data steward, finance, compliance (bank-detail verification) |
| Time zone | [Time Zone] | For sweep schedule |
| Schedule | Daily sweep 9:00 AM; weekly data-quality report | Or on demand |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Field status | Valid / Invalid / Missing | Per field |
| Format checks | Tax ID, IBAN/account structure, address, UoM, length | Add customer formats |
| Duplicate match keys | Name (fuzzy), tax ID, address, bank details, item attributes | Exact tax ID or bank match = strong candidate |
| Duplicate score threshold | [Duplicate Score Threshold] | Candidates at or above are listed |
| Bank-detail rule | Any new or changed bank detail | Requires independent call-back verification |
| Screening rule | [Screening Rule] | When sanctions or restricted-party screening is required |
| Required certificates | [Required Certificates] | By record type or category |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Record creation cycle time | Approval timestamp − request timestamp (median) | Request list, ERP audit trail | Record creation cycle time |
| Manual rekeying avoided | Fields populated from source ÷ total fields staged | Staging workbook | Fields rekeyed per record |
| First-pass validation rate | Records passing checks first time ÷ records submitted | Data steward log | First-pass validation rate |
| Duplicates prevented | Duplicate candidates confirmed before creation | Staging workbook | Duplicates found after creation |
| Rework reduced | Requester follow-ups per record | Mailbox sample | First-pass validation rate (clarifications) |

## Output templates

| Artifact | Layout |
| --- | --- |
| Staging workbook (Excel) | One row per record in target-system field order; validation columns (formulas); Duplicate Candidates tab; Source Trace tab |
| Exceptions list | Record, Field, Issue, Requester question |
| Approval request | Record summary, validation result, duplicate result, compliance flags, decision needed |
| Post-approval load file | Target-system template; produced only after approval for the authorized importer |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| ERP valid values and existing records | Optional (read-only) | Use [Master Extract]; state live duplicate checks were not run |
| Fabric IQ / Power BI quality dashboard | Optional | Skip quality trend |
| Request mailbox, forms, files | Required | List as source gap |

## Never-automate list

- Creating, updating, merging, or blocking records in any system
- Entering or changing bank details
- Sending approval requests or requester follow-ups
- Sanctions or restricted-party screening decisions

## Sharing gate

Default state: not sent, nothing created. Before any send, show exact recipients, content, and a
warning when personal or banking data is included.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Light |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Process the new [Record Type] requests in [Request Source]. Extract every field from the emails
> and supporting documents, validate against [Data Standards], check for duplicates against
> existing records in [Target System], and flag any bank details that need call-back
> verification. Stage load-ready records in an Excel workbook with validation formulas, list
> exceptions with draft questions to requesters, and draft the approval request for [Approvers].
> Do not create any records until I approve.
