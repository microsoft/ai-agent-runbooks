# Procurement Operator Concierge reference

Customer-tunable routing for `procurement-operator-concierge`. Settings here may tighten, but never
loosen, the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Plugin skills in scope | All five Procurement Operator skills | Remove skills not deployed |
| Sister concierge | `close-owner-concierge` | For close, budget, audit goals, if deployed |
| Expansion backlog | [Candidate Skill Backlog] | Where no-match goals are captured |
| Time zone | [Time Zone] | Used only when describing schedules |

## Routing table

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| New vendor, customer, or product record; duplicates; stage for ERP | `master-data-automation` | "set up this new vendor" | Yes - daily request sweep |
| Receipts, hotel folio, card reconciliation, expense report, policy check | `expense-itemization` | "prepare my expense report for [Trip]" | Yes - weekly or after each trip |
| RFQ we received, requirements, pricing inputs, response draft | `rfq-response` | "build a response to this RFQ" | On demand; optional intake trigger |
| Supplier bids, recommend supplier, Supplier Analyzer, award drafts | `bid-to-award` | "run Supplier Analyzer" | On demand per bid review |
| Regulator, agency, tax, or customs request; response pack | `regulatory-response` | "build the regulatory response pack" | On demand; daily status refresh |
| Routing help | `procurement-operator-concierge` | "help me choose" | On demand |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "Check this vendor form for duplicates" | `master-data-automation` |
| "Split this folio into categories" | `expense-itemization` |
| "Which RFQ requirements can't we meet?" | `rfq-response` |
| "Compare these supplier bids for [Subject]" | `bid-to-award` |
| "Map this agency letter to our evidence" | `regulatory-response` |
| "Prep the PBC list" | `close-owner-concierge` |

## Ambiguity rules

- "RFQ" or "quote request" we must answer -> rfq-response; bids we received from suppliers -> bid-to-award.
- "Vendor" with setup, record, or bank details -> master-data-automation; with selection or award -> bid-to-award.
- "Reconcile" with receipts or card -> expense-itemization; with GL, bank, or intercompany -> close-owner-concierge.
- "Request" from an auditor -> close-owner-concierge; from a regulator or agency -> regulatory-response.
- If two skills fit, pick the narrower artifact first and mention the alternative.

## Starter recommendation

Startup order (front door first): `procurement-operator-concierge`, `master-data-automation`,
`expense-itemization`, `rfq-response`, `bid-to-award`, `regulatory-response`. For "where do I
start", recommend `master-data-automation` against a controlled request folder.

## Schedule guidance

Schedule-worthy skills are marked above. Do not create a schedule; tell the user the sibling skill
can be scheduled after an on-demand run passes and they confirm the exact prompt, cadence, and time
zone.

## Never-automate list

- Running sibling-skill work (extraction, staging, comparison, drafting)
- Creating records, submitting expenses, awarding, or contacting suppliers or regulators
- Creating or changing schedules; sending, posting, or sharing anything

## Sharing gate

Default state: no action. The concierge produces only a routing recommendation; any share belongs
to the sibling skill's own sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Light (routing only) |
| Credit band | Indicative per run: Light 100-300; actual use varies |

## Example prompt

> Help me choose: I have [Number] supplier bids for [Subject] and a new vendor form for the likely
> winner. Which Procurement Operator skill should I start with, and what should I say to it?
