# Regulatory Response reference

Customer-tunable settings for `regulatory-response`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Request | [Request Letter] | Letter, notice, or portal request |
| Regulator and reference | [Regulator], [Reference Number] | |
| Deadline | [Response Deadline] | Include any extension granted |
| Period and entity | [Period], [Entity] | |
| Evidence locations | [Evidence Locations] | SharePoint folders, filings, policies, prior submissions |
| Prior correspondence | [Prior Correspondence] | Previous letters and responses |
| Legal / compliance owner | [Legal / Compliance Owner] | Leads review, privilege, approvals |
| Approvers and signatory | [Approvers], [Signatory] | Distinct from preparer and reviewer |
| Response team | [Response Team] | Only audience for drafts |
| Redaction rules | [Redaction Rules] | As legal directs |
| Time zone | [Time Zone] | For deadline math |
| Schedule | On demand; daily status refresh; reminders at 50% and 80% of time to deadline | |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Item status | Evidenced / Partial / Missing | Per numbered item |
| Item types | Factual data / document production / narrative / legal interpretation | Legal interpretation always routed to legal |
| Draft markers | "Pending input" / "Legal review required" | In response draft |
| Figure tolerance | Zero vs. source; any difference to prior filing flagged | Legal decides treatment |
| Milestones | Internal draft; legal review; executive sign-off; submission | Back-scheduled from deadline |
| Reminder points | 50% and 80% of time to deadline | Tunable |
| Draft label | DRAFT - PRIVILEGED & CONFIDENTIAL | Where legal directs |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Response preparation time | Hours from receipt to first legal review draft | Request tracker | Regulatory response preparation time |
| On-time submission rate | Submitted by deadline without unplanned extension ÷ requests | Approval tracker | Add to baseline |
| Evidence completeness at first legal review | Items Evidenced ÷ total items at first review | Matrix | Regulatory evidence completeness (pilot) |
| Regulator follow-ups or corrections | Follow-up requests or corrections after submission | Correspondence | Add to baseline |

## Output templates

| Artifact | Layout |
| --- | --- |
| Response draft (Word) | Cover letter; item-by-item responses with exhibit references; list of exhibits; open items |
| Request-to-evidence matrix (Excel) | Item #, Request Text, Type, Owner, Evidence Links, Status, Figure Recalc (formulas), Consistency Check, Legal Flag, Due Date, Days Remaining (formula) |
| Exhibit index | Proposed exhibit numbering, document, version, date |
| Approval and deadline tracker | Milestone, Owner, Date, Status |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| ERP (Dynamics 365 Finance, SAP) | Optional | Use provided extract; state date and scope |
| Fabric IQ / Power BI reported figures | Optional | Use filed figures from documents |
| Evidence locations, correspondence, mail, Teams | Required | Mark items Missing |
| Regulator published guidance (web) | Optional | Cite only what is retrieved |

## Never-automate list

- Submitting, sending, or uploading anything to a regulator or agency
- Contacting the regulator
- Privilege, legal-hold, or scope decisions
- Sharing drafts outside the response team

## Sharing gate

Default state: not sent. Before any share, show exact recipients (response team only unless legal
approves), content, exhibits, redactions applied, and the privilege marking.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Heavy |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> We received [Request Letter] from [Regulator] (ref [Reference Number]), due [Response
> Deadline]. Break it into numbered items, map each to evidence in [Evidence Locations], ERP data,
> and recent email and Teams threads, and mark each Evidenced, Partial, or Missing. Recompute every
> figure from source with formulas, check consistency with [Prior Correspondence], and draft an
> item-by-item response in Word with an exhibit index. Build an Excel matrix and a back-scheduled
> approval timeline for [Legal / Compliance Owner] and [Approvers]. Do not submit or share anything
> externally.
