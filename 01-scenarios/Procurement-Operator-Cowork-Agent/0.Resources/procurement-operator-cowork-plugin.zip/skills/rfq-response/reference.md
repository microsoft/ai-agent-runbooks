# RFQ Response reference

Customer-tunable settings for `rfq-response`. Settings here may tighten, but never loosen, the
guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| RFQ document | [RFQ Document] | Files including attachments and pricing templates |
| RFQ type | [RFQ Type] | Inbound customer RFQ or supplier-facing RFQ we issue |
| Deadline and method | [Response Deadline], [Submission Method] | Portal, email, or physical |
| Price list / cost model | [Price List / Cost Model] | Workbook or ERP price lists, cost and margin targets |
| Prior responses | [Prior Responses Library] | SharePoint folder of approved answers |
| Contract terms | [Contract Terms] | Master agreements, standard terms, approved deviations |
| Approvers | [Approvers] | Pricing, finance, legal, operations |
| Intake mailbox | [RFQ Intake Mailbox] | Optional event trigger source |
| Time zone | [Time Zone] | For deadline math |
| Schedule | On demand; daily status refresh until submission | Intake trigger only after on-demand runs pass |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Line status | Comply / Partial / Exception / Clarify | Cite internal source |
| Margin floor | [Margin Floor] | Lines below are flagged |
| Approval thresholds | [Approval Matrix] | By deal value, discount %, margin %, or term deviation |
| Clarification lead time | [Clarification Lead Days] before deadline | Due dates for requester and SME asks |
| Terms reviewed | Payment, liability, warranty, penalties | Add customer clauses |
| Reuse rule | Approved language from same customer or generic only | Never another customer's confidential terms |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| RFQ response cycle time | Elapsed time from receipt to approved submission | RFQ tracker, mailbox | RFQ response cycle time |
| Requirements coverage at first draft | Lines with sourced answer ÷ total lines | Compliance matrix | RFQ response cycle time (coverage; add to baseline) |
| Pricing review defects | Margin or threshold misses caught pre-approval | Approval tracker | Add to baseline |
| On-time submission and quote win rate | Submitted by deadline ÷ RFQs; won ÷ submitted | RFQ tracker, Fabric IQ win history | Add to baseline |

## Output templates

| Artifact | Layout |
| --- | --- |
| Requirements & pricing workbook (Excel) | Compliance Matrix; Pricing (qty × unit price, discount %, margin %, threshold flags - formulas); Terms Deviations; Summary (total value, average margin, compliance %) |
| Response draft (Word) | Cover letter; executive summary; compliance responses; pricing summary; assumptions and exceptions |
| Clarification & approval tracker | Question/approval, Owner, Due Date, Status |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| ERP item master, prices, costs, availability | Optional | Use [Price List / Cost Model]; else mark "Pricing input required" |
| Fabric IQ / Power BI win rate and margin | Optional | Omit history context |
| Prior responses, contract terms, mail, Teams | Required | List as source gap |

## Never-automate list

- Submitting the response
- Sending clarifications to the requester
- Committing or quoting pricing
- Accepting non-standard terms
- Sending approval requests

## Sharing gate

Default state: not sent. Before any send, show exact recipients, content, attachments, and a
warning when pricing or customer-confidential data is included.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Medium |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Build a response package for [RFQ Document], due [Response Deadline]. Extract every requirement
> and line item into a compliance matrix, map each to our capability using [Prior Responses
> Library] and recent SME emails, and pull pricing, cost, and lead time from [Price List / Cost
> Model] to calculate extended price and margin with formulas. Compare the RFQ terms to [Contract
> Terms], list gaps and clarification questions, and draft the response in Word. Show me the
> package and the approval routing for [Approvers] - don't send anything yet.
