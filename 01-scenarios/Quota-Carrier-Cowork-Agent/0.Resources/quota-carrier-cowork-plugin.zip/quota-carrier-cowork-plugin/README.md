# The Quota Carrier Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Quota Carrier (Account Executive / Seller / Account Team) · **Function:** Sales
**Runbook:** `cowork-quota-carrier-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  quota-carrier-concierge/
    SKILL.md
    reference.md
  meeting-prep-and-follow-up/
    SKILL.md
    reference.md
  rfp-response/
    SKILL.md
    reference.md
  proposal-pursuit/
    SKILL.md
    reference.md
  renewal-and-qbr-prep/
    SKILL.md
    reference.md
  expansion-and-upsell/
    SKILL.md
    reference.md
  at-risk-commit-deals/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `quota-carrier-concierge` | Optional guide for explicit questions about which skill in the Quota Carrier plugin to use |
| `meeting-prep-and-follow-up` | Builds CRM-grounded account-team preparation and post-meeting follow-through; not generic meeting prep or recap |
| `rfp-response` | Turns a customer RFP, RFI, or security/vendor questionnaire into a tailored, approval-ready response package and compliance matrix |
| `proposal-pursuit` | Orchestrates a proposal pursuit end to end for one opportunity: gathers requirements and account context from Dynamics 365 Sales and Microsoft 365, assembles pricing inputs, proof points, and the value story, drafts legal, security, and pricing review requests, tracks approvals, drafts a customer-ready proposal on the branded template, and drafts the cover email and follow-up actions |
| `renewal-and-qbr-prep` | Builds the recurring renewal and quarterly business review (QBR) package for one customer account from usage, support, pipeline, relationship, and prior QBR materials |
| `expansion-and-upsell` | Scans a book of business for expansion, upsell, and cross-sell potential and turns the signals into ranked account opportunities, each with cited evidence, recommended offer, labelled value estimate, next action, and pitch inputs |
| `at-risk-commit-deals` | Reviews Commit opportunities closing this week or earlier in Dynamics 365 Sales, validates them against recent customer emails, and flags deals with clear risk evidence (slipped milestones, unresolved questions, missing approvals, weak engagement, or a close date that no longer matches customer communication) |

Cowork selects skills automatically from session context; there is no mandatory concierge step.
Use `quota-carrier-concierge` only for explicit plugin-selection questions such as "Which skill in
the Quota Carrier plugin should I use?" Direct task requests should reach the relevant skill
through Cowork's normal selection. Recommended starter workflows are CRM-grounded account-team
prep/follow-through and RFP response.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

Before deployment, configure concierge cross-plugin routing for the actual user audience. If only
one persona plugin is deployed, edit its concierge `reference.md` routing row to use the no-match
response rather than recommend the unavailable concierge. Quota Carrier does not include
`pipeline-vs-budget-gap`; referrals to it require confirmed access to that Number Owner skill.

Keep generic meeting requests with Cowork's native handling, including Meetings for prep.
Configure the custom meeting skill only for CRM/account/opportunity-grounded preparation,
CRM reconciliation, or the account-team follow-through package, while supporting explicit
custom-skill invocation. Record any retained Dynamics 365 Sales Meeting Prep or Post-Meeting
Follow-Up phrases in both meeting and concierge references. Event-triggered prep requires an
approved CRM account scope; an external attendee alone is insufficient.

The concierge never creates or changes schedules. It may describe a cadence; the target skill
configures scheduling only after user confirmation.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
