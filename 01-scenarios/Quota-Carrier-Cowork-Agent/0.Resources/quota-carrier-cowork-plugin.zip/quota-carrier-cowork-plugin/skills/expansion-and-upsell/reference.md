# Expansion and Upsell reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Scope]` | "my accounts" | Seller default; a leader sets `[Segment / Region / Team]` |
| `[Segment / Region / Team]` | `[Territory or business unit]` | Resolve through CRM ownership or territory |
| `[Products / Offers in Focus]` | None (all offers) | Optional new SKU or attach motion |
| `[Lookback Period]` | Last 90 days | Window for usage trend and communication signals |
| `[Usage Dashboard]` | `[Power BI report or Fabric IQ model]` | Consumption, utilization, and adoption by account |
| `[Top N]` | 10 | Accounts detailed with pitch-input cards |
| `[Exclusions]` | Accounts in renewal negotiation, escalation, or with an active expansion opportunity | Optional, confirm with sales operations |
| `[Expansion Report Location]` | `[OneDrive or SharePoint folder]` | Where the Excel report is saved after approval |
| `[CRM Write-back Fields]` | New expansion opportunity, task, next step | Only fields approved by sales operations and security |
| `[Time Zone]` | `[Customer time zone]` | Used for the schedule |
| `[Schedule]` | Monthly, first Monday 9:00 a.m.; leaders may run quarterly | Configure only after the user confirms prompt and cadence |

## Rules and thresholds

| Signal | Default threshold | Notes |
| --- | --- | --- |
| Seat / license utilization | Above 85% of seats | Tunable per product |
| Consumption growth | Sustained growth across `[Lookback Period]` | Set a percentage per product if the customer has one |
| Adjacent-feature adoption | Adoption of features tied to an un-owned offer | Map features to offers per portfolio |
| Whitespace | Products owned by segment peers but not by this account | Peer group = same segment and size band |
| Communication signal | New initiative, new team/site, budget cycle, executive ask, pain point, competitor tool | Must be cited |

| Scoring dimension | Use |
| --- | --- |
| Signal strength | Number and quality of cited signals |
| Estimated value | Range with stated basis (seats, price list, peer average) |
| Timing | Budget cycle, contract milestones, initiative dates |
| Relationship readiness | Recent engagement and sponsor access |
| Dampeners | Open escalations, renewal risk; lower rank and flag |

Confidence labels: High (CRM + usage + communication agree), Medium (two sources), Low (one source).

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Upsell/cross-sell rate | Share of scanned accounts with an approved expansion opportunity won | Dynamics 365 Sales | Renewal rate and expansion pipeline |
| Expansion pipeline | Value of expansion opportunities created after approval | Dynamics 365 Sales | Renewal rate and expansion pipeline |
| Revenue per account | Revenue per account in the pilot book | Dynamics 365 Sales / finance | Not in baseline worksheet; add if tracked |

## Output templates

| Artifact | Layout |
| --- | --- |
| Expansion report (Excel + summary) | Account, Owner, Signals with evidence, Offer, Est. value range, Timing, Confidence, Next action, Contacts |
| Pitch-input card | Thesis, customer problem statement, proof points, discovery questions, draft outreach email |
| Leader roll-up | Potential by segment, territory, product; top plays; coverage gaps (no seller columns) |
| CRM preview | Account, Action, Detail, Evidence |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Dynamics 365 Sales | Required | Stop; ask for an account and install-base export |
| Fabric IQ / Power BI usage | Optional | Rank on CRM and communication signals; state that usage is missing |
| Outlook, Teams, transcripts | Required for communication signals | Rank on CRM and usage; note the gap |

## Never-automate list

- Sending outreach emails or posting to customers
- Creating expansion opportunities, tasks, or field updates in Dynamics 365 Sales
- Saving or sharing the report beyond the user's own workspace

## Sharing gate

Default state: not sent. Before any send, share, or write, show exact recipients, exact content,
the CRM preview, and a private-data warning when content draws on mail, chat, or meetings.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Heavy |
| Indicative credit band | Heavy 700+ per run (Light 100-300, Medium 300-700); actual use varies |
| License-only starter | None defined |

## Example prompt

> Find the expansion and upsell potential across [my accounts / Segment / Region / Team]. Use
> account, install-base, and opportunity data from Dynamics 365 Sales, usage trends from [Usage
> Dashboard], and growth signals from the last [90 days] of emails, Teams, and meeting transcripts.
> Rank the top [10] accounts with the evidence, recommended offer, estimated value, and the single
> best next action, and give me pitch inputs and a draft outreach email for each. Stage any new
> opportunities or tasks in CRM, but show me everything before anything is sent or written.
