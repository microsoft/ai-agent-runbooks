# Meeting Prep and Follow-Up reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Customer]` | `[Customer name]` | Resolve to the Dynamics 365 Sales account |
| `[Customer Meeting]` | Most recent meeting with `[Customer]` | Date, attendees, transcript |
| `[Account Team]` | Account team listed on the `[Customer]` account in Dynamics 365 Sales | Ask if not populated |
| `[Account-Team Meeting Time]` | End of this week, 30 minutes | Respect attendee working hours |
| `[Proposal]` | Latest proposal file in `[Account Folder]` | Optional |
| `[Account Folder]` | `[OneDrive or SharePoint folder]` | Account files and proposals |
| `[Related Opportunity]` | Confirm if several are open | Optional |
| `[Activity Lookback]` | Since the previous customer meeting | Window for "what changed" |
| `[Brief Format]` | Word or Loop page | One page |
| `[CRM Write-back Fields]` | Activity record, next step, close date, stage | Only fields approved by sales operations and security |
| `[Prep Trigger]` | Off; option: 24 hours before or morning of an approved in-scope customer meeting | CRM-grounded prep only; configure account scope before enabling |
| `[Prep Account Scope]` | `[Approved CRM accounts or opportunities]`; unset means no event-triggered prep | Must resolve to the meeting's CRM account; an external attendee alone is insufficient |
| `[Overlap Decision]` | Native handling for generic meeting requests; custom workflow for qualified CRM/account-team requests | Record any Dynamics 365 Sales Meeting Prep or Post-Meeting Follow-Up phrase retained for a built-in; align the concierge reference |
| `[Time Zone]` | `[Seller time zone]` | Used for invites and triggers |

## Activation boundary and overlap

Activate this custom workflow for explicit account/opportunity-grounded preparation, CRM
reconciliation, or the account-team follow-through package, or explicit invocation of
`meeting-prep-and-follow-up`. A customer name, meeting mention, or generic follow-up request alone
is insufficient. The examples below describe desired task scope, not a keyword-only match rule.

| Request | Expected handling |
| --- | --- |
| "Prepare a Dynamics 365 Sales account brief for [Customer] before my meeting, including open opportunities and recent account activity" | Custom prep mode, subject to the recorded overlap decision |
| "Build a CRM-grounded account-team decision brief for [Customer], reconciling opportunities with recent customer communications" | Custom account-team workflow |
| "For [Customer]'s Dynamics 365 Sales account, draft the post-meeting follow-up package and account-team update using the transcript and CRM context" | Custom follow-up workflow, subject to the recorded overlap decision |
| Generic meeting prep, meeting recap, or attendee follow-up without CRM/account-team scope | Cowork's native handling, including Meetings for prep; no automatic custom-workflow selection |
| Explicitly invoke `meeting-prep-and-follow-up` | Use this custom workflow and preserve its approval gates and labelled source fallbacks |

Record the tenant's Dynamics 365 Sales built-in overlap choices before rollout. If Meeting Prep
or Post-Meeting Follow-Up is retained for a qualified phrase, do not also assign that phrase to
this custom skill. Reflect the same choice in `quota-carrier-concierge/reference.md`. These scope
instructions guide activation; they do not override Cowork's native router.

After qualified or explicit invocation, unavailable CRM data may use the labelled M365-only
fallback below. That fallback must not make this skill activate for unrelated generic meetings.
Event-triggered prep requires `[Prep Trigger]` to be enabled and the meeting to resolve to
`[Prep Account Scope]`. If scope is unset, ambiguous, or cannot be resolved, skip the triggered prep
and report the scope/source gap; do not guess or ask questions in a triggered run.

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Unknown owner | Mark "unassigned" |
| Unknown due date | Mark "no date stated" |
| No transcript or recording | Ask for notes; label the summary "based on notes only" |
| CRM vs. communication conflict | Show both values with sources (for example CRM close date vs. latest email) |
| Customer meeting definition | Calendar event with an external attendee associated with the resolved CRM account; triggered prep also requires an approved `[Prep Account Scope]` match |
| Decisions in brief | Two or three, including anything committed in the customer meeting |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Seller prep time | Minutes per customer meeting gathering context and preparing follow-up | Time study | Meeting prep time |
| Follow-up completion rate | Share of customer meetings with a follow-up sent and owners assigned | Sent items, CRM activities | Follow-up completion rate |
| Follow-up latency | Minutes from meeting end to approved follow-up | Sent items, calendar | Follow-up latency |
| Sales cycle length | Median days in stage for covered opportunities | Dynamics 365 Sales | Win rate and sales cycle length |

## Output templates

| Artifact | Layout |
| --- | --- |
| Meeting summary | Decisions; action items table (item, owner, due date, source); risks, blockers, open questions |
| Customer email | Thanks; summary; decisions; action items; next steps; no internal content |
| Account-team update | Customer status, findings, open items, proposal updates, asks |
| Decision brief | Relationship status; what changed; open opportunities (name, stage, value, close date, next step); commitments; 2-3 decisions; sources |
| Prep brief (prep mode) | Relationship status; what changed since last contact; open opportunities; attendee briefs; 2-3 things to walk in ready to address |
| Invite | Title "Next steps - <Customer>"; brief attached; agenda = decisions |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Teams transcript | Required for transcript summary | Ask for notes; label "based on notes only" |
| Dynamics 365 Sales | Required for account team and opportunities | After qualified or explicit invocation only, build from available M365 data; label CRM sections "not verified against CRM"; do not broaden automatic activation |
| Outlook, Calendar, files | Required | Note gaps in "what changed" |

## Never-automate list

- Sending the customer follow-up or the account-team update
- Sharing the decision brief or prep brief
- Creating or sending the account-team meeting invite
- Writing activities, next steps, close dates, or stages to Dynamics 365 Sales

## Sharing gate

Default state: not sent. Before any send, share, invite, or write, show exact recipients, exact
content, the CRM before/after values, and a private-data warning when content draws on mail,
chat, transcripts, or files.

## Billing

| Item | Value |
| --- | --- |
| Model | USL to UBB |
| Intensity | Medium |
| License-only starter | Copilot Chat prep from email, calendar and files, plus Facilitator recap |
| Cowork (Copilot Credits) | The full multi-source, multi-step workflow with saved artifacts and approval-gated actions |
| Indicative credit band | Medium 300-700 per run (Light 100-300, Heavy 700+); actual use varies |

## Example prompt

> For [Customer]'s Dynamics 365 Sales account, build the CRM-grounded post-meeting follow-up
> package and account-team update. I met with this customer earlier last week. Use the meeting
> transcript, pulling out key decisions made, action items with owners and due dates, and any
> risks, blockers, or open questions raised. Draft a follow-up email to all attendees with the
> summary, decisions, action items, and next steps. Draft an internal update to the account team
> listed on the [Customer] account in Dynamics 365 covering customer status, findings, open items,
> proposal updates, and any asks for the account team. Then schedule a follow-up meeting for end of
> week with the account team to discuss next steps on the account. For that discussion, pull the
> account history, open opportunities, and recent activity from Dynamics 365 Sales, and
> cross-reference my recent emails, meetings, and proposal so the team knows what's changed. Create
> a brief covering where the relationship stands, what's open, and the two or three things we need
> to decide on as a team, including anything we committed to in the meeting. Share the brief with
> the account team on the invite. Show me everything before it's sent or scheduled. Save this
> process as a skill named [Meeting Prep and Follow-Up].
