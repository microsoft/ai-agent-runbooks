# Proposal Pursuit reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Customer Name]`, `[Opportunity]` | `[Customer]`, `[Opportunity]` | Resolve to the Dynamics 365 Sales opportunity |
| `[Proposal Due Date]`, `[Decision Date]` | `[Date]` | From the customer or opportunity |
| `[Proposal Template]` | `[SharePoint path to branded template]` | Approved template only |
| `[Scope / Solution]` | Opportunity product lines | Products, services, quantities |
| `[Pricing Inputs]` | `[Quote or pricing workbook]` | Confirm who approves discounts |
| `[Discount Guidance]` | `[Standard discount policy]` | Above guidance = approval required |
| `[Reviewers]` | `[Legal]`, `[Security]`, `[Pricing / deal desk]`, `[Executive sponsor]` | Look up from prior pursuits first |
| `[Proof Point Sources]` | `[Case study and reference library]` | Approved, customer-shareable only |
| `[Pursuit Workspace]` | `[OneDrive / SharePoint folder or Loop]` | Tracker and drafts location |
| `[CRM Write-back Fields]` | Next step, stage, close date | Only fields approved by sales operations and security |
| `[Refresh Schedule]` | Daily 8:00 a.m. while in flight | Stop when the proposal is sent |
| `[Time Zone]` | `[Seller time zone]` | Used for the refresh and due dates |

## Rules and thresholds

| Rule | Default |
| --- | --- |
| Required approvals before customer send | Legal, security, pricing |
| Pricing outside `[Discount Guidance]` or non-standard terms | Mark "requires approval"; route to pricing / legal |
| Missing pricing | Clearly marked placeholder |
| Proof points per proposal | 2-4, matched to industry and stated need |
| Readiness: Ready | All required approvals recorded; no open blocker |
| Readiness: Pending approvals | Drafts complete; one or more approvals outstanding |
| Readiness: Blocked | A blocker threatens `[Proposal Due Date]` |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Proposal cycle time | Time from proposal stage to customer send | Opportunity history | Proposal cycle time and approval latency |
| Approval latency | Time waiting on legal, security, and pricing approvals | Approval threads | Proposal cycle time and approval latency |
| Win rate | Won / closed for covered opportunities | Dynamics 365 Sales | Win rate and sales cycle length |
| Pursuit capacity | Proposals handled per seller per month | Tracker | Pursuit capacity |

## Output templates

| Artifact | Layout |
| --- | --- |
| Pursuit tracker (Excel or Loop) | Input, Owner, Due, Status, Blocker, Source |
| Draft proposal | Executive summary, understanding of needs, solution, value story, proof points, pricing summary, terms, next steps |
| Readiness summary | Approvals pending/received, blockers, risks to the due date |
| Review request | Reviewer role, exact sections, question, due date, link to draft |
| Cover email | Purpose, highlights tied to needs, attachments, proposed next step |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Dynamics 365 Sales | Required | Ask for opportunity details; label "not verified against CRM" |
| Pricing workbook or quote | Optional | Pricing sections stay as marked placeholders |
| Proposal template, proof library | Required | Draft in plain structure; flag missing template |
| Transcripts, mail, Teams | Required for requirements | Ask the seller; mark requirements "unconfirmed" |

## Never-automate list

- Sending the proposal or cover email to the customer
- Sending review requests to legal, security, or pricing
- Recording an approval on a reviewer's behalf
- Writing next step, stage, or close date to Dynamics 365 Sales

## Sharing gate

Default state: not sent. Before any send or write, show exact recipients, exact content, approval
status, the CRM before/after values, and a private-data warning when content draws on mail, chat,
or transcripts.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Heavy |
| Indicative credit band | Heavy 700+ per run (Light 100-300, Medium 300-700); actual use varies |
| License-only starter | None defined |

## Example prompt

> Run the proposal pursuit for [Opportunity] with [Customer Name], due [Proposal Due Date]. Pull
> the opportunity, product lines, stakeholders, and competitors from Dynamics 365 Sales, and the
> customer's requirements and success criteria from my recent emails and meeting transcripts.
> Build a pursuit tracker, assemble pricing from [Pricing Inputs], pick proof points from [Proof
> Point Sources], and draft the proposal on [Proposal Template]. Draft review requests to
> [Reviewers] and tell me what's blocking the send. Show me every draft and CRM update before
> anything goes out.
