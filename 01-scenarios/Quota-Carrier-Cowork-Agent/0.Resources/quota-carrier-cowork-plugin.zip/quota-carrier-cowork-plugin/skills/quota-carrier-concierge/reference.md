# Quota Carrier Concierge reference

Settings here tune routing for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Plugin Skills]` | The six skills below | Remove a row if the customer does not deploy that skill |
| `[Overlap Decision]` | Native handling for generic meeting requests; custom meeting workflow only for qualified CRM/account-team requests | Record any retained Dynamics 365 Sales Meeting Prep or Post-Meeting Follow-Up phrases; keep the decision aligned with `meeting-prep-and-follow-up/reference.md` |
| `[Starter Recommendation]` | `meeting-prep-and-follow-up` | Suggested first skill for new sellers |
| `[Time Zone]` | `[Seller time zone]` | Used only when describing default cadences |

## Plugin directory (routing table, startup order)

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| CRM-grounded account-team brief or post-meeting follow-through package | `meeting-prep-and-follow-up` | "build a CRM-grounded account-team decision brief for [Customer], reconciling opportunities with recent customer communications" | On demand; optional CRM-scoped event-triggered prep |
| Answer an RFP, RFI, or security/vendor questionnaire | `rfp-response` | "respond to this RFP" | On demand; re-run on addenda and 48 hours before deadline |
| Build a proposal with pricing, proof points, approvals | `proposal-pursuit` | "build the proposal for [Customer]" | Daily 8 a.m. while in flight |
| Prep a QBR or check renewal risk for one account | `renewal-and-qbr-prep` | "prep my QBR with [Customer]" | 10 business days before QBR; 120 days before renewal |
| Find upsell and cross-sell across my accounts | `expansion-and-upsell` | "where's the expansion in my book" | Monthly, first Monday 9 a.m. |
| Review Commit deals at risk before next week | `at-risk-commit-deals` | "which of my commit deals are at risk" | Fridays at noon PST |
| Explicit help choosing among this plugin's skills | `quota-carrier-concierge` | "which skill in the Quota Carrier plugin should I use" | On demand |

## Activation and cross-plugin deployment

This concierge is an optional guide for explicit questions about the Quota Carrier plugin's skills,
not a replacement for Cowork's automatic skill selection. Do not activate for general onboarding,
generic sales help, or direct task requests. The directory and positive routing examples below
guide recommendations within a plugin-selection conversation; they are not standalone triggers
for this concierge.

**Cross-plugin deployment note:** Recommend another plugin's concierge only when that plugin is
deployed and available to the same user. If only Quota Carrier is deployed, edit the leader-goal
routing row below to use the **No-match response** instead of recommending `number-owner-concierge`.
If only Number Owner is deployed, make the equivalent change in
`skills/number-owner-concierge/reference.md` so seller goals do not recommend
`quota-carrier-concierge`. When availability is unconfirmed, use the no-match response.

## Routing tests

| If the user says | Route to |
| --- | --- |
| Within plugin-selection help: "I need a CRM-grounded account-team decision brief for [Customer]" | `meeting-prep-and-follow-up` |
| Within plugin-selection help: "I need Dynamics 365 Sales account and opportunity context before meeting [Customer]" | `meeting-prep-and-follow-up`, subject to the recorded overlap decision |
| "Fill out this security questionnaire" | `rfp-response` |
| "What's blocking our proposal?" | `proposal-pursuit` |
| "Is [Customer]'s renewal at risk?" | `renewal-and-qbr-prep` |
| "Which customers are ready for [Product]?" | `expansion-and-upsell` |
| "Friday commit deal review" | `at-risk-commit-deals` |
| Within plugin-selection help: "Why is my team short of budget?" | `number-owner-concierge` only when Number Owner is confirmed available to this user; otherwise use the No-match response |
| Standalone general onboarding or generic sales-help request | Do not activate this concierge; leave selection to Cowork |
| Standalone generic customer-meeting prep or recap request | Cowork's native handling, including Meetings for prep; do not select this concierge or the custom CRM workflow on that basis alone |
| Standalone request for an RFP, proposal, or another concrete output | Let Cowork select the relevant task skill directly; do not add a concierge step |

## Ambiguity rules

- Within plugin-selection help, recommend `meeting-prep-and-follow-up` only when the desired
  artifact needs CRM/account/opportunity grounding, CRM reconciliation, or the account-team
  follow-through package, or the user explicitly selects that custom skill. A customer name or
  meeting mention alone is insufficient; generic meeting requests stay with native handling.
- "RFP", "RFI", or "questionnaire" routes to `rfp-response`; "proposal", "pricing", or "approvals"
  routes to `proposal-pursuit`.
- "QBR" or "renewal" for one account routes to `renewal-and-qbr-prep`; growth across many accounts
  routes to `expansion-and-upsell`.
- "Commit", "slipping", or "at risk this week" routes to `at-risk-commit-deals`.
- If two fit, pick the narrower artifact first and mention the alternative.
- Requests to rank or compare sellers are declined, not routed.

## Starter recommendation

New sellers start with `meeting-prep-and-follow-up`: it is the anchor workflow and the only Quota
Carrier skill with a license-only starter path.

## Schedule guidance

Do not create a schedule from the concierge. Name the default cadence from the directory and let the
target skill configure it after the seller confirms the exact prompt and cadence.

## No-match response

```markdown
I do not have an available Quota Carrier skill for <goal>. This plugin covers CRM-grounded
account-team prep and follow-up, RFP response, proposal pursuit, renewal and QBR prep, expansion
and upsell, at-risk Commit deals, and plugin-selection help.
```

## Never-automate list and sharing gate

The concierge sends, shares, writes, and schedules nothing. Any action belongs to the target skill
and its own sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Light (routing only) |
| Indicative credit band | Light 100-300 per run; actual use varies |

## Example prompt

> Which skill in the Quota Carrier plugin should I use for [a CRM-grounded account-team brief /
> an RFP / a proposal / a QBR / a renewal / Commit deals closing this week]? Explain which included
> skill fits and give me its trigger phrase; do not perform the task yet.
