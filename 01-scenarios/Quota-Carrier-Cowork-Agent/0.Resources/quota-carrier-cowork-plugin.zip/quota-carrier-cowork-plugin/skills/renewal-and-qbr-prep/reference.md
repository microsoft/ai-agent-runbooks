# Renewal and QBR Prep reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Customer Name]` | `[Customer]` | Resolve to the Dynamics 365 Sales account |
| `[QBR Date]` | `[Date]` | From the calendar or seller |
| `[Review Period]` | Last full quarter | Compared with the prior period |
| `[Renewal Date]` | From contract or CRM renewal opportunity | Drives the 120-day run |
| `[QBR Template]` | `[SharePoint path to QBR template]` | Look up in the account folder first |
| `[Prior QBR Deck]` | `[Account folder]/<last QBR>` | Source of last quarter's commitments |
| `[Usage Dashboard]` | `[Power BI report or Fabric IQ model]` | Usage, adoption, consumption |
| `[Support Source]` | `[Service system, exported report, or mail]` | Volume, severity, escalations, CSAT |
| `[Customer Attendees]`, `[Internal Attendees]` | From CRM contacts and account team | Confirm before drafting the invite |
| `[CRM Write-back Fields]` | Renewal risk, next step, tasks | Only fields approved by sales operations and security |
| `[Schedule]` | 10 business days before each QBR; 120 days before renewal; refresh 2 days before QBR | Configure only after the user confirms |
| `[Time Zone]` | `[Seller time zone]` | Used for schedules and invites |

## Rules and thresholds

| Dimension | Healthy | Watch | At risk |
| --- | --- | --- | --- |
| Usage | At or above goal, stable or rising | Below goal or flat | Declining or well below goal |
| Support | No open escalation; stable volume | Rising volume or recurring theme | Open high-severity escalation |
| Relationship | Sponsor engaged; positive signals | Sponsor change or quiet period | Frustration, competitor evaluation, sponsor lost |
| Commercial | Renewal on track; budget confirmed | Budget or timing unclear | Budget cut, downsizing, or non-renewal signal |

Overall health = the lowest dimension rating unless cited evidence justifies otherwise (state why).
Each rating needs at least one cited source. Set numeric goal bands per product with the customer.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Renewal rate | Renewals won / renewals due in period | Dynamics 365 Sales | Renewal rate and expansion pipeline |
| QBR prep time | Time to assemble the QBR deck and renewal-risk view per account | Time study | QBR and renewal prep time |
| Account retention | Accounts retained in the pilot book | Dynamics 365 Sales | Renewal rate and expansion pipeline |

## Output templates

| Artifact | Layout |
| --- | --- |
| Customer QBR deck (~8-10 slides) | Agenda; goals and outcomes vs. last QBR; usage and adoption trends; support summary; value delivered; roadmap / what's new relevant to them; next-quarter success plan; renewal timeline and next steps |
| Internal assessment (Word, internal only) | Health scorecard with evidence; risks and mitigations; asks; negotiation considerations; stakeholder map |
| Agenda email | Date, attendees, agenda, pre-reads |
| Prep invite | Internal attendees; agenda: health, risks, asks, roles |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Dynamics 365 Sales | Required | Ask for account and renewal details; label "not verified against CRM" |
| Fabric IQ / Power BI usage | Optional | State the gap on the usage slide; ask for an export; do not estimate |
| Support data | Optional | State the gap on the support slide; ask for an export |
| Prior QBR deck | Optional | Note "no prior commitments found"; skip variance vs. goals |

## Never-automate list

- Sending the customer agenda email or sharing the deck with the customer
- Scheduling the internal prep meeting
- Writing renewal risk, next step, or tasks to Dynamics 365 Sales
- Placing internal assessment content in any customer-facing artifact

## Sharing gate

Default state: not sent. Before any send, share, or write, show exact recipients, exact content,
the CRM before/after values, and a warning if internal content appears in a customer artifact.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Medium |
| Indicative credit band | Medium 300-700 per run (Light 100-300, Heavy 700+); actual use varies |
| License-only starter | None defined |

## Example prompt

> Prep my QBR with [Customer Name] on [QBR Date] covering [Review Period]. Pull the account,
> contacts, opportunities, and renewal date from Dynamics 365 Sales, usage trends from [Usage
> Dashboard], support history, and recent emails and meetings with the customer. Compare results
> to the goals in [Prior QBR Deck], assess renewal health with evidence, and draft the QBR deck on
> [QBR Template] plus an internal prep note. Draft the customer agenda email and an internal prep
> meeting, and stage CRM updates — show me everything before it's sent or saved.
