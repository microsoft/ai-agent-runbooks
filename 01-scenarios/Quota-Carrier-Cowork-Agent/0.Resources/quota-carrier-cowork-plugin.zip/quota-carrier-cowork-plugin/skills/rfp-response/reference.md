# RFP Response reference

Settings here tune the skill for a customer. They may tighten, but never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| `[Customer Name]`, `[RFP Title / Number]` | `[Customer]`, `[RFP]` | Link to the Dynamics 365 Sales opportunity |
| `[RFP Folder]` | `[OneDrive / SharePoint folder]` | RFP files, addenda, Q&A clarifications |
| `[Submission Deadline]` | `[Date and time]` | Drives SME due dates and the 48-hour re-run |
| `[Required Response Format]` | Customer template, portal, page limits | Confirm from the RFP |
| `[Approved Content Sources]` | `[Answer library]`, `[Prior responses folder]`, `[Product / security documentation site]` | Governed sources only |
| `[SME Reviewers]` | `[Security]`, `[Legal]`, `[Product]`, `[Pricing]` | Look up from prior RFP threads before asking |
| `[Win Themes]` | None | Optional differentiators for the executive summary |
| `[Stale Source Threshold]` | 12 months | Older approved answers are flagged stale |
| `[SME Lead Time]` | `[Business days before deadline]` | Set with the bid manager |
| `[RFP Trigger]` | Off; option: email with an RFP attachment from a customer domain | Event trigger |
| `[Time Zone]` | `[Seller time zone]` | Used for deadlines and re-runs |

## Rules and thresholds

| Status | Use when |
| --- | --- |
| Fully meets | An approved, current source fully answers the requirement |
| Partially meets | An approved source covers part of the requirement |
| Roadmap | Only an approved roadmap statement applies; needs product approval |
| Does not meet | Approved sources confirm the capability is not offered |
| Needs SME | No, stale, or conflicting source; or a commitment needs approval |

| Confidence | Meaning |
| --- | --- |
| High | Current approved source, direct match |
| Medium | Approved source, tailored or partial match |
| Low | Stale, indirect, or conflicting source |

Gap flags: no source found; stale (older than `[Stale Source Threshold]`); conflicting sources;
legal, pricing, or product approval required. If the answer library is unavailable, mark every
answer "unverified - no governed source".

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Response turnaround time | Time from RFP receipt to submission-ready draft | Bid tracker, mail | RFP response turnaround |
| Answer rework | Answers revised because the source was stale, unapproved, or missing | SME review comments | RFP answer rework |
| Win rate | Won / closed for RFP-driven opportunities | Dynamics 365 Sales | Win rate and sales cycle length |
| Pursuit capacity | RFPs handled per seller per month | Bid tracker | Pursuit capacity |

## Output templates

| Artifact | Layout |
| --- | --- |
| Compliance matrix (Excel) | Req #, Section, Requirement, Type, Compliance status, Confidence, Draft answer, Source citation, Gap/risk note, SME owner, Review status |
| Draft response (Word) | Customer template; executive summary aligned to `[Win Themes]` |
| Gap and risk summary | Counts by status; mandatory not fully met; decisions needed; bid/no-bid considerations |
| SME review request | Area, item numbers, question, current draft, source, due date |

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Approved answer library | Required | Mark every answer "unverified - no governed source" |
| Dynamics 365 Sales | Required for tailoring | Draft generic approved answers; note "not tailored to CRM context" |
| Transcripts, mail, Teams | Optional | Tailor from CRM only; note the gap |

## Never-automate list

- Submitting the response to the customer or a procurement portal
- Sending SME review requests
- Marking an item approved on an SME's behalf
- Adding new content to the approved answer library

## Sharing gate

Default state: not sent and never submitted. Before any SME request is sent, show exact
recipients, item numbers, and content, and a private-data warning when content draws on mail,
chat, or transcripts.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Copilot Credits) |
| Intensity | Heavy |
| Indicative credit band | Heavy 700+ per run (Light 100-300, Medium 300-700); actual use varies |
| License-only starter | None defined |

## Example prompt

> We received [RFP Title] from [Customer Name], due [Submission Deadline]. The RFP and addenda are
> in [RFP Folder]. Extract every requirement, draft answers using only our approved content in
> [Approved Content Sources] and the account context in Dynamics 365 Sales, and build a compliance
> matrix with status, confidence, and source for each item. Flag every gap or stale source, group
> items needing SME review by area, and draft review requests to [SME Reviewers]. Show me the
> package and requests before anything is sent.
