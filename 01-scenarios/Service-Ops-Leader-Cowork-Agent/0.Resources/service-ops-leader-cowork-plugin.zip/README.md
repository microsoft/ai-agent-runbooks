# The Service Ops Leader Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

**Persona:** The Service Ops Leader (Support Team Lead / Service Manager) · **Function:** Customer Service
**Runbook:** `cowork-service-ops-leader-runbook.md`

## Contents

```text
manifest.json
color.png
outline.png
skills/
  service-ops-leader-concierge/
    SKILL.md
    reference.md
  sla-risk-triage/
    SKILL.md
    reference.md
  service-ops-review/
    SKILL.md
    reference.md
  manager-interventions/
    SKILL.md
    reference.md
  voice-of-customer/
    SKILL.md
    reference.md
  coaching-and-training/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `service-ops-leader-concierge` | Routes the user to the right Service Ops Leader skill |
| `sla-risk-triage` | Runs each time the weekly open-cases update email arrives: reviews the Open Cases Workbook, ranks cases by time to SLA breach weighted by priority, explains blockers, recommends the next action (reply, escalate, request update, or close), builds a live HTML triage dashboard with one card per case ordered by urgency, and drafts a stakeholder email to resolve open items |
| `service-ops-review` | Produces a recurring service-operations performance review that combines queue volume and backlog, SLA attainment, CSAT, quality, and escalation data with team updates into a leadership-ready narrative of what changed and why, risks, decisions needed, and open actions, delivered as a review deck, refreshed action tracker, and draft agenda |
| `manager-interventions` | Surfaces the support cases that need leadership attention by scanning queue, SLA, ownership, severity, customer, and sentiment signals against intervention criteria, then keeps a working Excel tracker of manager-needed cases with the signal fired, situation, recommended intervention, owner, due date, and change since last run, plus staged messages |
| `voice-of-customer` | Synthesizes customer feedback for a product and period from a Customer Feedback Workbook of ticket feedback and survey results, plus emails and meeting transcripts, into recurring themes with anonymized quotes, frequency, affected area, likely drivers, and recommended improvements; delivers a concise presentation of three to five priority improvements, an action table with owner, timing, and evidence, and a draft Teams update |
| `coaching-and-training` | Turns recurring quality and knowledge gaps found in case themes, QA reviews, escalations, reopens, and CSAT comments into team-level coaching plans and reusable training materials: a training module deck with anonymized scenario exercises and a knowledge check, a quick-reference guide, a team coaching guide, and proposed knowledge-article updates |

Start with `service-ops-leader-concierge` if you are not sure which skill to use. Recommended starters: `sla-risk-triage` and `service-ops-review`.

## Tune before first use

Each skill has a `reference.md` with customer settings (folders, reports, views, channels, approvers, schedule), rules and thresholds, KPI definitions, output templates, connector fallbacks, the never-automate list and the billing note. Tune `reference.md` first. Do not edit the guardrails in `SKILL.md`; `reference.md` may tighten them, never loosen them.

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, documents, decks, dashboards, and recommendations, but they must not send, post, publish, share, create records, update systems, or change calendars without explicit user confirmation.
