# Coaching and Training reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Queues / team | [Queues / Team] | Required |
| Time period | Last 30 days | [Time Period] |
| Topic | Derived from themes | [Topic], optional |
| QA source | [QA Source] | QA results or scorecard export, aggregated |
| Case workbook | [Case Workbook] | Reopens, escalations, transfers, resolution codes, handling-time outliers |
| Case management system | [Case Management System] - not connected | Optional |
| Knowledge base | [Knowledge Base] | Approved articles and policies |
| SME channels | [SME Teams Channels] | Swarming and escalation discussion |
| Training template | [Training Template] | Deck or LMS module format |
| Output location | [Output Location] | |
| Schedule | Monthly on [date] or quarterly | Plus on demand after major releases or incidents |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the enablement/QA lead before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Gap categories | Product/technical knowledge; process/policy; troubleshooting method; communication/empathy; tooling | |
| Priority score | Impact x frequency x trainability | Top three to five |
| Minimum evidence | Gap must recur across [N] cases or sources | Show evidence count |
| Aggregation | Team level only | Never per agent |
| Scenario exercises | Two or three per module | Built from anonymized real patterns |
| No approved source | Flag and propose a knowledge update | Do not teach unapproved procedure |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Training creation time | Time to build coaching or training material from case themes | Enablement records/self-report | Training creation time |
| Quality score | Team-level QA score for in-scope queues | QA source | Quality score |
| Agent performance improvement (team level) | Team QA and CSAT trend after training | QA source, survey/CSAT | Quality score; CSAT |

## Output templates

Skills-gap summary columns: Gap | Category | Evidence count | Customer impact | Approved source |
Training response.

Module outline: objectives -> concepts -> worked examples -> scenario exercises -> knowledge check
-> references to approved articles.

Quick-reference guide: one page; the steps, the policy line, the article link, common pitfalls.

Rollout note skeleton: why (themes) -> what (materials) -> how (huddles, 1:1 talking points) ->
when -> where materials live.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Case workbook (M365) | Required (default path) | Ask for the export; state gap |
| QA source | Required | Gaps derived from cases and CSAT only; labelled |
| Knowledge base | Required | Materials marked "pending approved source" |
| Survey/CSAT, SME channels | Optional | Note sources not included |
| Case management system | Optional | Use workbook; state source |

## Never-automate list

- Sending the rollout note or any internal message
- Publishing knowledge-article changes
- Updating case records or LMS content

## Sharing gate

Default state: drafts only. Before sharing or sending, show exact recipients and content, and
confirm examples are anonymized and no agent is named, scored, or ranked.

## Billing

| Item | Value |
| --- | --- |
| Billing model | USL to UBB |
| Credit intensity | Medium |
| License-only starter (USL) | Copilot in Word or PowerPoint builds training from a defined theme |
| Cowork (UBB) | Full multi-source gap analysis, materials, and approval-gated rollout |
| Indicative band per run | Medium 300-700 credits; actual use varies |

## Example prompt

> Build coaching and training for [Queues / Team] from case themes over [Time Period]. Use QA
> results from [QA Source], reopened and escalated cases from [Case Workbook] (or [Case Management
> System], if connected), low CSAT comments, and questions raised in our SME Teams channels to
> identify the top three to five recurring skills and knowledge gaps.
>
> Map each gap to approved guidance in [Knowledge Base] and flag where no approved source exists.
> Then create a training module on [Training Template] with anonymized scenario exercises and a
> knowledge check, a one-page quick-reference guide, a team coaching guide, and draft
> knowledge-article updates. Keep everything at the team and theme level - don't rank or evaluate
> individual agents.
>
> Draft a rollout note to team leads and show me everything before saving to [Output Location] or
> sending.
>
> Save this as a skill named [Coaching and Training] and run it monthly on [date].
