# Manager Interventions reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Queues / team | [Queues / Team] | Required |
| Time period | Open cases plus activity in the last 7 days | [Time Period] |
| Open cases workbook | [Open Cases Workbook] | Queue, SLA, severity, owner, reopen count, escalation flags |
| Case management system | [Case Management System] - not connected | Optional; adds owner history |
| Key accounts list | [Key Accounts List] | Optional; account tier or renewal date |
| CSAT source | [CSAT Source] | Survey exports with responses and sentiment |
| Tracker location | [Tracker Location] | Existing Excel tracker or new |
| Schedule | Daily at start of business; fuller refresh Monday morning | Or event when a critical criterion fires |
| Time zone | [Time Zone] | |

## Rules and thresholds

Default intervention criteria (confirm or adjust as [Intervention Criteria]):

| Criterion | Default | Notes |
| --- | --- | --- |
| SLA | Breached or near-breach on a high-severity case | Near-breach uses the `sla-risk-triage` risk window |
| Executive involvement | Customer executive involvement or complaint | |
| Reopens | Reopened more than once | |
| Reassignment churn | Reassigned three or more times | Case signal only |
| Age | Open longer than [N] days | Set [N] per queue |
| Sentiment | Negative CSAT or sentiment on an open case | |
| Cross-team block | Blocked on another team with no response | |
| Key account | Key account at renewal risk | Needs [Key Accounts List] |

Priority order: customer impact, then severity, then time sensitivity, then account importance.
Top-five summary uses this order.

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Manager intervention time | Median time from a case meeting a criterion to manager action | Case history/escalation records | Manager intervention latency |
| Escalations prevented | Flagged cases resolved without formal escalation, judged in review | Tracker/escalation records | Escalations |
| Case backlog | Open in-scope cases, and flagged cases open at period end | Open cases workbook | Case volume managed |

## Output templates

Tracker columns: Case ID | Customer | Severity | Signal(s) fired | Situation summary | Intervention
needed | Owner | Due date | Status | Change since last run | Source links.

Internal message skeleton: case and impact -> what is needed (decision, resource, exception,
customer call, unblock) -> owner and due date -> link.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Open cases workbook (M365) | Required (default path) | Stop and ask for the queue export |
| Outlook, Teams, transcripts | Required | Situation marked "unconfirmed" |
| Survey/CSAT | Optional | Sentiment criterion listed as not evaluated |
| Key accounts / CRM | Optional | Key-account criterion listed as not evaluated |
| Case management system | Optional | Use workbook; state source and timestamp |

## Never-automate list

- Sending messages to case owners, partner teams, or customer executives
- Reassigning, changing priority, or setting escalation flags
- Writing to the shared tracker without confirmation

## Sharing gate

Default state: draft tracker, messages not sent. Before any action, show exact recipients, content,
and staged changes; confirm no agent-level judgment appears.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Medium |
| Indicative band per run | Medium 300-700 credits; actual use varies |
| Volume guardrail | One daily run per team; weekly fuller refresh |

## Example prompt

> Build my manager intervention tracker for [Queues / Team]. Review open cases in [Open Cases
> Workbook] (or [Case Management System], if connected) and flag any that meet these criteria:
> [Intervention Criteria]. Cross-reference recent customer and internal emails, Teams escalation
> chats, meeting transcripts, and CSAT responses to confirm what's happening and what's needed from
> me.
>
> For each flagged case, give me the signal, a short situation summary, the recommended
> intervention, an owner, and a due date. Update [Tracker Location], show what changed since the
> last run, and highlight the top five for today. Keep this focused on cases and blockers, not
> individual agent performance. Draft any messages to case owners or partner teams, but show me
> before sending or updating any records.
>
> Save this as a skill named [Manager Interventions] and run it every weekday at [time].
