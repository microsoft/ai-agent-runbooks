# Service Ops Leader Concierge reference

Settings here tune routing for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Package directory

Startup order follows the plugin: concierge first, then the scenario skills.

| User goal | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Routing help across the plugin | `service-ops-leader-concierge` | "help me choose" | On demand |
| At-risk cases before SLA breach; triage dashboard and stakeholder email | `sla-risk-triage` | "which cases are about to breach" | Event - each weekly open-cases update email |
| Weekly or monthly service performance review deck and tracker | `service-ops-review` | "prepare the weekly service ops review" | Yes - weekly on [day] at [time] |
| Cases needing a manager to step in; intervention tracker | `manager-interventions` | "which cases need my attention" | Yes - daily at start of business |
| Customer feedback themes, drivers, and priority fixes | `voice-of-customer` | "review customer feedback for [Product]" | On demand (optional monthly/quarterly) |
| Team coaching and training from case themes | `coaching-and-training` | "what should we coach the team on" | Yes - monthly or quarterly |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "What's at risk of missing SLA this week?" | `sla-risk-triage` |
| "The weekly open cases update just came in" | `sla-risk-triage` |
| "How did support perform this week?" | `service-ops-review` |
| "Build the service performance deck" | `service-ops-review` |
| "What should I step in on?" | `manager-interventions` |
| "Show me escalation risks across my team's queues" | `manager-interventions` |
| "What are customers complaining about?" | `voice-of-customer` |
| "Top drivers of dissatisfaction for [Product]" | `voice-of-customer` |
| "Turn QA findings into coaching" | `coaching-and-training` |
| "Which skill should I use?" | `service-ops-leader-concierge` |
| "Who is my weakest agent?" | Decline; offer `coaching-and-training` (team level) |
| "Brief me on case [Case ID]" | No match here - point to `case-specialist-concierge` (`case-intake-brief`) |

## Ambiguity rules

- "Queue", "breach", "SLA risk", "open cases update": `sla-risk-triage`.
- "Review", "readout", "scorecard", "deck for leadership": `service-ops-review`.
- "Step in", "need my attention", "escalation risk", "intervention": `manager-interventions`.
- "Feedback", "complaints", "survey themes", "VoC": `voice-of-customer`.
- "Coach", "training", "QA findings", "skills gaps": `coaching-and-training`.
- "How is my queue doing?" with no time frame: `sla-risk-triage` for this week's risk; mention
  `service-ops-review` for the trend narrative.
- If two skills fit, pick the narrower artifact first and mention the alternative.

## Starter recommendation

New users start with `sla-risk-triage` on demand against the latest [Open Cases Workbook], then
`service-ops-review`. Add `manager-interventions` once criteria are agreed, and `voice-of-customer`
and `coaching-and-training` after anonymization and people-safety checks pass.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Skills installed | All five scenario skills | Remove rows above for skills not in pilot scope |
| Cross-persona router | `case-specialist-concierge` | Remove the pointer if not installed |

## Never-automate list

- Creating, changing, or deleting triggers or schedules
- Invoking a sibling skill's outbound actions

## No-match response

```markdown
I do not have a Service Ops Leader skill for <goal> yet. This plugin covers SLA-risk triage,
service ops reviews, manager interventions, voice of the customer, coaching and training, and
routing help.
```

## Schedule guidance

`sla-risk-triage` runs as an event trigger on the named weekly open-cases update email (one run per
email). `service-ops-review` (weekly), `manager-interventions` (daily), and `coaching-and-training`
(monthly or quarterly) are schedule-worthy after their first on-demand runs pass. Do not create any
trigger or schedule unless the user confirms the exact prompt, email or cadence, and time zone.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB |
| Credit intensity | Light (routing only) |
| Note | The routed skill bills at its own band once invoked |

## Example prompt

> I run service operations for [Service Area / Queues]. Help me choose where to start this week.
