# Service Ops Review reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Service area / queues | [Service Area / Queues] | Required |
| Metrics source | [Dashboard / Report] | Service metrics workbook, Power BI service dashboard, or case-system report |
| Targets | [Targets] | SLA, CSAT, quality, backlog |
| CSAT source | [CSAT Source] | Survey export or folder |
| QA source | [QA Source] | QA review results aggregated by criterion |
| Review template | [Review Template] | PowerPoint; default 6-8 slide outline below |
| Prior action tracker | [Prior Action Tracker] | Excel |
| Stakeholders | [Stakeholders] | Review attendees |
| Schedule | Weekly on [day] at [time]; monthly roll-up | Before the service leadership review |
| Time zone | [Time Zone] | |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the service leader before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Comparison | This period vs prior period and target | Monthly roll-up compares month over month |
| RAG Green | At or better than target | Per KPI |
| RAG Amber | Behind target within [tolerance] | Set tolerance per KPI |
| RAG Red | Behind target beyond [tolerance], or trend worsening two periods running | |
| Material movement | Change greater than [materiality threshold] | Only material movements get a "why" |
| Stale metric | Source not refreshed within [N] days of period end | Flag on scorecard |
| Stalled action | No status change since the last review | Flag in action review |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Report generation time | Time to assemble the weekly or monthly review | Self-report/prior decks | Service review prep time |
| SLA performance | SLA attainment by metric vs target | Metrics workbook/report | SLA breach rate |
| Service quality score | Team-level QA score | QA source | Quality score |
| CSAT | Average CSAT for in-scope queues | Survey/CSAT source | CSAT |
| Backlog and aging | Open cases and age distribution | Metrics workbook/report | Case volume managed |

## Output templates

Deck outline (6-8 slides): 1 headline summary; 2 KPI scorecard with traffic lights; 3 what changed
and why; 4 escalations and major incidents; 5 CSAT and quality; 6 risks; 7 decisions needed;
8 action review.

Tracker columns: Action | Owner (role) | Due | Status | Change since last review.

Agenda skeleton: performance -> risks -> decisions needed -> action review; give decisions the
largest time slot and fit to the meeting length.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Metrics workbook/report (M365) | Required (default path) | Stop; ask for the export |
| Power BI service dashboard | Optional | Use the workbook; note source |
| Survey/CSAT, QA | Required for those slides | Mark slide "source unavailable" |
| Outlook, Teams, transcripts | Required for "why" | Movement shown without explanation, labelled |
| Case management system, telemetry | Optional | State source used |

## Never-automate list

- Sharing the deck or tracker
- Sending the invitation or scheduling the meeting
- Modifying case records or source dashboards

## Sharing gate

Default state: not shared, not scheduled. Before any action, show exact attendees, location, deck
version, and confirm content is aggregated with no customer PII or individual agent detail.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Medium |
| Indicative band per run | Medium 300-700 credits; actual use varies |
| Volume guardrail | One weekly run per service area |

## Example prompt

> I'm preparing the weekly service operations review for [Service Area / Queues]. Use [Dashboard /
> Report] (and case data from [Case Management System], if connected) for [Time Period], plus CSAT
> results, quality reviews, and relevant updates from recent emails, Teams discussions, and review
> meetings.
>
> Identify the most important changes since last week, where we're ahead of or behind [Targets] on
> SLA, CSAT, quality, backlog, and escalations, the risks that need leadership attention, decisions
> to be made, and actions from [Prior Action Tracker] that haven't progressed. Keep it at team and
> process level, not individual agents.
>
> Build a review deck on [Review Template] and an updated action tracker, and draft an agenda and
> invitation for [Stakeholders]. Cite sources, flag gaps, and show me everything before sharing or
> scheduling.
>
> Save this as a skill named [Service Ops Review] and run it every [day] at [time].
