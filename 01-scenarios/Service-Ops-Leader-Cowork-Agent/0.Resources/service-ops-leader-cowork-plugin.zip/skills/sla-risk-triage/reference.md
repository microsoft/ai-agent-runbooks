# SLA-Risk Triage reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Trigger email | [Weekly Update Email] sender and subject | Scope tightly so unrelated mail does not fire the run |
| Open cases workbook | [Open Cases Workbook] | Attached or in OneDrive/SharePoint |
| Required fields | Owner, customer, priority, status, age, last customer contact, next action date, SLA target | Map column names here if they differ |
| Risk window | Next 5 business days | [Time Period] |
| Stakeholders | Owners of at-risk cases plus their team lead | [Stakeholders] |
| Dashboard location | [Dashboard Location] | OneDrive or SharePoint folder |
| Case management system | [Case Management System] - not connected | Optional alternative source |
| Time zone | [Time Zone] | Time remaining is computed from the email's received time |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the service leader before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| At risk | SLA target falls inside [Time Period] | Already-breached cases listed first |
| Ranking | Time remaining to SLA target, weighted by priority | Set weights per priority, e.g., [P1 weight], [P2 weight] |
| Blocker classes | Awaiting customer / awaiting internal team or engineering / no owner / stale next-action date / missing information | |
| Stale next action | Next action date in the past | |
| Next actions | Reply, escalate, request update, close | Exactly one per card |
| Source conflict | Workbook and live system or latest email disagree | Show both; never pick silently |
| Run cap | One run per weekly update email | Light band |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| SLA breach rate | Share of in-scope cases breaching SLA in the period | Workbook history (or case system SLA report) | SLA breach rate |
| Queue resolution time | Median time to resolve in-scope cases | Workbook history/report | Queue resolution time |
| Case volume managed | Open cases triaged per lead per week | Open cases workbook | Case volume managed |
| SLA risk detection lead time | Time from entering the risk window to first action | Case activity history | SLA risk detection lead time |

## Output templates

Dashboard (HTML): header (timestamp, source, at-risk count, data-quality flags) -> cards ordered by
urgency. Card fields: customer name | current status | what's blocking progress | time remaining
until SLA target | recommended next action | source link.

Stakeholder email skeleton: purpose (resolve open items to keep accounts on track) -> per-recipient
list of cases, ask, time remaining -> dashboard link -> reply-by time.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Weekly update email (Outlook) | Required for the event run | Run on demand against the latest workbook |
| Open cases workbook | Required (default path) | Stop and ask for the workbook; do not estimate SLA |
| Outlook contact history, Teams | Required | Blocker shown as "unknown - no recent contact found" |
| Case management system | Optional alternative | Use workbook; state source; show conflicts if both used |

## Never-automate list

- Sending the stakeholder email
- Sharing or publishing the dashboard to a shared location
- Writing owner, priority, status, or SLA clock changes to the workbook or a case system

## Sharing gate

Default state: not sent, not shared. Before any action, show exact recipients, the email text, the
dashboard location and audience, and confirm all recipients already have access to the case data.

## Billing

| Item | Value |
| --- | --- |
| Billing model | UBB (Cowork on Copilot Credits) |
| Credit intensity | Light per run; one run per weekly update email |
| Indicative band per run | Light 100-300 credits; actual use varies |
| Cost guardrail | Scope the trigger to the named sender and subject |

## Example prompt

> Every time I get the weekly open cases update in my inbox, review the open cases in [Open Cases
> Workbook] and identify which are at risk of missing their SLA in the next [Time Period]. Use the
> case owner, customer, priority, status, age, last customer contact date, next action date, and SLA
> target fields to determine which cases require attention first.
>
> Build a live HTML triage dashboard - one card per case, ordered by urgency - so I can work
> top-to-bottom through the highest-priority cases first. For each case include the customer name,
> current status, what's blocking progress, time remaining until SLA target, and recommended next
> action (reply, escalate, request update, or close).
>
> Once complete, draft an email to [Stakeholders] notifying them they need to resolve the open items
> to keep our accounts on track. Cite sources, flag missing or conflicting data, and show me the
> dashboard and email before anything goes out.
>
> Save this as a skill named [SLA-Risk Triage] and run it every time the weekly open cases update
> email arrives from [Weekly Update Email].
