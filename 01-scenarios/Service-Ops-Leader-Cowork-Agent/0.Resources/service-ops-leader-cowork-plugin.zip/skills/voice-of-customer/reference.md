# Voice of Customer reference

Settings here tune the skill for one customer. They may tighten, never loosen, the guardrails in
`SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Product | [Product] | Product, service line, or queue |
| Time period | [Time Period] | e.g., last 30 days or last quarter |
| Feedback workbook | [Customer Feedback Workbook] | Excel: ticket feedback and survey results (scores and verbatims) |
| Teams channel | [Customer Feedback Teams Channel] | Destination for the draft update |
| Presentation template | [Presentation Template] | Optional |
| Prior report | [Prior VoC Report] | Optional, for trend comparison |
| Output location | [Output Location] | OneDrive or SharePoint folder |
| Case management system | [Case Management System] - not connected | Optional enrichment |
| Schedule | On demand | Optional monthly on [date] or quarterly, with sponsor approval |

## Rules and thresholds

Suggested defaults below are starting points; confirm them with the sponsor and CX lead before go-live.

| Rule | Default | Notes |
| --- | --- | --- |
| Counting unit | One mention per feedback item per theme | Same rule across all sources |
| Priority score | Customer impact x frequency x feasibility | Pick three to five |
| Emerging theme | Present now, absent or minor in [Prior VoC Report] | |
| Fading theme | Material in prior report, lower now | |
| Low confidence | Theme supported by a single source or small sample | Label in the table |
| Minimum segment size | [Minimum segment size] | Smaller segments are aggregated |
| Anonymization | Remove names, emails, account numbers, identifying details | Applies to quotes and examples |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Improvement actions identified | Count of owned improvement actions from feedback reviews | Action table | Improvement actions identified |
| Engagement rate | Sponsor-agreed measure (e.g., responses to the posted Teams update) | Teams channel/feedback loop | Engagement rate |
| Recurring issue reduction | Volume of top recurring themes per period | Feedback workbook | Recurring issue reduction |
| CSAT | Average CSAT for the product/queue (slide 21 value signal) | Survey/CSAT source | CSAT |
| VoC synthesis effort | Time to turn sources into themes and priorities | Self-report | VoC synthesis effort |

## Output templates

Deck outline: 1 summary and sample sizes; 2 strongest themes; 3 drivers; 4 three to five priority
improvements; 5 action table; appendix: theme detail and method.

Action table columns: Recommended improvement | Owner (role/function) | Timing | Supporting evidence.

Teams update skeleton: period and scope -> top themes (one line each) -> proposed priorities -> link
to deck -> ask for input.

## Connectors and fallbacks

| Source | Required/optional | If unavailable |
| --- | --- | --- |
| Customer feedback workbook (M365) | Required (default path) | Stop and ask for the workbook |
| Outlook emails, Teams transcripts | Required | Note sources not included; sample sizes reflect it |
| Case management system | Optional | Frequency counts from workbook only |
| CSAT report | Optional | Omit score movement |

## Never-automate list

- Posting the Teams update
- Saving the deck to a shared location
- Modifying the feedback workbook, survey data, or case records

## Sharing gate

Default state: draft, not posted. Before posting or saving, show the exact channel or location,
the final text, and confirm quotes are anonymized and small segments aggregated.

## Billing

| Item | Value |
| --- | --- |
| Billing model | USL to UBB |
| Credit intensity | Heavy |
| License-only starter (USL) | Analyst on ticket or survey exports |
| Cowork (UBB) | Full multi-source synthesis, deck, action table, and approval-gated Teams draft |
| Indicative band per run | Heavy 700+ credits; actual use varies |

## Example prompt

> Review customer feedback for [Product] from [Time Period]. Use the compiled support-ticket
> feedback and survey results in [Customer Feedback Workbook], along with recent emails and meeting
> transcripts where customer issues or service experiences were discussed.
>
> Group the feedback into recurring themes. For each theme, capture supporting customer quotes or
> examples, how frequently it appears, the product, issue type, or customer journey stage affected,
> the likely driver behind the feedback, and the service improvement you recommend.
>
> Create a concise presentation covering the strongest themes, their underlying drivers, and the
> three to five improvements worth prioritizing. Include an action table with the recommended
> improvement, owner, timing, and supporting evidence.
>
> Draft an update to post in the [Customer Feedback Teams Channel] summarizing the findings and
> proposed priorities. Anonymize customer quotes, show sample sizes, cite sources, and keep the
> update as a draft until I choose to post it.
>
> Save this as a skill named [Voice of Customer].
