<#
.SYNOPSIS
    Creates an Entra ID app and registers it in ServiceNow as an OIDC provider.

.DESCRIPTION
    Creates Application A for the Power Automate "Microsoft Entra ID User Login"
    connection, then registers that app in ServiceNow so it can verify the
    access token. On Australia and later this is the third-party ID token
    record. The Client ID is the Entra application ID, not the api:// URI.

    ServiceNow username and password are used only for the Table API call.
    The OIDC client secret is not used; the script stores a dummy value
    because the form requires one.

.PARAMETER DisplayName
    Display name of the Entra app and the ServiceNow OIDC records.

.PARAMETER ServiceNowInstance
    PDI URL, for example https://dev12345.service-now.com.

.PARAMETER Credential
    ServiceNow admin username and password. Pass (Get-Credential).

.PARAMETER UserClaim
    JWT claim matched to a ServiceNow user. User login requires upn.
    oid and sub do not match a User ID that is an Entra UPN.

.PARAMETER UserField
    sys_user column matched to UserClaim. "User ID" in the UI is user_name.

.EXAMPLE
    .\Configure-ServiceNowOIDC.ps1 -DisplayName "ServiceNow Connector" -ServiceNowInstance "https://dev12345.service-now.com" -Credential (Get-Credential)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$DisplayName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$ServiceNowInstance,

    [Parameter(Mandatory = $true)]
    [pscredential]$Credential,

    [Parameter()]
    [string[]]$RedirectUris,

    [Parameter()]
    [switch]$CreateSecret,

    [Parameter()]
    [string]$SecretDisplayName = 'Created by script',

    [Parameter()]
    [ValidateRange(1, 2)]
    [int]$SecretYears = 1,

    [Parameter()]
    [string]$UserClaim = 'upn',

    [Parameter()]
    [string]$UserField = 'user_name'
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Module -ListAvailable -Name Az.Resources)) {
    throw "Az.Resources is not installed. Install it with: Install-Module Az.Resources -Scope CurrentUser"
}

Import-Module Az.Resources -ErrorAction Stop

$context = Get-AzContext -ErrorAction SilentlyContinue
if (-not $context) {
    Write-Host "No Azure context found. Signing in..."
    Connect-AzAccount -ErrorAction Stop | Out-Null
    $context = Get-AzContext
}

Write-Host "Using tenant: $($context.Tenant.Id) account: $($context.Account.Id)"

$appParams = @{
    DisplayName    = $DisplayName
    SignInAudience = 'AzureADMyOrg'
}

if ($RedirectUris) {
    $appParams.Web = @{
        RedirectUri = $RedirectUris
    }
}

# The connector sends an access token, so these claims belong only there.
# Use the module's model types. A hashtable is re-parsed by Az.Resources 8.x and
# throws "An item with the same key has already been added. Key: accessToken".
$optionalClaimNames = @('email', 'upn')
$accessTokenClaims = foreach ($claimName in $optionalClaimNames) {
    $claim = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphOptionalClaim]::new()
    $claim.Name = $claimName
    $claim.Essential = $false
    $claim
}

$optionalClaims = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphOptionalClaims]::new()
$optionalClaims.IdToken = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphOptionalClaim[]]@()
$optionalClaims.AccessToken = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphOptionalClaim[]]@($accessTokenClaims)
$appParams.OptionalClaim = $optionalClaims

$existingApplication = @(Get-AzADApplication -DisplayName $DisplayName -ErrorAction SilentlyContinue) |
    Where-Object { $_.DisplayName -eq $DisplayName } |
    Select-Object -Last 1
if ($existingApplication) {
    Write-Host "Reusing Entra app $($existingApplication.AppId)"
    $application = $existingApplication
}
else {
    $application = New-AzADApplication @appParams
}

# Power Automate "Microsoft Entra ID User Login" calls this app as a resource.
# The caller is Microsoft's first-party connector, not a second app you create.
# The scope must be saved before it is referenced by preAuthorizedApplications.
# Entra rejects both changes in one update with "Permission Id that cannot be found".
$connectorAppId = 'c26b24aa-7874-4e06-ad55-7d06b1f79b63'
$identifierUri = "api://$($application.AppId)"

Update-AzADApplication -ApplicationId $application.AppId -IdentifierUri $identifierUri | Out-Null

$current = Get-AzADApplication -ApplicationId $application.AppId
$scope = @($current.Api.Oauth2PermissionScope) |
    Where-Object { $_.Value -eq 'user_impersonation' } |
    Select-Object -First 1
if (-not $scope) {
    $scope = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphPermissionScope]::new()
    $scope.Id = [guid]::NewGuid().ToString()
    $scope.Value = 'user_impersonation'
    $scope.Type = 'User'
    $scope.IsEnabled = $true
    $scope.AdminConsentDisplayName = "Access $DisplayName"
    $scope.AdminConsentDescription = "Access $DisplayName on behalf of the signed-in user"
    $scope.UserConsentDisplayName = "Access $DisplayName"
    $scope.UserConsentDescription = "Access $DisplayName on your behalf"

    $scopeApi = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphApiApplication]::new()
    $scopeApi.Oauth2PermissionScope = @($scope)
    Update-AzADApplication -ApplicationId $application.AppId -Api $scopeApi | Out-Null
    $current = Get-AzADApplication -ApplicationId $application.AppId
    $scope = @($current.Api.Oauth2PermissionScope) |
        Where-Object { $_.Value -eq 'user_impersonation' } |
        Select-Object -First 1
}
if (-not $scope.Id) {
    throw "Entra did not save the user_impersonation scope on application $($application.AppId)."
}

$alreadyAuthorized = @($current.Api.PreAuthorizedApplication) |
    Where-Object { $_.AppId -eq $connectorAppId -and @($_.DelegatedPermissionId) -contains $scope.Id }
if (-not $alreadyAuthorized) {
    $preAuthorized = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphPreAuthorizedApplication]::new()
    $preAuthorized.AppId = $connectorAppId
    $preAuthorized.DelegatedPermissionId = @($scope.Id)

    $preAuthApi = [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphApiApplication]::new()
    $preAuthApi.Oauth2PermissionScope = @($current.Api.Oauth2PermissionScope)
    $preAuthApi.PreAuthorizedApplication = @($current.Api.PreAuthorizedApplication) + @($preAuthorized)
    Update-AzADApplication -ApplicationId $application.AppId -Api $preAuthApi | Out-Null
}

if (-not (Get-AzADServicePrincipal -ApplicationId $application.AppId -ErrorAction SilentlyContinue)) {
    New-AzADServicePrincipal -ApplicationId $application.AppId | Out-Null
}

# Keep v1 tokens. The ServiceNow metadata URL below has no /v2.0, and Expose an API
# can flip requestedAccessTokenVersion to 2, which makes ServiceNow reject the token.
Update-AzADApplication -ApplicationId $application.AppId -OptionalClaim $optionalClaims -RequestedAccessTokenVersion 1 | Out-Null

$result = [ordered]@{
    DisplayName    = $application.DisplayName
    AppId          = $application.AppId
    ObjectId       = $application.Id
    SignInAudience = $application.SignInAudience
    TenantId       = $context.Tenant.Id
    OptionalClaims       = ($optionalClaimNames -join ', ')
    IdentifierUri        = $identifierUri
    ConnectorAppId       = $connectorAppId
    ResourceUri          = $application.AppId
}

if ($CreateSecret) {
    $credential = New-AzADAppCredential `
        -ApplicationId $application.AppId `
        -DisplayName $SecretDisplayName `
        -EndDate (Get-Date).AddYears($SecretYears)

    $result.SecretDisplayName = $SecretDisplayName
    $result.SecretEndDate     = $credential.EndDateTime
    # Secret text is only available at creation time.
    $result.ClientSecret      = $credential.SecretText
}

$ServiceNowInstance = $ServiceNowInstance.TrimEnd('/')
if ($ServiceNowInstance -notmatch '^https://[^/]+$') {
    throw "ServiceNowInstance must be an https instance URL, for example https://dev12345.service-now.com"
}

# Learn article Step 2. Do not append /v2.0: that article validates the
# resource-style token whose issuer comes from the v1 metadata document.
$metadataUrl = "https://login.microsoftonline.com/$($context.Tenant.Id)/.well-known/openid-configuration"

$script:SnHeaders = @{
    Accept         = 'application/json'
    'Content-Type' = 'application/json'
}
$script:PreserveAuthorizationOnRedirect = (Get-Command Invoke-RestMethod).Parameters.ContainsKey('PreserveAuthorizationOnRedirect')

function Invoke-ServiceNowApi {
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$RelativeUri,
        [hashtable]$Body
    )

    $params = @{
        Method         = $Method
        Uri            = "$ServiceNowInstance/api/now/$RelativeUri"
        Headers        = $script:SnHeaders
        Authentication = 'Basic'
        Credential     = $Credential
        ErrorAction    = 'Stop'
    }
    if ($script:PreserveAuthorizationOnRedirect) {
        $params.PreserveAuthorizationOnRedirect = $true
    }
    if ($Body) {
        $params.Body = ($Body | ConvertTo-Json -Compress -Depth 6)
    }

    try {
        $response = Invoke-RestMethod @params
        return [pscustomobject]@{ Status = 200; Result = $response.result; Error = $null }
    }
    catch {
        $status = 0
        $detail = $_.ErrorDetails.Message
        $httpResponse = $_.Exception.Response
        if ($httpResponse) {
            $status = [int]$httpResponse.StatusCode
            if (-not $detail) {
                try {
                    $stream = $httpResponse.GetResponseStream()
                    $reader = New-Object System.IO.StreamReader($stream)
                    $detail = $reader.ReadToEnd()
                    $reader.Dispose()
                }
                catch { }
            }
        }
        if (-not $detail) { $detail = $_.Exception.Message }
        return [pscustomobject]@{ Status = $status; Result = $null; Error = $detail }
    }
}

function Send-ServiceNowRecord {
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$RelativeUri,
        [hashtable]$Body
    )

    $pending = @{}
    foreach ($key in $Body.Keys) { $pending[$key] = $Body[$key] }

    for ($attempt = 0; $attempt -lt 8; $attempt++) {
        $response = Invoke-ServiceNowApi -Method $Method -RelativeUri $RelativeUri -Body $pending
        if ($response.Status -lt 400) { return $response }

        if ($response.Error -match 'Invalid field (\w+)' -and $pending.ContainsKey($Matches[1])) {
            Write-Warning "ServiceNow rejected field '$($Matches[1])'. Retrying without it."
            $pending.Remove($Matches[1])
            continue
        }

        throw "ServiceNow $Method $RelativeUri failed ($($response.Status)): $($response.Error)"
    }

    throw "ServiceNow $Method $RelativeUri failed after removing invalid fields."
}

function Get-ServiceNowColumns {
    param([Parameter(Mandatory)][string[]]$Tables)

    $names = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($table in $Tables) {
        $query = [Uri]::EscapeDataString("name=$table^elementISNOTEMPTY")
        $response = Invoke-ServiceNowApi -Method Get -RelativeUri "table/sys_dictionary?sysparm_query=$query&sysparm_fields=element&sysparm_limit=400"
        if ($response.Status -ge 400) { return $null }
        foreach ($row in @($response.Result)) {
            if ($row.element) { [void]$names.Add([string]$row.element) }
        }
    }
    return $names
}

Write-Host "Connecting to ServiceNow as $($Credential.UserName)"
$probe = Invoke-ServiceNowApi -Method Get -RelativeUri 'table/sys_user?sysparm_limit=1&sysparm_fields=sys_id'
if ($probe.Status -ge 400) {
    throw @"
ServiceNow login failed ($($probe.Status)): $($probe.Error)
Use the local ServiceNow user and password, not the Entra password. Basic authentication must also be enabled for inbound API calls.
"@
}

$configColumns = Get-ServiceNowColumns -Tables @('oidc_provider_configuration')
$configQuery = [Uri]::EscapeDataString("name=$DisplayName")
$existingConfig = Invoke-ServiceNowApi -Method Get -RelativeUri "table/oidc_provider_configuration?sysparm_query=$configQuery&sysparm_fields=sys_id,name&sysparm_limit=1"
if ($existingConfig.Status -ge 400) {
    throw "Could not query oidc_provider_configuration ($($existingConfig.Status)): $($existingConfig.Error)"
}

$configBody = @{
    name                      = $DisplayName
    oidc_url                  = $metadataUrl
    user_claim                = $UserClaim
    user_field                = $UserField
    enable_jti_verification   = 'false'
}
if (-not $configColumns -or $configColumns.Contains('oidc_config_cache_life_span')) {
    $configBody.oidc_config_cache_life_span = '120'
}
elseif ($configColumns.Contains('oidc_configuration_cache_lifespan')) {
    $configBody.oidc_configuration_cache_lifespan = '120'
}
if ($configColumns -and $configColumns.Contains('sys_scope')) {
    $configBody.sys_scope = 'global'
}

$configRecord = @($existingConfig.Result) | Where-Object { $_.sys_id } | Select-Object -First 1
if ($configRecord) {
    Write-Host "Updating OIDC provider configuration $($configRecord.sys_id)"
    $savedConfig = Send-ServiceNowRecord -Method Patch -RelativeUri "table/oidc_provider_configuration/$($configRecord.sys_id)" -Body $configBody
    $configId = $configRecord.sys_id
}
else {
    try {
        Write-Host 'Creating OIDC provider configuration'
        $savedConfig = Send-ServiceNowRecord -Method Post -RelativeUri 'table/oidc_provider_configuration' -Body $configBody
        $configId = $savedConfig.Result.sys_id
    }
    catch {
        if ($_.Exception.Message -notmatch '\(403\)') { throw }
        Write-Warning 'Creating oidc_provider_configuration was denied. Updating the built-in Azure/Entra configuration instead.'
        $fallbackQuery = [Uri]::EscapeDataString('nameLIKEAzure^ORnameLIKEEntra^ORnameLIKEMicrosoft')
        $fallback = Invoke-ServiceNowApi -Method Get -RelativeUri "table/oidc_provider_configuration?sysparm_query=$fallbackQuery&sysparm_fields=sys_id,name&sysparm_limit=1"
        $fallbackRecord = @($fallback.Result) | Where-Object { $_.sys_id } | Select-Object -First 1
        if (-not $fallbackRecord) { throw }
        $savedConfig = Send-ServiceNowRecord -Method Patch -RelativeUri "table/oidc_provider_configuration/$($fallbackRecord.sys_id)" -Body $configBody
        $configId = $fallbackRecord.sys_id
    }
}

if (-not $configId) {
    throw 'ServiceNow did not return an OIDC provider configuration sys_id.'
}

$entityQuery = [Uri]::EscapeDataString("client_id=$($application.AppId)")
$existingEntity = Invoke-ServiceNowApi -Method Get -RelativeUri "table/oauth_oidc_entity?sysparm_query=$entityQuery&sysparm_fields=sys_id,name,client_id&sysparm_limit=1"
if ($existingEntity.Status -ge 400) {
    throw "Could not query oauth_oidc_entity ($($existingEntity.Status)): $($existingEntity.Error)"
}

$entityBody = @{
    name                          = $DisplayName
    client_id                     = $application.AppId
    active                        = 'true'
    oidc_provider_configuration   = $configId
}
$entityRecord = @($existingEntity.Result) | Where-Object { $_.sys_id } | Select-Object -First 1
if ($entityRecord) {
    Write-Host "Updating OIDC application registry $($entityRecord.sys_id)"
    $savedEntity = Send-ServiceNowRecord -Method Patch -RelativeUri "table/oauth_oidc_entity/$($entityRecord.sys_id)" -Body $entityBody
    $entityId = $entityRecord.sys_id
}
else {
    # Required by the form. ServiceNow does not use it when verifying ID tokens.
    $entityBody.client_secret = [guid]::NewGuid().ToString('n')
    Write-Host 'Creating OIDC application registry record'
    $savedEntity = Send-ServiceNowRecord -Method Post -RelativeUri 'table/oauth_oidc_entity' -Body $entityBody
    $entityId = $savedEntity.Result.sys_id
}

if (-not $entityId) {
    throw 'ServiceNow did not return an OAuth OIDC entity sys_id.'
}

$result.ServiceNowInstance = $ServiceNowInstance
$result.OidcMetadataUrl = $metadataUrl
$result.OidcConfigSysId = $configId
$result.OidcEntitySysId = $entityId
$result.UserClaim = $UserClaim
$result.UserField = $UserField

[pscustomobject]$result

