#requires -Version 7.0
<#
.SYNOPSIS
    Creates an API-only ServiceNow integration user for SAML SSO and provisioning.

.DESCRIPTION
    Creates int-saml as an API-only user with admin by default, for SAML
    configuration and Microsoft Entra provisioning. This grants full administrator
    privileges; the separate granular SAML roles are normally unnecessary.
    Use -Roles for an approved restricted list or customized ACL requirements.

    Generates a cryptographically random 32-character password with uppercase,
    lowercase, digits, and special characters. Creates the account inactive,
    verifies its settings and roles, then activates and unlocks it. Tests the
    exact generated credential before displaying its password once.
    Existing usernames are rejected without changes. On failure, attempts to
    deactivate and lock any confirmed new account and reports the cleanup result.
    -WhatIf validates prerequisites without generating a password or writing.

    No ACR, MFA, authentication-policy, ACL, or Internal Integration User settings
    are changed. API-only does not bypass Basic authentication restrictions.
    REST verification does not prove SOAP provisioning access: also test the
    Entra provisioning connection with ACR and SSO enabled.

    Save the password in your password manager; transcripts can capture it.
    It is not returned or saved to a file. Customized password policies may
    reject it; policies are not weakened and password changes are not retried.
    Creation uses sysparm_input_display_value=true for the password setter.

.PARAMETER ServiceNowInstance
    HTTPS instance URL, for example https://dev12345.service-now.com.

.PARAMETER Credential
    Existing administrator Basic credential permitted to use the Table API.

.PARAMETER UserName
    New user_name, default int-saml. The password is generated automatically.

.PARAMETER Roles
    Existing role names, default admin. An explicit list replaces the default;
    admin is never added to a restricted list. Missing roles prevent creation.

.PARAMETER DisplayName
    User's first_name, default ServiceNow SAML Integration.

.EXAMPLE
    .\New-ServiceNowIntegrationUser.ps1 -ServiceNowInstance "https://dev12345.service-now.com" -Credential $bootstrapCredential -WhatIf

.EXAMPLE
    .\New-ServiceNowIntegrationUser.ps1 -ServiceNowInstance "https://dev12345.service-now.com" -Credential $bootstrapCredential

.EXAMPLE
    .\New-ServiceNowIntegrationUser.ps1 -ServiceNowInstance "https://dev12345.service-now.com" -Credential $bootstrapCredential -UserName "int-saml-only" -Roles @('sso_config_admin', 'business_rule_admin', 'script_include_admin')

    Creates a restricted SAML-only account, not a provisioning administrator.
    The full SAML script also reads users and writes properties and certificates;
    approve any additional access needed on your instance.

.LINK
    https://www.servicenow.com/docs/r/platform-security/authentication/t_CreateASAML2Upd1SSOConfigMultiSSO.html

.LINK
    https://learn.microsoft.com/en-us/entra/identity/saas-apps/servicenow-provisioning-tutorial
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'None')]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$ServiceNowInstance,

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [pscredential]$Credential,

    [ValidateNotNullOrEmpty()]
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_.@-]*$')]
    [string]$UserName = 'int-saml',

    [ValidateNotNullOrEmpty()]
    [ValidatePattern('^[A-Za-z0-9_.-]+$')]
    [string[]]$Roles = @('admin', 'snc_basic_auth_api_access'),

    [ValidateNotNullOrEmpty()]
    [string]$DisplayName = 'ServiceNow SAML Integration'
)

$ErrorActionPreference = 'Stop'
$instanceUri = $null
if (-not [uri]::TryCreate($ServiceNowInstance, [UriKind]::Absolute, [ref]$instanceUri) -or
    $instanceUri.Scheme -ne 'https' -or $instanceUri.UserInfo -or
    $instanceUri.AbsolutePath -ne '/' -or $instanceUri.Query -or $instanceUri.Fragment) {
    throw 'ServiceNowInstance must be an HTTPS instance URL without a path, query, fragment, or embedded credentials.'
}
$ServiceNowInstance = $instanceUri.GetLeftPart([UriPartial]::Authority)
$roleNames = @($Roles | Sort-Object -Unique)

function Invoke-ServiceNowRecordApi {
    param(
        [Parameter(Mandatory)][string]$RelativeUri,
        [ValidateSet('Get', 'Post', 'Patch')][string]$Method = 'Get',
        [hashtable]$Body,
        [switch]$SensitiveRequest,
        [pscredential]$ApiCredential = $Credential
    )

    $params = @{
        Method             = $Method
        Uri                = "$ServiceNowInstance/api/now/table/$RelativeUri"
        Headers            = @{ Accept = 'application/json' }
        Authentication     = 'Basic'
        Credential         = $ApiCredential
        MaximumRedirection = 0
        ErrorAction        = 'Stop'
    }
    if ($null -ne $Body) {
        $params.ContentType = 'application/json'
        $params.Body = $Body | ConvertTo-Json -Compress -Depth 4
    }

    try {
        $response = Invoke-RestMethod @params
    }
    catch {
        $httpResponse = $_.Exception.Response
        $status = if ($httpResponse) { "HTTP $([int]$httpResponse.StatusCode)" } else { 'no HTTP response' }
        if ($SensitiveRequest) {
            $detail = 'Response details omitted for this sensitive request. Check ServiceNow logs for authentication, authorization, password-policy, or business-rule failures.'
        }
        else {
            $detail = $_.ErrorDetails.Message
            if (-not $detail) { $detail = $_.Exception.Message }
        }
        throw "ServiceNow $Method $RelativeUri failed ($status): $detail"
    }

    if ($null -eq $response -or $response -is [string] -or $null -eq $response.result) {
        throw "ServiceNow $Method $RelativeUri returned no Table API JSON result. Interactive login or MFA pages cannot authenticate this script."
    }
    return $response.result
}

function New-ServiceNowPassword {
    $groups = @('ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789', '!@#$%^&*_-')
    $alphabet = $groups -join ''
    $characters = [char[]]::new(32)
    try {
        for ($index = 0; $index -lt $groups.Count; $index++) {
            $group = $groups[$index]
            $characters[$index] = $group[[System.Security.Cryptography.RandomNumberGenerator]::GetInt32($group.Length)]
        }
        for ($index = $groups.Count; $index -lt $characters.Length; $index++) {
            $characters[$index] = $alphabet[[System.Security.Cryptography.RandomNumberGenerator]::GetInt32($alphabet.Length)]
        }
        for ($index = $characters.Length - 1; $index -gt 0; $index--) {
            $other = [System.Security.Cryptography.RandomNumberGenerator]::GetInt32($index + 1)
            $characters[$index], $characters[$other] = $characters[$other], $characters[$index]
        }
        $password = [securestring]::new()
        foreach ($character in $characters) { $password.AppendChar($character) }
        $password.MakeReadOnly()
        return $password
    }
    finally {
        [Array]::Clear($characters, 0, $characters.Length)
    }
}

function Assert-ServiceNowIntegrationUserSettings {
    param(
        [Parameter(Mandatory)][object]$User,
        [Parameter(Mandatory)][bool]$Active
    )

    $expected = @{
        user_name               = $UserName
        active                  = $(if ($Active) { 'true' } else { 'false' })
        web_service_access_only = 'true'
        password_needs_reset    = 'false'
    }
    if ($Active) { $expected.locked_out = 'false' }
    foreach ($field in ($expected.Keys | Sort-Object)) {
        if ([string]$User.$field -ne $expected[$field]) {
            $actual = if ($null -eq $User.$field) { '<missing/null>' } else { [string]$User.$field }
            throw "ServiceNow account setting '$field' expected '$($expected[$field])', actual '$actual'."
        }
    }
}

$userFields = 'sys_id,user_name,active,web_service_access_only,password_needs_reset,locked_out'
$userQuery = [Uri]::EscapeDataString("user_name=$UserName^EQ")
$existing = @(Invoke-ServiceNowRecordApi -RelativeUri "sys_user?sysparm_query=$userQuery&sysparm_fields=sys_id,user_name&sysparm_limit=2")
if ($existing.Count -gt 0) {
    throw "ServiceNow username '$UserName' already exists. No account, password, or roles were changed. Manage the existing account in ServiceNow or choose a different -UserName."
}

$roleRecords = foreach ($roleName in $roleNames) {
    $roleQuery = [Uri]::EscapeDataString("name=$roleName^EQ")
    $rolesFound = @(Invoke-ServiceNowRecordApi -RelativeUri "sys_user_role?sysparm_query=$roleQuery&sysparm_fields=sys_id,name&sysparm_limit=2")
    if ($rolesFound.Count -ne 1 -or $rolesFound[0].name -ne $roleName -or $rolesFound[0].sys_id -notmatch '^[0-9a-f]{32}$') {
        throw "Role '$roleName' was not uniquely readable on this instance. Verify the role exists and bootstrap access permits reading it. No user was created."
    }
    $rolesFound[0]
}

if (-not $PSCmdlet.ShouldProcess("$ServiceNowInstance user '$UserName'", "Create API-only user with roles: $($roleNames -join ', ')")) {
    return
}

$newPassword = New-ServiceNowPassword

$newUserId = $null
try {
    $createBody = @{}
    try {
        $createBody = @{
            user_name               = $UserName
            first_name              = $DisplayName
            user_password           = [System.Net.NetworkCredential]::new('', $newPassword).Password
            active                  = $false
            web_service_access_only = $true
            password_needs_reset    = $false
            locked_out              = $true
        }
        $created = Invoke-ServiceNowRecordApi -Method Post -RelativeUri "sys_user?sysparm_fields=sys_id&sysparm_input_display_value=true" -Body $createBody -SensitiveRequest
    }
    finally {
        $createBody.Remove('user_password')
    }
    if ($created.sys_id -notmatch '^[0-9a-f]{32}$') {
        throw 'ServiceNow did not return a valid sys_id for the new user.'
    }
    $newUserId = $created.sys_id
    $user = Invoke-ServiceNowRecordApi -RelativeUri "sys_user/${newUserId}?sysparm_fields=$userFields"
    Assert-ServiceNowIntegrationUserSettings -User $user -Active $false

    foreach ($role in $roleRecords) {
        $assignmentQuery = [Uri]::EscapeDataString("user=$newUserId^role=$($role.sys_id)^EQ")
        $assignments = @(Invoke-ServiceNowRecordApi -RelativeUri "sys_user_has_role?sysparm_query=$assignmentQuery&sysparm_fields=sys_id&sysparm_limit=1")
        if ($assignments.Count -eq 0) {
            $assignment = Invoke-ServiceNowRecordApi -Method Post -RelativeUri 'sys_user_has_role?sysparm_fields=sys_id' -Body @{
                user = $newUserId
                role = $role.sys_id
            }
            if (-not $assignment.sys_id) { throw "ServiceNow did not confirm assignment of role '$($role.name)'." }
        }
    }

    $assignedQuery = [Uri]::EscapeDataString("user=$newUserId^roleIN$($roleRecords.sys_id -join ',')^EQ")
    $assignedRoles = @(Invoke-ServiceNowRecordApi -RelativeUri "sys_user_has_role?sysparm_query=$assignedQuery&sysparm_fields=role&sysparm_exclude_reference_link=true&sysparm_limit=$($roleNames.Count)")
    foreach ($role in $roleRecords) {
        if ($assignedRoles.role -notcontains $role.sys_id) {
            throw "ServiceNow did not verify role '$($role.name)' on the new account."
        }
    }

    $null = Invoke-ServiceNowRecordApi -Method Patch -RelativeUri "sys_user/${newUserId}?sysparm_fields=sys_id" -Body @{ active = $true; locked_out = $false }
    $user = Invoke-ServiceNowRecordApi -RelativeUri "sys_user/${newUserId}?sysparm_fields=$userFields"
    Assert-ServiceNowIntegrationUserSettings -User $user -Active $true

    $generatedCredential = [pscredential]::new($UserName, $newPassword)
    try {
        $verifiedUser = Invoke-ServiceNowRecordApi -RelativeUri "sys_user/${newUserId}?sysparm_fields=sys_id" -ApiCredential $generatedCredential -SensitiveRequest
    }
    catch {
        throw "The generated credential could not authenticate or access the ServiceNow sys_user Table API. $($_.Exception.Message)"
    }
    if ($verifiedUser.sys_id -cne $newUserId) {
        throw 'The generated credential did not return the expected ServiceNow user record. API access could not be verified.'
    }
    Write-Host "Generated password for '$UserName' (save it in your password manager): $($generatedCredential.GetNetworkCredential().Password)"
}
catch {
    $originalError = $_.Exception.Message
    $cleanup = "No new user sys_id was confirmed. Check whether '$UserName' was created before retrying."
    if ($newUserId) {
        try {
            $null = Invoke-ServiceNowRecordApi -Method Patch -RelativeUri "sys_user/${newUserId}?sysparm_fields=sys_id" -Body @{ active = $false; locked_out = $true }
            $state = Invoke-ServiceNowRecordApi -RelativeUri "sys_user/${newUserId}?sysparm_fields=active,locked_out"
            if ([string]$state.active -ne 'false' -or [string]$state.locked_out -ne 'true') {
                throw 'ServiceNow did not confirm deactivation and lockout.'
            }
            $cleanup = "Account '$UserName' ($newUserId) is inactive and locked. An administrator must inspect the account in ServiceNow before retrying."
        }
        catch {
            $cleanup = "Could not ensure account '$UserName' ($newUserId) is inactive and locked: $($_.Exception.Message). An administrator must inspect it."
        }
    }
    throw "$originalError`n$cleanup"
}
finally {
    $newPassword.Dispose()
}

[pscustomobject][ordered]@{
    ServiceNowInstance   = $ServiceNowInstance
    UserName             = $UserName
    SysId                = $newUserId
    Active               = $true
    WebServiceAccessOnly = $true
    Roles                = $roleNames
}
